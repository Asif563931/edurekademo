# SynergyX Logging System

## Overview
This document describes the centralized logging system implemented across the SynergyX repository.

## Configuration Files

### `log.conf`
Main logging configuration file located in the project root. Defines:
- **Loggers**: Different loggers for different components (a2a_server, mcp_server, llm_helper, etc.)
- **Handlers**: Console and rotating file handlers
- **Formatters**: Detailed and simple formatting options

### Key Features
- **Rotating File Logs**: Automatic log rotation (10MB max, 5 backup files)
- **Multiple Log Levels**: DEBUG, INFO, WARNING, ERROR, CRITICAL
- **Structured Logging**: Consistent format across all components
- **Performance Metrics**: Built-in performance tracking
- **Security Event Logging**: Special handling for security-related events

## Log Files Location
All logs are stored in `./logs/` directory:
- `synergyx.log` - Main application log (all components)
- `synergyx_error.log` - Error-only log
- Component-specific logs may also be created

## Usage

### Basic Logging
```python
from core.logger import get_logger

logger = get_logger("component_name")
logger.info("This is an info message")
logger.error("This is an error message")
```

### Critical Operations
```python
from core.logger import log_critical_operation

log_critical_operation(logger, "OPERATION_NAME", {
    "key": "value",
    "details": "additional_info"
})
```

### Security Events
```python
from core.logger import log_security_event

log_security_event(logger, "SECURITY_EVENT", {
    "event_type": "authentication_failure",
    "user": "username"
})
```

### Performance Metrics
```python
from core.logger import log_performance_metric

log_performance_metric(logger, "operation_time", 150.5, "ms")
```

## Log Levels by Component

### A2A Server (`a2a_server`)
- **DEBUG**: Intent classification, agent selection details
- **INFO**: Message processing, configuration loading
- **WARNING**: Missing agents, MCP connection issues
- **ERROR**: Configuration errors, processing failures
- **CRITICAL**: System startup/shutdown, agent selection

### MCP Server (`mcp_server`)
- **DEBUG**: Tool execution details, request processing
- **INFO**: Server startup, tool registration
- **WARNING**: Safety violations, PII detection
- **ERROR**: Tool execution failures, configuration issues
- **CRITICAL**: Server startup/shutdown, security blocks

### LLM Helper (`llm_helper`)
- **INFO**: LLM client initialization
- **WARNING**: Connection issues, model fallbacks
- **ERROR**: Client initialization failures
- **CRITICAL**: Model availability issues

## Security Logging

The system includes specialized security logging for:
- **Content Moderation**: Blocked keywords, inappropriate content
- **PII Detection**: Personal information detection and redaction
- **Prompt Injection**: Malicious prompt attempts
- **Jailbreak Prevention**: Attempts to bypass safety measures

Security events are logged with the format:
```
SECURITY: event_type | Details: {"key": "value"}
```

## Performance Monitoring

Performance metrics are automatically logged for:
- Intent classification time
- MCP tool loading time
- Message processing time
- Safety check processing time
- PII detection and redaction time

Performance logs use the format:
```
PERFORMANCE: metric_name=value_unit
```

## Critical Operations

Critical operations are logged for audit purposes:
- System startup/shutdown
- Agent selection and routing
- Security policy violations
- Configuration changes
- Service failures

Critical operations use the format:
```
CRITICAL_OP: operation_name | Details: {"key": "value"}
```

## Startup

Use the centralized startup script for proper logging initialization:
```bash
python start_with_logging.py --service all
```

Or initialize logging manually in your code:
```python
from core.logger import setup_logging
setup_logging()
```

## Log Rotation

Logs are automatically rotated when they reach 10MB:
- Main logs: 5 backup files kept
- Error logs: 3 backup files kept
- Old logs are compressed and archived

## Troubleshooting

### Common Issues

1. **Logs directory not found**
   - The system automatically creates `./logs/` directory
   - Ensure write permissions in the project directory

2. **Configuration file not found**
   - System falls back to basic logging configuration
   - Check that `log.conf` exists in project root

3. **Permission errors**
   - Ensure the application has write access to the logs directory
   - Check file system permissions

### Debug Mode

To enable debug logging for all components, modify `log.conf`:
```ini
[logger_root]
level=DEBUG
```

Or set environment variable:
```bash
export LOG_LEVEL=DEBUG
```

## Best Practices

1. **Use appropriate log levels**:
   - DEBUG: Detailed diagnostic information
   - INFO: General operational messages
   - WARNING: Something unexpected happened
   - ERROR: Serious problem occurred
   - CRITICAL: System may be unable to continue

2. **Include context in log messages**:
   ```python
   logger.info(f"Processing message {message_id} for user {user_id}")
   ```

3. **Use structured logging for important events**:
   ```python
   log_critical_operation(logger, "USER_LOGIN", {
       "user_id": user_id,
       "timestamp": datetime.now().isoformat(),
       "ip_address": request.remote_addr
   })
   ```

4. **Don't log sensitive information**:
   - Avoid logging passwords, API keys, or personal data
   - Use redaction for sensitive fields

5. **Performance considerations**:
   - Use DEBUG level for verbose information
   - Consider log volume in high-traffic scenarios
   - Monitor log file sizes and rotation