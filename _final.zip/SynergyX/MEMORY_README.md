# SynergyX Memory Management System

## Overview

Enterprise-grade conversational memory system for SynergyX agents. Provides persistent conversation history, context management, and agent state persistence.

## Features

- **Persistent Conversations**: Store and retrieve conversation history
- **Context Management**: Automatic context building for LLMs with token limits
- **Agent State**: Persist agent-specific state across conversations
- **Auto-Summarization**: Intelligent summarization of long conversations
- **Loose Coupling**: Optional integration - existing functionality unaffected
- **Performance Optimized**: PostgreSQL with proper indexing

## Quick Setup (Docker-First)

1. **Configure Environment**:
   ```bash
   cp .env.example .env
   # Edit .env with your settings if needed
   ```

2. **Start Everything**:
   ```bash
   docker-compose up --build
   ```

That's it! The memory system will automatically:
- Start PostgreSQL with health checks
- Initialize database schema via Docker volume mount
- Start your application with memory enabled

## Configuration

Environment variables in `.env`:

```env
# Database
DB_NAME=synergyx_memory
DB_USER=postgres
DB_PASSWORD=password
DB_PORT=5432

# Memory System
MEMORY_ENABLED=true
MEMORY_MAX_MESSAGES=10
MEMORY_MAX_TOKENS=2000
MEMORY_AUTO_SUMMARIZE=true
```

## Usage

### Automatic Integration

Memory is automatically integrated into existing agents via `MemoryMixin`. No code changes required.

### Manual Usage

```python
from memory import MemoryManager

memory = MemoryManager()

# Save message
memory.save_message(
    conversation_id="conv-123",
    role="user",
    content="Hello",
    user_id="user-456",
    agent_name="assistant"
)

# Get context for LLM
context = memory.get_context_for_llm("conv-123", llm)
```

## Architecture

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   A2A Agents    │───▶│   MemoryMixin    │───▶│ MemoryManager   │
└─────────────────┘    └──────────────────┘    └─────────────────┘
                                                         │
                                                         ▼
                                               ┌─────────────────┐
                                               │   PostgreSQL    │
                                               │  - conversations │
                                               │  - messages      │
                                               │  - agent_states  │
                                               └─────────────────┘
```

## Disable Memory

Set `MEMORY_ENABLED=false` in `.env` to disable memory system completely.

## Production Considerations

1. **Database**: Use managed PostgreSQL service
2. **Connection Pooling**: Configure SQLAlchemy pool settings in `database.yaml`
3. **Monitoring**: Monitor database performance and memory usage
4. **Backup**: Regular database backups
5. **Scaling**: Consider read replicas for high-load scenarios