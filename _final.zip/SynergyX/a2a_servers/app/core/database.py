import os
import ssl
import yaml
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy.pool import QueuePool
import logging

# Disable SSL verification to prevent tiktoken SSL errors
ssl._create_default_https_context = ssl._create_unverified_context
os.environ["PYTHONHTTPSVERIFY"] = "0"
os.environ["TIKTOKEN_CACHE_DIR"] = ""

# Monkey patch tiktoken before any imports
try:
    import tiktoken
    def mock_get_encoding(name):
        return None
    tiktoken.get_encoding = mock_get_encoding
except:
    pass

logger = logging.getLogger(__name__)

Base = declarative_base()

class DatabaseManager:
    def __init__(self, config_path="agents_config/database.yaml"):
        self.engine = None
        self.SessionLocal = None
        self.config = self._load_config(config_path)
        self._initialize_engine()

    def _load_config(self, config_path):
        with open(config_path, "r") as f:
            config = yaml.safe_load(f)
        
        # Expand environment variables
        db_config = config["database"]
        for key, value in db_config.items():
            if isinstance(value, str):
                # Use os.path.expandvars for proper env var expansion
                import re
                # Handle ${VAR:-default} syntax
                def replace_env_var(match):
                    var_expr = match.group(1)
                    if ":-" in var_expr:
                        var_name, default_val = var_expr.split(":-", 1)
                        return os.getenv(var_name, default_val)
                    else:
                        return os.getenv(var_expr, "")
                
                db_config[key] = re.sub(r'\$\{([^}]+)\}', replace_env_var, value)
        
        return config

    def _initialize_engine(self):
        db_config = self.config["database"]
        
        self.engine = create_engine(
            db_config["url"],
            poolclass=QueuePool,
            pool_size=int(db_config["pool_size"]),
            max_overflow=int(db_config["max_overflow"]),
            echo=str(db_config["echo"]).lower() == "true"
        )
        
        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)
        logger.info(f"Database engine initialized: {db_config['url'].split('@')[1] if '@' in db_config['url'] else 'local'}")

    def get_session(self):
        return self.SessionLocal()

    def create_tables(self):
        from memory.models import Conversation, Message, AgentState
        Base.metadata.create_all(bind=self.engine)
        logger.info("Database tables created successfully")

    def get_memory_config(self):
        memory_config = self.config["memory"]
        # Expand environment variables for memory config
        for key, value in memory_config.items():
            if isinstance(value, str) and value.startswith("${"):
                env_expr = value[2:-1]
                if ":-" in env_expr:
                    env_var, default = env_expr.split(":-", 1)
                    memory_config[key] = os.getenv(env_var, default)
                else:
                    memory_config[key] = os.getenv(env_expr)
        
        # Convert string booleans to actual booleans
        memory_config["enabled"] = str(memory_config["enabled"]).lower() == "true"
        memory_config["auto_summarize"] = str(memory_config["auto_summarize"]).lower() == "true"
        memory_config["max_context_messages"] = int(memory_config["max_context_messages"])
        memory_config["max_context_tokens"] = int(memory_config["max_context_tokens"])
        
        return memory_config

# Global database manager instance
db_manager = None

def get_db_manager():
    global db_manager
    if db_manager is None:
        db_manager = DatabaseManager()
    return db_manager

def init_database():
    manager = get_db_manager()
    manager.create_tables()
    return manager