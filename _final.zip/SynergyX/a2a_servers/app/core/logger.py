"""
Centralized logging configuration for SynergyX
"""
import logging
import logging.config
import os
import sys
from pathlib import Path

def setup_logging(config_path: str = None, log_level: str = "INFO"):
    """
    Setup logging configuration for the application
    
    Args:
        config_path: Path to logging configuration file
        log_level: Default log level if config file not found
    """
    # Ensure logs directory exists
    logs_dir = Path("./logs")
    logs_dir.mkdir(exist_ok=True)
    print(f"[DEBUG] Created logs directory at: {logs_dir.absolute()}")
    
    # Default config path
    if config_path is None:
        config_path = Path(__file__).parent.parent.parent.parent / "log.conf"
    
    print(f"[DEBUG] Looking for config at: {config_path}")
    print(f"[DEBUG] Config exists: {os.path.exists(config_path)}")
    
    # Always use basic logging for now to ensure it works
    _setup_basic_logging(log_level)
    print(f"[DEBUG] Basic logging setup completed")

def _setup_basic_logging(log_level: str):
    """Fallback basic logging configuration"""
    # Clear any existing handlers
    root_logger = logging.getLogger()
    root_logger.handlers.clear()
    
    # Create formatter
    formatter = logging.Formatter(
        '[%(asctime)s] [%(name)s] [%(levelname)s] %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    console_handler.setLevel(logging.INFO)
    
    # File handler
    log_file = './logs/synergyx.log'
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.DEBUG)
    
    # Add handlers to root logger
    root_logger.addHandler(console_handler)
    root_logger.addHandler(file_handler)
    root_logger.setLevel(getattr(logging, log_level.upper()))
    
    print(f"[DEBUG] File handler created for: {os.path.abspath(log_file)}")
    print(f"[DEBUG] Root logger level: {root_logger.level}")
    print(f"[DEBUG] Root logger handlers: {len(root_logger.handlers)}")

def get_logger(name: str) -> logging.Logger:
    """
    Get a logger instance with the specified name
    
    Args:
        name: Logger name
        
    Returns:
        Logger instance
    """
    logger = logging.getLogger(name)
    print(f"[DEBUG] Created logger '{name}' with level: {logger.level}")
    print(f"[DEBUG] Logger '{name}' effective level: {logger.getEffectiveLevel()}")
    return logger

# Critical operation loggers
def log_critical_operation(logger: logging.Logger, operation: str, details: dict = None):
    """Log critical operations with structured data"""
    msg = f"CRITICAL_OP: {operation}"
    if details:
        msg += f" | Details: {details}"
    logger.critical(msg)

def log_security_event(logger: logging.Logger, event: str, details: dict = None):
    """Log security-related events"""
    msg = f"SECURITY: {event}"
    if details:
        msg += f" | Details: {details}"
    logger.warning(msg)

def log_performance_metric(logger: logging.Logger, metric: str, value: float, unit: str = "ms"):
    """Log performance metrics"""
    logger.info(f"PERFORMANCE: {metric}={value}{unit}")