import os

API_KEY = "sk-D83phfp7sQOC4FIk98EheQ"
EMBEDDING_MODEL = "azure/genailab-maas-text-embedding-3-large"
SMALL_LLM_MODEL = "azure_ai/genailab-maas-DeepSeek-V3-0324"
REASONING_LLM_MODEL = "azure_ai/genailab-maas-Phi-4-reasoning"
LARGE_LLM_MODEL = "azure/genailab-maas-gpt-4o"
BASE_URL = "https://genailab.tcs.in"
OLLAMA_LLM_MODEL="llama-3.2-3b-it:latest"
ENSEMBLE_LLMS = [SMALL_LLM_MODEL,REASONING_LLM_MODEL,LARGE_LLM_MODEL]
# Consortium Consistency Configuration
CONSORTIUM_SIMILARITY_THRESHOLD = float(os.getenv('CONSORTIUM_SIMILARITY_THRESHOLD', '0.5'))
CONSORTIUM_ENTROPY_THRESHOLD = float(os.getenv('CONSORTIUM_ENTROPY_THRESHOLD', '1.0'))
CONSORTIUM_STOPWORDS_FILE = os.getenv('CONSORTIUM_STOPWORDS_FILE', 'trust_layer/stopwords.json')
CONSORTIUM_ENTITY_FILTERS_FILE = os.getenv('CONSORTIUM_ENTITY_FILTERS_FILE', 'trust_layer/entity_filters.json')
