from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

HAL_DATABASE_URL = (
    "postgresql+psycopg2://hal_admin:hal_password@hal-postgres:5432/hal_db"
)

engine = create_engine(
    HAL_DATABASE_URL,
    pool_size=10,
    max_overflow=20,
    pool_pre_ping=True,
)

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
