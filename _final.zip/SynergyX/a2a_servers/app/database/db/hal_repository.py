from sqlalchemy.orm import Session
from .hal_tables import (
    conversations,
    mitigation_methods,
    hallucination_detection,
    methods,
)

# ------------------------------------------------
# Insert into conversations
# ------------------------------------------------
def insert_conversation(
    db: Session,
    conversation_id: int,
    user_message: str,
    ai_response: str,
    confidence_score: float,
    hallucination_score: float,
    critique_score: float,
    critique_verdict: str,
    completeness: str,
    sources: list,
) -> int:
    stmt = conversations.insert().values(
        conversation_id=conversation_id,
        user_message=user_message,
        ai_response=ai_response,
        confidence_score=confidence_score,
        hallucination_score=hallucination_score,
        critique_score=critique_score,
        critique_verdict=critique_verdict,
        completeness=completeness,
        sources=sources,
    ).returning(conversations.c.id)

    result = db.execute(stmt)
    db.commit()
    return result.scalar_one()


# ------------------------------------------------
# Insert into mitigation_methods
# ------------------------------------------------
def insert_mitigation_method(
    db: Session,
    conversation_db_id: int,
    technique_id: str,
    name: str,
    description: str,
    new_confidence_score: float,
):
    stmt = mitigation_methods.insert().values(
        conversation_id=conversation_db_id,
        technique_id=technique_id,
        name=name,
        description=description,
        new_confidence_score=new_confidence_score,
    )

    db.execute(stmt)
    db.commit()


# ------------------------------------------------
# Insert into hallucination_detection
# ------------------------------------------------
def insert_hallucination_detection(
    db: Session,
    conversation_db_id: int,
    detection_id: int,
    detection_method: str,
    hallucination_score: float,
    hallucination_reason: str,
    severity: str = "medium",
):
    stmt = hallucination_detection.insert().values(
        conversation_id=conversation_db_id,
        detection_id=detection_id,
        detection_method=detection_method,
        hallucination_score=hallucination_score,
        hallucination_reason=hallucination_reason,
        severity=severity,
    )

    db.execute(stmt)
    db.commit()


# ------------------------------------------------
# Methods table functions
# ------------------------------------------------
def update_methods(db: Session, method_id: int = 1, **kwargs) -> dict:
    """Update methods table columns"""
    if kwargs:
        stmt = methods.update().where(methods.c.id == method_id).values(**kwargs)
        db.execute(stmt)
        db.commit()
    return get_methods(db, method_id)


def get_methods(db: Session, method_id: int = 1) -> dict:
    """Fetch methods table columns"""
    stmt = methods.select().where(methods.c.id == method_id)
    result = db.execute(stmt).fetchone()
    if not result:
        # Create default row if doesn't exist
        stmt = methods.insert().values(id=method_id)
        db.execute(stmt)
        db.commit()
        return get_methods(db, method_id)
    return dict(result._mapping)
