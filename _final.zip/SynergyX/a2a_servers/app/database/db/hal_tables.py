from sqlalchemy import (
    Table, Column, Integer, String, Float, Text, TIMESTAMP, ForeignKey, MetaData, Boolean
)
from sqlalchemy.dialects.postgresql import JSON
from sqlalchemy.sql import func

metadata = MetaData()

conversations = Table(
    "conversations",
    metadata,
    Column("id", Integer, primary_key=True),
    Column("conversation_id", Integer, nullable=False),
    Column("user_message", Text, nullable=False),
    Column("ai_response", Text),
    Column("confidence_score", Float),
    Column("hallucination_score", Float),
    Column("critique_score", Float),
    Column("critique_verdict", Text),
    Column("completeness", Text),
    Column("sources", JSON, default=list),
    Column("created_at", TIMESTAMP(timezone=True), server_default=func.now()),
)

mitigation_methods = Table(
    "mitigation_methods",
    metadata,
    Column("id", Integer, primary_key=True),
    Column("conversation_id", Integer, ForeignKey("conversations.id"), nullable=False),
    Column("technique_id", String(255), unique=True, nullable=False),
    Column("name", String(255), nullable=False),
    Column("description", Text),
    Column("new_confidence_score", Float),
    Column("created_at", TIMESTAMP(timezone=True), server_default=func.now()),
    Column("updated_at", TIMESTAMP(timezone=True), server_default=func.now()),
)

hallucination_detection = Table(
    "hallucination_detection",
    metadata,
    Column("id", Integer, primary_key=True),
    Column("conversation_id", Integer, ForeignKey("conversations.id"), nullable=False),
    Column("detection_id", Integer),
    Column("detection_method", String(255), nullable=False),
    Column("hallucination_score", Float, nullable=False),
    Column("hallucination_reason", Text),
    Column("severity", String(50), default="medium"),
    Column("created_at", TIMESTAMP(timezone=True), server_default=func.now()),
)

methods = Table(
    "methods",
    metadata,
    Column("id", Integer, primary_key=True),
    Column("llm_eval", Boolean, default=False),
    Column("ml_eval", Boolean, default=False),
    Column("llm_judge", Boolean, default=False),
    Column("completeness_check", Boolean, default=False),
    Column("neg_kw", Boolean, default=False),
    Column("claim_ground", Boolean, default=False),
    Column("msa", Boolean, default=False),
    Column("ensemble", Boolean, default=False),
    Column("hybrid_rag", Boolean, default=False),
    Column("query_expansion", Boolean, default=False),
    Column("created_at", TIMESTAMP(timezone=True), server_default=func.now()),
    Column("updated_at", TIMESTAMP(timezone=True), server_default=func.now()),
)
