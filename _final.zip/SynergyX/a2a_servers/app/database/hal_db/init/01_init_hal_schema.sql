-- ============================================
-- Extensions
-- ============================================
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================
-- Table: conversations
-- ============================================
CREATE TABLE IF NOT EXISTS conversations (
    id SERIAL PRIMARY KEY,
    conversation_id INTEGER NOT NULL,
    user_message TEXT NOT NULL,
    ai_response TEXT,
    confidence_score DECIMAL(5,2),
    hallucination_score DECIMAL(5,2),
    critique_score DECIMAL(5,2),
    critique_verdict TEXT,
    completeness TEXT,
    sources JSON DEFAULT '[]'::json,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_conversations_conversation_id
    ON conversations(conversation_id);

CREATE INDEX IF NOT EXISTS idx_conversations_created_at
    ON conversations(created_at);

-- ============================================
-- Table: mitigation_methods
-- ============================================
CREATE TABLE IF NOT EXISTS mitigation_methods (
    id SERIAL PRIMARY KEY,
    conversation_id INTEGER NOT NULL,
    technique_id VARCHAR(255) NOT NULL UNIQUE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    new_confidence_score DECIMAL(5,2),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_mitigation_conversation
        FOREIGN KEY (conversation_id)
        REFERENCES conversations(id)
        ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_mitigation_methods_conversation_id
    ON mitigation_methods(conversation_id);

-- ============================================
-- Table: hallucination_detection
-- ============================================
CREATE TABLE IF NOT EXISTS hallucination_detection (
    id SERIAL PRIMARY KEY,
    conversation_id INTEGER NOT NULL,
    detection_id INTEGER,
    detection_method VARCHAR(255) NOT NULL,
    hallucination_score DECIMAL(5,2) NULL,
    hallucination_reason TEXT,
    severity VARCHAR(50) DEFAULT 'medium',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_hallucination_conversation
        FOREIGN KEY (conversation_id)
        REFERENCES conversations(id)
        ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_hallucination_detection_conversation_id
    ON hallucination_detection(conversation_id);

CREATE INDEX IF NOT EXISTS idx_hallucination_detection_method
    ON hallucination_detection(detection_method);

-- ============================================
-- Table: methods
-- ============================================
CREATE TABLE IF NOT EXISTS methods (
    id SERIAL PRIMARY KEY,
    llm_eval BOOLEAN DEFAULT FALSE,
    ml_eval BOOLEAN DEFAULT FALSE,
    llm_judge BOOLEAN DEFAULT FALSE,
    completeness_check BOOLEAN DEFAULT FALSE,
    neg_kw BOOLEAN DEFAULT FALSE,
    claim_ground BOOLEAN DEFAULT FALSE,
    msa BOOLEAN DEFAULT FALSE,
    ensemble BOOLEAN DEFAULT FALSE,
    hybrid_rag BOOLEAN DEFAULT FALSE,
    query_expansion BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
