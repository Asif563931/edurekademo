from langchain_openai import ChatOpenAI, OpenAIEmbeddings 
from langchain_ollama import ChatOllama
import tempfile 
import os 
import httpx 
import tiktoken 
from core.settings import API_KEY, BASE_URL, SMALL_LLM_MODEL, REASONING_LLM_MODEL, LARGE_LLM_MODEL, OLLAMA_LLM_MODEL, ENSEMBLE_LLMS
from core.logger import get_logger, log_critical_operation, log_security_event
import json

tiktoken_cache_dir = "./token"
os.environ["TIKTOKEN_CACHE_DIR"] = tiktoken_cache_dir

logger = get_logger("llm_helper")
def get_small_llm():
    """Initialize small LLM client"""
    logger.info(f"Initializing small LLM: {SMALL_LLM_MODEL}")
    log_security_event(logger, "LLM_CLIENT_INIT", {"model": SMALL_LLM_MODEL, "base_url": BASE_URL})
    
    try:
        client = httpx.Client(verify=False) 
        llm = ChatOpenAI( 
            base_url=BASE_URL, 
            model=SMALL_LLM_MODEL, 
            api_key=API_KEY, 
            http_client=client 
        )
        logger.info("Small LLM client initialized successfully")
        return llm
    except Exception as e:
        logger.error(f"Failed to initialize small LLM: {e}")
        raise

def get_reasoning_llm():
    """Initialize reasoning LLM client"""
    logger.info(f"Initializing reasoning LLM: {REASONING_LLM_MODEL}")
    log_security_event(logger, "LLM_CLIENT_INIT", {"model": REASONING_LLM_MODEL, "base_url": BASE_URL})
    
    try:
        client = httpx.Client(verify=False) 
        llm = ChatOpenAI( 
            base_url=BASE_URL, 
            model=REASONING_LLM_MODEL, 
            api_key=API_KEY, 
            http_client=client 
        )
        logger.info("Reasoning LLM client initialized successfully")
        return llm
    except Exception as e:
        logger.error(f"Failed to initialize reasoning LLM: {e}")
        raise

def get_large_llm():
    """Initialize large LLM client"""
    logger.info(f"Initializing large LLM: {LARGE_LLM_MODEL}")
    log_security_event(logger, "LLM_CLIENT_INIT", {"model": LARGE_LLM_MODEL, "base_url": BASE_URL})
    
    try:
        client = httpx.Client(verify=False) 
        llm = ChatOpenAI( 
            base_url=BASE_URL, 
            model=LARGE_LLM_MODEL, 
            api_key=API_KEY, 
            http_client=client 
        )
        logger.info("Large LLM client initialized successfully")
        log_critical_operation(logger, "LARGE_LLM_READY", {"model": LARGE_LLM_MODEL})
        return llm
    except Exception as e:
        logger.error(f"Failed to initialize large LLM: {e}")
        raise

def get_ollama_llm():
    "Initialize OLLAMA LLM"
    logger.info(f"Initialize Ollama LLM: {OLLAMA_LLM_MODEL}")
    log_security_event(logger, "LLM_CLIENT_INIT", {"model": OLLAMA_LLM_MODEL, "base_url": BASE_URL})

    try:
        llm = ChatOllama(
                model=OLLAMA_LLM_MODEL,
                temperature=0,
                # base_url="http://localhost:11434"  # Optional: Defaults to this anyway
        )
        logger.info("Ollama LLM client initialized successfully")
        log_critical_operation(logger, "OLLAMA_LLM_READY", {"model": OLLAMA_LLM_MODEL})
        return llm
    except Exception as e:
        logger.error(f"Failed to initialize Ollama LLM: {e}")
        raise

def init_ensemble_llms():
    """Initialize ensemble of different LLMs for hallucination mitigation"""
    ensemble = []
    ensemble.append(get_small_llm)
    ensemble.append(get_large_llm)
    ensemble.append(get_reasoning_llm)
    return ensemble

def _get_stopwords() -> set:
    """Get configurable stopwords from environment or config file"""
    # Try to load from config file first
    try:
        
        stopwords_file = os.getenv('CONSORTIUM_STOPWORDS_FILE', 'trust_layer/stopwords.json')
        if os.path.exists(stopwords_file):
            with open(stopwords_file, 'r') as f:
                return set(json.load(f))
    except Exception as e:
        logger.debug(f"Could not load stopwords from file: {e}")
    
    # Fallback to environment variable
    stopwords_env = os.getenv('CONSORTIUM_STOPWORDS', 'the,is,a,an,of,in,to,for,and,or,with,by,from,at,on')
    return set(word.strip() for word in stopwords_env.split(','))

def _get_entity_filters() -> set:
    """Get configurable entity filters from environment or config file"""
    # Try to load from config file first
    try:
        import json
        filters_file = os.getenv('CONSORTIUM_ENTITY_FILTERS_FILE', 'trust_layer/entity_filters.json')
        if os.path.exists(filters_file):
            with open(filters_file, 'r') as f:
                return set(json.load(f))
    except Exception as e:
        logger.debug(f"Could not load entity filters from file: {e}")
    
    # Fallback to environment variable
    filters_env = os.getenv('CONSORTIUM_ENTITY_FILTERS', 'city,country,language,programming,used,great,better,than,very,much,more,most,less,least')
    return set(word.strip() for word in filters_env.split(','))

def aggregate_responses(responses: list) -> str:
    """Aggregate multiple LLM responses using consortium consistency with semantic clustering"""
    if len(responses) == 1:
        return responses[0]
    
    import math
    from collections import defaultdict
    
    # Step 1: Semantic clustering using entity-based similarity
    clusters = defaultdict(list)
    similarity_threshold = float(os.getenv('CONSORTIUM_SIMILARITY_THRESHOLD', '0.5'))
    
    for i, response in enumerate(responses):
        response_words = set(response.lower().split())
        assigned = False
        
        # Try to assign to existing cluster
        for cluster_id, cluster_responses in clusters.items():
            cluster_words = set(cluster_responses[0].lower().split())
            
            # Focus on key content words (exclude configurable stopwords)
            common_words = _get_stopwords()
            response_key_words = response_words - common_words
            cluster_key_words = cluster_words - common_words
            
            # Check if they have conflicting key entities
            entity_filters = _get_entity_filters()
            response_entities = response_key_words - entity_filters
            cluster_entities = cluster_key_words - entity_filters
            
            # If they have different entities, don't cluster together
            conflicting_entities = (response_entities - cluster_entities) | (cluster_entities - response_entities)
            if conflicting_entities:
                similarity = 0  # Force separate clusters for conflicting entities
            else:
                # Jaccard similarity on key words
                intersection = len(response_key_words & cluster_key_words)
                union = len(response_key_words | cluster_key_words)
                similarity = intersection / union if union > 0 else 0
            
            if similarity >= similarity_threshold:
                clusters[cluster_id].append(response)
                assigned = True
                break
        
        # Create new cluster if not assigned
        if not assigned:
            clusters[len(clusters)] = [response]
    
    # Step 2: Calculate probability distribution
    total_responses = len(responses)
    cluster_probs = {}
    for cluster_id, cluster_responses in clusters.items():
        cluster_probs[cluster_id] = len(cluster_responses) / total_responses
    
    # Step 3: Calculate entropy for hallucination detection
    entropy = 0
    for p in cluster_probs.values():
        if p > 0:
            entropy -= p * math.log2(p)
    
    # Step 4: Select final answer (highest probability cluster)
    best_cluster_id = max(cluster_probs.keys(), key=lambda k: cluster_probs[k])
    final_answer = clusters[best_cluster_id][0]  # Representative from best cluster
    
    logger.info(f"Consortium consistency: {len(clusters)} clusters, entropy={entropy:.2f}, confidence={cluster_probs[best_cluster_id]:.2f}")
    
    # High entropy indicates potential hallucination
    entropy_threshold = float(os.getenv('CONSORTIUM_ENTROPY_THRESHOLD', '1.0'))
    if entropy > entropy_threshold:
        logger.warning(f"High entropy ({entropy:.2f}) detected - potential hallucination (threshold: {entropy_threshold})")
    
    return final_answer
