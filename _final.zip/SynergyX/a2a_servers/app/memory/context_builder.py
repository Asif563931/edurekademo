from typing import List, Dict, Any
from .models import Message

class ContextBuilder:
    def __init__(self, model_name="gpt-4"):
        pass

    def count_tokens(self, text: str) -> int:
        # Simple token estimation: ~4 chars per token
        return len(text) // 4

    def build_context_prompt(self, messages: List[Message], max_tokens: int = 2000) -> str:
        if not messages:
            return ""

        context_parts = []
        total_tokens = 0

        # Start from most recent messages and work backwards
        for message in reversed(messages):
            message_text = f"{message.role.upper()}: {message.content}"
            message_tokens = self.count_tokens(message_text)

            if total_tokens + message_tokens > max_tokens:
                break

            context_parts.insert(0, message_text)
            total_tokens += message_tokens

        if not context_parts:
            return ""

        context = "Previous conversation:\n" + "\n".join(context_parts) + "\n\nCurrent message:"
        return context

    def summarize_old_context(self, messages: List[Message], llm=None) -> str:
        """Summarize older messages to save token space"""
        if not messages or not llm:
            return ""

        # Take first half of messages for summarization
        mid_point = len(messages) // 2
        old_messages = messages[:mid_point]

        if not old_messages:
            return ""

        conversation_text = "\n".join([
            f"{msg.role.upper()}: {msg.content}" for msg in old_messages
        ])

        summary_prompt = f"""Summarize this conversation concisely, preserving key context and decisions:

{conversation_text}

Summary:"""

        try:
            response = llm.invoke(summary_prompt)
            return f"SUMMARY: {response.content.strip()}"
        except Exception:
            return "SUMMARY: Previous conversation context available but summarization failed."

    def build_enhanced_context(self, messages: List[Message], max_tokens: int = 2000, llm=None) -> str:
        """Build context with summarization for long conversations"""
        if not messages:
            return ""

        if len(messages) <= 5:
            return self.build_context_prompt(messages, max_tokens)

        # Try to fit recent messages first
        recent_context = self.build_context_prompt(messages[-5:], max_tokens // 2)
        recent_tokens = self.count_tokens(recent_context)

        remaining_tokens = max_tokens - recent_tokens

        if remaining_tokens > 100 and len(messages) > 5:
            # Summarize older messages
            summary = self.summarize_old_context(messages[:-5], llm)
            summary_tokens = self.count_tokens(summary)

            if summary_tokens < remaining_tokens:
                return f"{summary}\n\n{recent_context}"

        return recent_context