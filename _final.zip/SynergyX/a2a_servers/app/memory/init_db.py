#!/usr/bin/env python
"""
Database initialization script for SynergyX Memory System
"""
import os
import sys
from pathlib import Path

# Add app to path
sys.path.append(str(Path(__file__).parent.parent))

from core.database import init_database, get_db_manager
from memory.models import Base
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def init_memory_database():
    """Initialize memory database"""
    try:
        # Initialize database manager
        db_manager = init_database()
        
        if not db_manager.engine:
            logger.error("Database engine not initialized")
            return False
        
        # Create tables
        logger.info("Creating database tables...")
        Base.metadata.create_all(bind=db_manager.engine)
        logger.info("Database tables created successfully")
        
        # Optionally run SQL schema
        schema_path = Path(__file__).parent / "migrations" / "init_schema.sql"
        if schema_path.exists():
            logger.info("Running SQL schema...")
            with open(schema_path, 'r') as f:
                sql_commands = f.read()
            
            # Execute SQL commands
            with db_manager.engine.connect() as conn:
                # Split by semicolon and execute each command
                for command in sql_commands.split(';'):
                    command = command.strip()
                    if command:
                        try:
                            conn.execute(command)
                        except Exception as e:
                            logger.warning(f"SQL command failed (may be expected): {e}")
            
            logger.info("SQL schema executed")
        
        logger.info("Memory database initialized successfully")
        return True
        
    except Exception as e:
        logger.error(f"Database initialization failed: {e}")
        return False

if __name__ == "__main__":
    success = init_memory_database()
    sys.exit(0 if success else 1)