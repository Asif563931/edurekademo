import uuid
from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import desc
from core.database import get_db_manager
from .models import Conversation, Message, AgentState
from .context_builder import ContextBuilder
import logging

logger = logging.getLogger(__name__)

class MemoryManager:
    def __init__(self):
        self.db_manager = get_db_manager()
        self.memory_config = self.db_manager.get_memory_config()
        self.context_builder = ContextBuilder()

    def is_enabled(self) -> bool:
        return self.memory_config.get("enabled", True)

    def get_or_create_conversation(self, conversation_id: str, user_id: str, agent_name: str) -> Optional[Conversation]:
        if not self.is_enabled():
            return None

        session = self.db_manager.get_session()
        try:
            # Convert string ID to UUID if needed
            try:
                conv_uuid = uuid.UUID(conversation_id)
            except ValueError:
                conv_uuid = uuid.uuid5(uuid.NAMESPACE_DNS, conversation_id)
            
            # Try to find existing conversation
            conversation = session.query(Conversation).filter_by(id=conv_uuid).first()
            
            if not conversation:
                # Create new conversation
                conversation = Conversation(
                    id=conv_uuid,
                    user_id=user_id,
                    agent_name=agent_name
                )
                session.add(conversation)
                session.commit()
                logger.info(f"Created new conversation: {conversation.id}")

            return conversation
        except Exception as e:
            session.rollback()
            logger.error(f"Error creating/getting conversation: {e}")
            return None
        finally:
            session.close()

    def save_message(self, conversation_id: str, role: str, content: str, 
                    message_id: str = None, parent_message_id: str = None, 
                    user_id: str = "default", agent_name: str = "unknown") -> bool:
        if not self.is_enabled():
            return True

        session = self.db_manager.get_session()
        try:
            # Ensure conversation exists
            conversation = self.get_or_create_conversation(conversation_id, user_id, agent_name)
            if not conversation:
                return False

            # Convert conversation_id to UUID
            try:
                conv_uuid = uuid.UUID(conversation_id)
            except ValueError:
                conv_uuid = uuid.uuid5(uuid.NAMESPACE_DNS, conversation_id)
            
            # Create message
            message = Message(
                conversation_id=conv_uuid,
                role=role,
                content=content,
                message_id=message_id,
                parent_message_id=parent_message_id
            )
            
            session.add(message)
            session.commit()
            logger.debug(f"Saved message: {role} in conversation {conversation_id}")
            return True

        except Exception as e:
            session.rollback()
            logger.error(f"Error saving message: {e}")
            return False
        finally:
            session.close()

    def get_conversation_history(self, conversation_id: str, limit: int = None) -> List[Message]:
        if not self.is_enabled():
            return []

        session = self.db_manager.get_session()
        try:
            # Convert conversation_id to UUID
            try:
                conv_uuid = uuid.UUID(conversation_id)
            except ValueError:
                conv_uuid = uuid.uuid5(uuid.NAMESPACE_DNS, conversation_id)
            
            query = session.query(Message).filter_by(conversation_id=conv_uuid)
            query = query.order_by(Message.created_at)
            
            if limit:
                # Get the most recent messages
                query = query.order_by(desc(Message.created_at)).limit(limit)
                messages = query.all()
                messages.reverse()  # Return in chronological order
            else:
                messages = query.all()

            return messages

        except Exception as e:
            logger.error(f"Error getting conversation history: {e}")
            return []
        finally:
            session.close()

    def get_context_for_llm(self, conversation_id: str, llm=None) -> str:
        if not self.is_enabled():
            return ""

        max_messages = self.memory_config.get("max_context_messages", 10)
        max_tokens = self.memory_config.get("max_context_tokens", 2000)
        auto_summarize = self.memory_config.get("auto_summarize", True)

        messages = self.get_conversation_history(conversation_id, limit=max_messages)
        
        if not messages:
            return ""

        if auto_summarize and llm:
            return self.context_builder.build_enhanced_context(messages, max_tokens, llm)
        else:
            return self.context_builder.build_context_prompt(messages, max_tokens)

    def save_agent_state(self, conversation_id: str, agent_name: str, state_data: Dict[str, Any]) -> bool:
        if not self.is_enabled():
            return True

        session = self.db_manager.get_session()
        try:
            # Convert conversation_id to UUID
            try:
                conv_uuid = uuid.UUID(conversation_id)
            except ValueError:
                conv_uuid = uuid.uuid5(uuid.NAMESPACE_DNS, conversation_id)
            
            # Check if state exists
            agent_state = session.query(AgentState).filter_by(
                conversation_id=conv_uuid,
                agent_name=agent_name
            ).first()

            if agent_state:
                agent_state.state_data = state_data
            else:
                agent_state = AgentState(
                    conversation_id=conv_uuid,
                    agent_name=agent_name,
                    state_data=state_data
                )
                session.add(agent_state)

            session.commit()
            return True

        except Exception as e:
            session.rollback()
            logger.error(f"Error saving agent state: {e}")
            return False
        finally:
            session.close()

    def get_agent_state(self, conversation_id: str, agent_name: str) -> Dict[str, Any]:
        if not self.is_enabled():
            return {}

        session = self.db_manager.get_session()
        try:
            # Convert conversation_id to UUID
            try:
                conv_uuid = uuid.UUID(conversation_id)
            except ValueError:
                conv_uuid = uuid.uuid5(uuid.NAMESPACE_DNS, conversation_id)
            
            agent_state = session.query(AgentState).filter_by(
                conversation_id=conv_uuid,
                agent_name=agent_name
            ).first()

            return agent_state.state_data if agent_state else {}

        except Exception as e:
            logger.error(f"Error getting agent state: {e}")
            return {}
        finally:
            session.close()

    def clear_conversation(self, conversation_id: str) -> bool:
        if not self.is_enabled():
            return True

        session = self.db_manager.get_session()
        try:
            # Convert conversation_id to UUID
            try:
                conv_uuid = uuid.UUID(conversation_id)
            except ValueError:
                conv_uuid = uuid.uuid5(uuid.NAMESPACE_DNS, conversation_id)
            
            conversation = session.query(Conversation).filter_by(id=conv_uuid).first()
            if conversation:
                session.delete(conversation)
                session.commit()
                logger.info(f"Cleared conversation: {conversation_id}")
            return True

        except Exception as e:
            session.rollback()
            logger.error(f"Error clearing conversation: {e}")
            return False
        finally:
            session.close()