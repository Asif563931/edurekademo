"""
Memory Mixin for A2A Agents
Provides optional memory capabilities without breaking existing functionality
"""
from typing import Optional, Dict, Any
from .manager import MemoryManager
import logging

logger = logging.getLogger(__name__)

class MemoryMixin:
    """
    Mixin class to add memory capabilities to existing agents
    Can be mixed into any agent class without breaking existing functionality
    """
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._memory_manager: Optional[MemoryManager] = None
        self._memory_enabled = False
        self._init_memory()
    
    def _init_memory(self):
        """Initialize memory manager if enabled"""
        try:
            self._memory_manager = MemoryManager()
            self._memory_enabled = self._memory_manager.is_enabled()
            if self._memory_enabled:
                logger.info(f"Memory enabled for agent: {getattr(self, 'agent_card', {}).get('name', 'unknown')}")
            else:
                logger.debug("Memory disabled via configuration")
        except Exception as e:
            logger.warning(f"Memory initialization failed: {e}")
            self._memory_enabled = False
    
    def _save_message_to_memory(self, conversation_id: str, role: str, content: str, 
                               message_id: str = None, parent_message_id: str = None,
                               user_id: str = "default") -> bool:
        """Save message to memory if enabled"""
        if not self._memory_enabled or not self._memory_manager:
            return True
        
        agent_name = getattr(self, 'agent_card', {}).get('name', 'unknown')
        return self._memory_manager.save_message(
            conversation_id=conversation_id,
            role=role,
            content=content,
            message_id=message_id,
            parent_message_id=parent_message_id,
            user_id=user_id,
            agent_name=agent_name
        )
    
    def _get_conversation_context(self, conversation_id: str, llm=None) -> str:
        """Get conversation context for LLM if memory enabled"""
        if not self._memory_enabled or not self._memory_manager:
            return ""
        
        return self._memory_manager.get_context_for_llm(conversation_id, llm)
    
    def _save_agent_state(self, conversation_id: str, state_data: Dict[str, Any]) -> bool:
        """Save agent state if memory enabled"""
        if not self._memory_enabled or not self._memory_manager:
            return True
        
        agent_name = getattr(self, 'agent_card', {}).get('name', 'unknown')
        return self._memory_manager.save_agent_state(conversation_id, agent_name, state_data)
    
    def _get_agent_state(self, conversation_id: str) -> Dict[str, Any]:
        """Get agent state if memory enabled"""
        if not self._memory_enabled or not self._memory_manager:
            return {}
        
        agent_name = getattr(self, 'agent_card', {}).get('name', 'unknown')
        return self._memory_manager.get_agent_state(conversation_id, agent_name)
    
    @property
    def memory_enabled(self) -> bool:
        """Check if memory is enabled"""
        return self._memory_enabled