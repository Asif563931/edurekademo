from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional

class RAGChunk(BaseModel):
    content: str
    source: str
    similarity_score: float
    metadata: Dict[str, Any]

class CustomState(BaseModel):
    user_query: str
    rag_chunks: List[RAGChunk] = Field(default_factory=list)
    final_llm_answer: Optional[str] = None
    confidence_score: Optional[float] = None
