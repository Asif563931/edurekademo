#!/usr/bin/env python
"""
Dynamic Agent Registry + Runtime Agent Builder
Supports:
- YAML-driven dynamic agent creation
- YAML-driven intent extraction
- MCP Client initialization per agent (not stored in capabilities)
- A2A LLM router agent for intent routing
- File/console logging via core.logger
"""

import sys
import time
import threading
import argparse
import re
import yaml
import asyncio
from typing import Optional, AsyncGenerator, Dict, Any, List
import requests
import os
from langgraph.prebuilt import create_react_agent
from inspect import iscoroutine
from python_a2a import AgentCard, BaseA2AServer, A2AServer, run_server, Message, TextContent, MessageRole
from python_a2a.discovery import AgentRegistry, run_registry, enable_discovery

from langchain_core.prompts import PromptTemplate
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain.agents import create_agent

from helpers.get_llm import get_large_llm, get_small_llm
from core.logger import setup_logging, get_logger, log_critical_operation, log_performance_metric
from langchain_core.messages import BaseMessage, messages_to_dict
from memory.memory_mixin import MemoryMixin
import json
import logging
from helpers.get_llm import init_ensemble_llms, aggregate_responses
from common import detect_output_type
from database.db.hal_repository import get_methods
from database.db.hal_db import SessionLocal
from database.db.hal_repository import (
    insert_conversation,
    insert_mitigation_method,
    insert_hallucination_detection,
)


# -------------------------------
# Logger setup
# -------------------------------
setup_logging()
logger = get_logger("a2a_server")

logger.info("Starting A2A-Server (A2A)")
logger.info(f"Python {sys.version.split()[0]} | Process ID: {os.getpid()}")
log_critical_operation(logger, "A2A_SERVER_STARTUP", {"pid": os.getpid(), "python_version": sys.version.split()[0]})

async def stream_llm_chunks(llm, mcp_tools, system_prompt: str, query: str):
    """
    Creates the agent and streams raw text chunks.
    This isolates the astream() logic.
    """
    agent = create_agent(
        llm,
        tools=mcp_tools,
        system_prompt=system_prompt
    )
    print("IM INSIDE stream_llm_chunks...............")
    raw_stream = await agent.astream(
        {"messages": [{"role": "user", "content": query}]},
        stream_mode="messages"
    )
    stream = ensure_async_iterable(raw_stream)
    async for event in stream:
        text_chunk = ""

        # extract content from event
        try:
            if isinstance(event, dict) and "messages" in event and len(event["messages"]) > 0:
                text_chunk = event["messages"][-1].get("content", "") or ""
            elif isinstance(event, str):
                text_chunk = event
        except Exception:
            text_chunk = ""

        if text_chunk:
            print("CHUNK YIELD...............",text_chunk)
            yield text_chunk

def extract_message_text(msg):
    if msg is None:
        return ""

    # LangChain BaseMessage
    if hasattr(msg, "content"):
        content = msg.content
    else:
        content = msg

    # If content is list (tool outputs often are)
    if isinstance(content, list):
        parts = []
        for c in content:
            if isinstance(c, str):
                parts.append(c)
            elif isinstance(c, dict):
                parts.append(json.dumps(c, ensure_ascii=False))
            else:
                parts.append(str(c))
        return "\n".join(parts)

    # If dict
    if isinstance(content, dict):
        return json.dumps(content, ensure_ascii=False)

    return str(content)



def ensure_async_iterable(obj):
    # Case 1: already async generator/iterator
    if hasattr(obj, "__aiter__"):
        return obj

    # Case 2: coroutine returning something
    async def wrap_coroutine():
        result = await obj
        # Recursively normalize
        async for x in ensure_async_iterable(result):
            yield x
    if asyncio.iscoroutine(obj):
        return wrap_coroutine()

    # Case 3: synchronous iterables (list / generator / etc.)
    if hasattr(obj, "__iter__"):
        async def iterate_sync():
            for x in obj:
                yield x
        return iterate_sync()

    # Case 4: raw strings
    async def single_yield():
        yield obj
    return single_yield()



def to_json_safe(data):
    """Convert LangChain Message objects and nested structures to JSON-safe dicts."""
    if isinstance(data, BaseMessage):
        return messages_to_dict([data])[0]

    if isinstance(data, dict):
        safe = {}
        for k, v in data.items():
            safe[k] = to_json_safe(v)
        return safe

    if isinstance(data, list):
        return [to_json_safe(i) for i in data]

    return data  # primitive types stay unchanged



# ===================================================================
# YAML Loader
# ===================================================================
def load_config(config_path: str) -> dict:
    """Load YAML configuration file"""
    logger.info(f"Loading configuration from: {config_path}")
    try:
        with open(config_path, "r") as f:
            config = yaml.safe_load(f)
        logger.info("Configuration loaded successfully")
        return config
    except Exception as e:
        logger.exception("Failed to load configuration")
        raise

# ===================================================================
# MCP Client Loader
# ===================================================================
async def initialize_mcp(mcp_cfg: dict, yaml_tools_list: List[Dict[str, Any]]):
    """
    Initialize MCP client for a specific agent using MCP server URL.
    Return:
        mcp_client, yaml_tools_list, remote_tools
    """
    url = (mcp_cfg or {}).get("url")
    if not url:
        logger.debug("YAML has no MCP URL → MCP disabled for agent")
        return None, yaml_tools_list, []

    logger.info(f"Initializing MCP client with URL: {url}")
    try:
        mcp_client = MultiServerMCPClient({
            "mcp_server": {
                "url": url,
                "transport": "sse"
            }
        })
    except Exception as e:
        logger.exception("Failed to create MCP client instance")
        return None, yaml_tools_list, []

    remote_tools = []
    try:
        start_time = time.time()
        remote_tools = await mcp_client.get_tools()
        load_time = (time.time() - start_time) * 1000
        log_performance_metric(logger, "mcp_tools_load_time_ms", load_time)
        logger.info(f"TOOL format: {remote_tools[0]}]")
        logger.info(f"Successfully loaded {len(remote_tools)} MCP tools from {url}")
    except Exception as e:
        logger.exception("MCP tool load failed")
        remote_tools = []

    return mcp_client, yaml_tools_list, remote_tools

# ===================================================================
# Intent Extraction
# ===================================================================
def extract_intents_from_yaml(config: dict) -> List[str]:
    """Extract intents from YAML configuration"""
    intents = set()
    agent_count = len(config.get("agents", []))
    logger.debug(f"Extracting intents from {agent_count} agents")

    for ag in config.get("agents", []):
        skills = ag.get("skills", [])
        for skill in skills:
            if isinstance(skill, dict):
                intents.add(skill["name"].lower())
            else:
                intents.add(skill.lower())

    intents.add("general")
    intent_list = sorted(intent for intent in intents if intent)
    logger.info(f"Extracted intents: {intent_list}")
    return intent_list

# ===================================================================
# Build intent prompt
# ===================================================================
def build_intent_prompt(config: dict) -> PromptTemplate:
    agents_info = ""
    for ag in config.get("agents", []):
        name = ag.get("name", "")
        desc = ag.get("description", "")
        skills = [s if isinstance(s, str) else s.get("name", "") for s in ag.get("skills", [])]
        skill_str = ", ".join(skills)
        agents_info += f"- {name}:\n    Description: {desc}\n    Skills: {skill_str}\n"

    template = f"""
You classify user queries into intents.

Use these agents' descriptions and skills:

{agents_info}

Reply ONLY with the intent (lowercase). If unsure, reply "general".

User query: {{query}}
"""
    return PromptTemplate.from_template(template)

# ===================================================================
# LLM router agent
# ===================================================================
class A2ALLMAgent(A2AServer):
    
    def __init__(self, agent_card: AgentCard, full_yaml_config: dict):
        super().__init__(agent_card) 
        self.registry_yaml = full_yaml_config
        self.intents = extract_intents_from_yaml(full_yaml_config)
        self.llm = get_small_llm()
        self.intent_prompt = build_intent_prompt(full_yaml_config)

    def classify_intent(self, query: str) -> str:
        logger.debug("Classifying intent for query (truncated): %s", query[:120])
        start = time.time()
        try:
            logger.info(f"Prompt: {self.intent_prompt.format(query=query)}")
            resp = self.llm.invoke(self.intent_prompt.format(query=query))
            raw = resp.content.strip().lower()
            duration_ms = (time.time() - start) * 1000
            log_performance_metric(logger, "intent_classification_ms", duration_ms)
            logger.info(f"SELFFFFFF: {self.intents}")
            intent = raw if raw in self.intents else "general"
            logger.info(f"Intent classified: {intent} (raw: {raw})")
            return intent
        except Exception as e:
            logger.exception("Intent classification failed")
            return "general"

    def pick_agent(self, intent: str):
        logger.debug("Selecting agent for intent: %s", intent)
        for ag in self.registry_yaml.get("agents", []):
            names = [s if isinstance(s, str) else s.get("name", "") for s in ag.get("skills", [])]
            if intent in [n.lower() for n in names]:
                logger.info("Selected agent %s for intent %s", ag.get("name"), intent)
                return ag
        logger.warning("No agent matched the intent: %s", intent)
        return None

    def handle_message(self, message: Message) -> Message:
        query = message.content.text if hasattr(message.content, "text") else ""
        logger.info("A2A LLM router handling message id=%s", message.message_id)
        intent = self.classify_intent(query)
        selected = self.pick_agent(intent)

        if not selected:
            resp_text = f"Intent detected: {intent} → No matching agent found."
            logger.warning("No matching agent for intent %s", intent)
        else:
            resp_text = f"Intent detected: {intent}"
            log_critical_operation(logger, "AGENT_SELECTED", {
                "intent": intent,
                "agent": selected.get("name"),
                "message_id": message.message_id
            })

        return Message(
            content=TextContent(text=resp_text),
            role=MessageRole.AGENT,
            parent_message_id=message.message_id,
            conversation_id=message.conversation_id
        )

# ===================================================================
# Generic Agent with MCP client
# ===================================================================
class GenericAgent(MemoryMixin, A2AServer):
    def __init__(self, card: AgentCard, mcp_client=None, yaml_tools_list=None, mcp_tools=None):
        super().__init__(card) 
        self.mcp_client = mcp_client
        self.yaml_tools_list = yaml_tools_list or []
        self.mcp_tools = mcp_tools or []

        # If MCP client exists, filter MCP tools to only those present in YAML
        if self.mcp_client:
            #logger.info(" Agent %s mcp tools are: %s", self.agent_card.name, self.mcp_tools)
            yaml_tool_names = [t.get("name") if isinstance(t, dict) else str(t) for t in self.yaml_tools_list]
            logger.info(" Agent %s after filter: %s", self.agent_card.name, yaml_tool_names)
            filtered_tools = []
            for t in self.mcp_tools:
                #logger.info(" Agent %s for tool %s: ", self.agent_card.name, t)
                logger.info(" Agent %s after filter type of t: %s", self.agent_card.name, type(t))
                t_name = t.get("name") if isinstance(t, dict) else str(t)
                logger.info(" Agent %s after filter type of t_name: %s", self.agent_card.name, type(t_name))
                match = re.search(r"name='([^']+)'", t_name)
                if match:
                    name_value = match.group(1)
                    logger.info(" After match Agent %s after filter type of t_name: %s", self.agent_card.name, name_value)
                    if name_value in yaml_tool_names:
                        logger.info(" Agent %s for tool %s: ", self.agent_card.name, name_value)
                        filtered_tools.append(t)
            self.mcp_tools = filtered_tools
        else:
            # No MCP client → use YAML tools directly
            logger.info(" Agent %s YAML tools are: %s", self.agent_card.name, self.yaml_tools_list)
            self.mcp_tools = [
                t if isinstance(t, dict) else {"name": t} for t in self.yaml_tools_list
            ]

        self.llm = get_large_llm()
        caps = getattr(self.agent_card, "capabilities", {}) or {}
        self.ensemble_enabled = caps.get("ensemble_enabled", False)
        self.ensemble_llms = init_ensemble_llms() if self.ensemble_enabled else [self.llm]
        logger.info("self.ensemble_enabled for agent is  %s", self.ensemble_enabled)
        self.request_count = 0
        self.total_tokens = 0

    def _get_system_prompt(self,check) -> str:
        caps = getattr(self.agent_card, "capabilities", {}) or {}
        if check:
            sp = caps.get("system_prompt")
        else:
            sp = caps.get("system_prompt_normal")
        return sp

    def handle_message(self, message: Message) -> Message:
        user_text = message.content.text if hasattr(message.content, "text") else ""
        logger.info("GenericAgent '%s' handling message id=%s", self.agent_card.name, message.message_id)
        db = SessionLocal()
        methods_config = get_methods(db)
        check = methods_config.get('msa', False)
        check = True
        logger.info("GenericAgent '%s' check of msa is %s", self.agent_card.name, check)

        # Save user message to memory
        if hasattr(message, 'conversation_id') and message.conversation_id:
            self._save_message_to_memory(
                conversation_id=message.conversation_id,
                role="user",
                content=user_text,
                message_id=message.message_id,
                parent_message_id=getattr(message, 'parent_message_id', None)
            )
        
        # Get conversation context if memory enabled
        context = ""
        if hasattr(message, 'conversation_id') and message.conversation_id:
            context = self._get_conversation_context(message.conversation_id, self.llm)
            if context:
                logger.debug("Using conversation context: %s", context[:100])
        result_text = ""
        for tool in self.mcp_tools:
            logger.info("GenericAgent '%s' type of tool=%s", self.agent_card.name, type(tool))
        if self.mcp_tools:
            logger.info("Using tools: %s", [t.get("name") if isinstance(t, dict) else str(t) for t in self.mcp_tools])
        else:
            logger.info("No tools available for agent %s", self.agent_card.name)

        system_prompt = self._get_system_prompt(check)
        logger.info(system_prompt)
        
        try:
            #loop = asyncio.new_event_loop()
            #asyncio.set_event_loop(loop)
            if methods_config.get('ensemble', False):
                check = True
                system_prompt = self._get_system_prompt(check)
                async def run_ensemble_agents():
                    responses = []
                    for llm in self.ensemble_llms:
                        try:
                            agent = create_agent(self.llm, tools=self.mcp_tools, system_prompt=system_prompt)
                            resp = await agent.ainvoke({"messages": [{"role": "user", "content": user_text}]})
                            
                            responses.append(resp)
                        except Exception as e:
                            logger.warning(f"LLM in ensemble failed: {e}")
                    return responses
                ensemble_responses = asyncio.run(run_ensemble_agents())
                logger.info("ENSAMBLEEEEEEEEEEEEEEEEEEE: %s",ensemble_responses)
                resp = aggregate_responses(ensemble_responses) if ensemble_responses else "No valid responses"
                logger.info("ENSAMBLEEEEEEEEEEEEEEEEEEE Answer: %s",resp)
            else:
                async def run_agent_once():
                    agent = create_agent(
                        self.llm,
                        tools=self.mcp_tools,
                        system_prompt=system_prompt
                    )
                    resp = await agent.ainvoke({"messages": [{"role": "user", "content": user_text}]})
                    print("Handle Messagess :",resp["messages"])
                    return resp
                resp = asyncio.run(run_agent_once())


            if not resp or "messages" not in resp or not resp["messages"]:
                result_text = "Data is not available."

            if isinstance(resp, dict) and "messages" in resp and resp["messages"]:
                last_msg = resp["messages"][-1]
                result_text = extract_message_text(last_msg)
            else:
                result_text = str(resp)
            logger.info("GenericAgent result (truncated): %s", (result_text or ""))

        except Exception as e:
            logger.exception("Error invoking agent (sync path)")
            result_text = f"Error while processing request: {str(e)}"

        response_text = result_text

        return Message(
            content=TextContent(text=str(response_text)),
            role=MessageRole.AGENT,
            parent_message_id=message.message_id,
            conversation_id=message.conversation_id
        )



    async def stream_response(self, message: Message) -> AsyncGenerator[str, None]:
        """
        Stream a response from the LLM provider (async generator).
        Yields plain text chunks as strings.
        """
        self.request_count += 1
        request_id = self.request_count
        query = message.content.text if hasattr(message.content, "text") else ""
        logger.info("Streaming response for request #%d (agent=%s)", request_id, self.agent_card.name)

        system_prompt = self._get_system_prompt()
        token_count = 0

        try:
            # delegate streaming to the new helper function
            async for text_chunk in stream_llm_chunks(
                self.llm,
                self.mcp_tools,
                system_prompt,
                query
            ):
                token_count += 1
                self.total_tokens += 1

                # occasional debug logs
                if token_count <= 3 or token_count % 25 == 0:
                    logger.debug(
                        "Agent %s: token %d chunk (truncated): %s",
                        self.agent_card.name,
                        token_count,
                        text_chunk[:120]
                    )

                # yield the chunk up to the caller
                yield text_chunk

            logger.info("Streaming complete for request #%d: %d tokens", request_id, token_count)

        except Exception as e:
            logger.exception("Error during streaming response")
            yield f"Error during streaming: {str(e)}"

# ===================================================================
# Start registry
# ===================================================================
def start_registry(config: dict, ready_event: Optional[threading.Event] = None):
    """Start the agent registry service"""
    reg_cfg = config["registry"]
    logger.info("Starting registry: %s on port %s", reg_cfg.get("name"), reg_cfg.get("port"))
    log_critical_operation(logger, "REGISTRY_STARTUP", {"name": reg_cfg.get("name"), "port": reg_cfg.get("port")})

    registry = AgentRegistry(name=reg_cfg.get("name"), description=reg_cfg.get("description"))
    if ready_event:
        ready_event.set()

    try:
        run_registry(registry, host="0.0.0.0", port=reg_cfg.get("port"), debug=False)
    except Exception:
        logger.exception("Registry startup failed")
        raise

# ===================================================================
# Start dynamic agent
# ===================================================================
def start_dynamic_agent(agent_cfg: dict, registry_port: int, full_yaml: dict, ready_event=None):
    name = agent_cfg.get("name")
    port = agent_cfg.get("port")
    desc = agent_cfg.get("description", "")
    version = agent_cfg.get("version", "1.0.0")

    # copy base capabilities and inject supports_system_prompt if present in YAML (default True)
    base_capabilities = dict(agent_cfg.get("capabilities", {}) or {})
    supports_sys = agent_cfg.get("supports_system_prompt", True)
    base_capabilities["supports_system_prompt"] = bool(supports_sys)

    # attach system_prompt if provided (or leave default)
    if "system_prompt" in agent_cfg:
        base_capabilities["system_prompt"] = agent_cfg["system_prompt"]
    else:
        base_capabilities.setdefault("system_prompt", "Strictly use the available tools. Do not answer outside of them.")

    # build skills metadata
    skills = []
    for s in agent_cfg.get("skills", []):
        if isinstance(s, dict):
            skills.append(s)
        else:
            skills.append({"name": s, "intent": s, "pattern": s})

    # create AgentCard (do not store mcp tools in capabilities)
    card = AgentCard(
        name=name,
        description=desc,
        url=f"http://localhost:{port}",
        version=version,
        capabilities={
            **base_capabilities,
            "skills": skills,
            "skill_names": [s["name"] for s in skills],
            "intents": [s.get("intent", s["name"]) for s in skills]
        }
    )

    # initialize MCP (non-blocking attempt using limited loop)
    mcp_cfg = agent_cfg.get("mcp_server", {}) or {}
    yaml_tools = agent_cfg.get("tools", []) or []

    mcp_client = None
    mcp_tools = []
    yaml_tools_list = yaml_tools

    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        mcp_client, yaml_tools_list, mcp_tools = loop.run_until_complete(initialize_mcp(mcp_cfg, yaml_tools_list))
        loop.close()
    except Exception:
        logger.exception("MCP init failed for agent %s", name)
        mcp_client, yaml_tools_list, mcp_tools = None, yaml_tools_list, []

    agent = None
    # instantiate agent (LLM router vs generic)
    if "llm" in (name or "").lower():
        agent = A2ALLMAgent(card, full_yaml)
    elif "orchestrator" not in (name or "").lower():
        agent = GenericAgent(card, mcp_client=mcp_client, yaml_tools_list=yaml_tools_list, mcp_tools=mcp_tools)
    else:
        logger.info("Skipping agent startup in this script for agent %s", name)

    if agent:
        # register for discovery
        registry_url = f"http://localhost:{registry_port}"
        enable_discovery(agent, registry_url=registry_url)

        if ready_event:
            ready_event.set()

        # run server for this agent (blocks inside thread)
        try:
            run_server(agent, host="0.0.0.0", port=port)
        except Exception:
            logger.exception("Failed to run agent server for %s:%s", name, port)
            raise

# ===================================================================
# List agents (helper)
# ===================================================================
def list_agents(registry_port: int):
    try:
        resp = requests.get(f"http://localhost:{registry_port}/registry/agents", timeout=5)
        agents = resp.json()
        logger.info("Registered Agents:")
        for a in agents:
            logger.info("- %s (%s)", a.get("name"), a.get("url"))
    except Exception:
        logger.exception("Failed to list agents from registry")

# ===================================================================
# Main
# ===================================================================
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, default="agents_config/agents.yaml")
    #parser.add_argument("--intent_risk_config", type=str, default="agents_config/intent_risk_map.yaml")
    # 🔹 NEW: intent risk config
    #parser.add_argument(
    #    "--intent-risk-config",
    #    type=str,
    #    default="agents_config/intent_risk.yaml",
    #    help="Path to intent risk policy YAML"
    #)

    args = parser.parse_args()

    # -------------------------------
    # Load main agent config
    # -------------------------------
    full_yaml = load_config(args.config)
    reg_port = full_yaml["registry"]["port"]

    # -------------------------------
    # 🔹 NEW: Load intent risk config
    # -------------------------------
    #intent_risk_cfg = load_intent_risk_config(args.intent_risk_config)

    # Optional: store it in main config for downstream use
    #full_yaml["intent_risk"] = intent_risk_cfg

    #logger.info(
    #    "Intent risk policy loaded: domain=%s, version=%s",
    #    intent_risk_cfg.get("domain"),
    #    intent_risk_cfg.get("version")
    #)

    # -------------------------------
    # Start registry
    # -------------------------------
    registry_ready = threading.Event()
    threading.Thread(
        target=start_registry,
        args=(full_yaml, registry_ready),
        daemon=True
    ).start()
    registry_ready.wait(timeout=10)
    time.sleep(1)

    # -------------------------------
    # Start dynamic agents
    # -------------------------------
    threads = []
    events = []
    for cfg in full_yaml.get("agents", []):
        e = threading.Event()
        events.append(e)
        t = threading.Thread(
            target=start_dynamic_agent,
            args=(cfg, reg_port, full_yaml, e),
            daemon=True
        )
        threads.append(t)
        t.start()

    # wait for agent threads to signal readiness (best-effort)
    for e in events:
        e.wait(timeout=10)

    logger.info(
        "All agents running (or started). Registry at http://localhost:%s",
        reg_port
    )
    list_agents(reg_port)

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        logger.info("Shutting down…")


if __name__ == "__main__":
    sys.exit(main())

