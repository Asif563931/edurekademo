import json
import re


def extract_answer_and_confidence(llm_answer):
    """
    Extracts answer and confidence_score from LLM output.
    Falls back safely if output is not valid JSON.
    """
    answer = ""
    confidence_score = 0.0

    if isinstance(llm_answer, (dict, list)):
        answer = llm_answer.get("answer", "")
        confidence_score = float(llm_answer.get("confidence_score", 0.0))
        return answer, confidence_score

    if isinstance(llm_answer, str):
        try:
            parsed = json.loads(llm_answer)
            answer = parsed.get("answer", "")
            confidence_score = float(parsed.get("confidence_score", 0.0))
        except (ValueError, TypeError):
            # Fallback: treat entire output as answer
            answer = llm_answer
            confidence_score = 0.0

    return answer, confidence_score

def detect_output_type(value):
    """
    Returns one of:
    - 'json_object'  → dict or list
    - 'json_string'  → string containing valid JSON
    - 'string'       → normal string
    - 'unknown'
    """
    if isinstance(value, (dict, list)):
        return "json_object"

    if isinstance(value, str):
        try:
            json.loads(value)
            return "json_string"
        except json.JSONDecodeError:
            return "string"

    return "unknown"

def normalize_response_text(result_text) -> str:
    """
    Guarantees a STRING output suitable for A2A transport.
    """
    if isinstance(result_text, (dict, list)):
        return json.dumps(
            result_text,
            ensure_ascii=False,
            separators=(",", ":"),
        )

    if isinstance(result_text, str):
        try:
            json.loads(result_text)
            return result_text  # valid JSON string
        except json.JSONDecodeError:
            return result_text  # plain string

    # Absolute fallback (should never happen)
    return str(result_text)



import json
from typing import Any


def _to_text(obj: Any) -> str:
    """
    Convert any object into a safe string representation.
    This prevents A2A/orchestrator crashes due to non-string joins.
    """
    if obj is None:
        return ""

    if isinstance(obj, str):
        return obj

    if isinstance(obj, dict):
        return json.dumps(obj, indent=2, ensure_ascii=False)

    if isinstance(obj, list):
        return "\n".join(_to_text(item) for item in obj)

    # Fallback for custom objects
    try:
        return str(obj)
    except Exception:
        return repr(obj)


def build_final_response(
    final_llm_answer: str,
    confidence_score: float,
    validation: dict,
    metrics,
    trace
) -> str:
    lines: list[str] = []

    # --------------------------------------------------
    # Main Answer
    # --------------------------------------------------
    lines.append(_to_text(final_llm_answer).strip())

    # --------------------------------------------------
    # Confidence
    # --------------------------------------------------
    lines.append("\n---")
    lines.append(f"🧠 **Agent Confidence Score:** {confidence_score:.2f}")

    # --------------------------------------------------
    # Claim Grounding Analysis
    # --------------------------------------------------
    lines.append("\n📊 **Claim Grounding Analysis:**")

    claim_results = validation.get("claim_results", [])
    if not claim_results:
        lines.append("- ⚠️ No claims extracted for validation.")
    else:
        for r in claim_results:
            supported = bool(r.get("supported"))
            status = "✅ Supported" if supported else "❌ Not Supported"
            src = r.get("source") or "N/A"
            conf = r.get("confidence", "N/A")
            claim = r.get("claim", "")

            lines.append(
                f"- {status} | Confidence: {conf} | Source: {src}\n"
                f"  ↳ Claim: {_to_text(claim)}"
            )

    # --------------------------------------------------
    # Execution Metrics
    # --------------------------------------------------
    lines.append("\n📈 **Execution Metrics:**")
    try:
        metrics_out = metrics.report()
        lines.append(_to_text(metrics_out))
    except Exception as e:
        lines.append(f"⚠️ Metrics unavailable: {str(e)}")

    # --------------------------------------------------
    # Execution Trace
    # --------------------------------------------------
    lines.append("\n🧭 **Execution Trace:**")
    try:
        trace_out = trace.end()
        lines.append(_to_text(trace_out))
    except Exception as e:
        lines.append(f"⚠️ Trace unavailable: {str(e)}")

    # --------------------------------------------------
    # Final Assembly (SAFE)
    # --------------------------------------------------
    return "\n".join(lines)

