#!/usr/bin/env python
"""
A2A Orchestrator Agent
Acts as a control-plane A2A agent responsible for:
- PII validation
- Intent classification
- Routing to domain agents
"""

import re
import requests
import json
from typing import Optional, Dict, Any, List
import uuid
import random
from database.db.hal_repository import get_methods
from database.db.hal_db import SessionLocal
from database.db.hal_repository import (
    insert_conversation,
    insert_mitigation_method,
    insert_hallucination_detection,
)


from python_a2a import (
    AgentCard,
    A2AServer,
    Message,
    TextContent,
    MessageRole
)

from trust_layer.detectors import TransformerDetector
from python_a2a.discovery import enable_discovery
from python_a2a import A2AClient
from trust_layer.observability.metrics import Metrics
from trust_layer.observability.traces import Trace
from trust_layer.methods.negative_knowledge import NegativeKnowledgeInjector
from trust_layer.methods.multi_sample_agreement import MultiSampleAgreement
from trust_layer.methods.claim_grounding import ClaimGroundingValidator
from src.common import build_final_response, detect_output_type,extract_answer_and_confidence
from helpers.get_llm import get_large_llm
from core.logger import setup_logging, get_logger, log_critical_operation, log_performance_metric
from trust_layer.methods.critique_agent import critique_agent
import sys, os
from trust_layer.detectors.llm import LLMDetector
from trust_layer.methods.system_response import response_system_prompt
setup_logging()
logger = get_logger("a2a_orchestrator")
logger.info("Starting A2A-Orchestrator (A2A)")
logger.info(f"Python {sys.version.split()[0]} | Process ID: {os.getpid()}")

class A2AOrchestratorAgent(A2AServer):
    """
    Orchestrator A2A Agent (NO MCP, NO TOOLS)
    """

    def __init__(self, agent_card: AgentCard, registry_url: str):
        super().__init__(agent_card)
        self.registry_url = registry_url.rstrip("/")
        self._llm = get_large_llm()
        self.hallucination_detector = LLMDetector(domain="telecom", lang="en")

        self.detector = TransformerDetector(
            model_path="trust_layer/detectors/local_lettuce_model",
            device="cpu"
        )
    # --------------------------------------------------
    # Registry utilities
    # --------------------------------------------------
    def _get_registered_agents(self) -> List[Dict[str, Any]]:
        resp = requests.get(
            f"{self.registry_url}/registry/agents",
            timeout=5
        )
        resp.raise_for_status()
        return resp.json()

    def _find_agent_by_name(self, agents: list, keyword: str) -> Optional[dict]:
        for agent in agents:
            if keyword.lower() in agent.get("name", "").lower():
                return agent
        return None

    # --------------------------------------------------
    # A2A call helper
    # --------------------------------------------------
    def _send_to_agent(self, agent_url: str, text: str) -> str:

        client = A2AClient(agent_url)
        msg = Message(
            role=MessageRole.USER,
            content=TextContent(text=text)
        )
        resp = client.send_message(msg)
        if not resp or not resp.content:
            return ""
        return resp.content.text or ""

    # --------------------------------------------------
    # Intent helpers
    # --------------------------------------------------
    def _extract_intent(self, text: str) -> str:
        text = text.strip().lower()
        if "intent" in text:
            return text.split(":")[-1].strip()
        return text

    def _pick_agent_by_intent(
        self,
        intent: str,
        agents: list,
        query: str
    ) -> Optional[dict]:
        query = query.lower()
        for agent in agents:
            caps = agent.get("capabilities", {})
            skills = caps.get("skills", [])
            for skill in skills:
                if "intent" in skill and intent in skill["intent"].lower():
                    return agent
                if "pattern" in skill and re.search(skill["pattern"], query):
                    return agent
        return None

    # --------------------------------------------------
    # Core handler
    # --------------------------------------------------
    def handle_message(self, message: Message) -> Message:


        # ---------------- Default Safe Values ----------------

        conv_db_id = None
        random_id = ""
        final_llm_answer = ""
        answer = ""
        confidence_score=0.0
        query_entities=""
        retrieved_evidence=""
        evidence_entities=""
        user_query=""
        total_span_confidence = 0.0
        total_token_confidence = 0.0
        risk_level = "Low"
        hallucination_score=0.0
        hallucinated = False
        detection_method = "NO EVAL"
        hallucinated_reason = "NO HALLUCINATION_DETECTED"
        # Critique agent defaults (safe object-style)
        class _DefaultCritique:
            revaluated_score = 0.0
            reason = "No critique available"
        critique_agent_resp = _DefaultCritique()

        db = SessionLocal()
        metrics = Metrics()
        trace = Trace("Hallucination-Mitigation-Demo")
        # -------- BEFORE --------
        trace.log("Running without guardrails")
        
        if message.conversation_id is None:
            random_id = random.randint(1, 1_000_000)
            message.conversation_id = str(random_id)


        # Fetch methods configuration

        methods_config = get_methods(db)
        
        query = message.content.text if hasattr(message.content, "text") else ""

        #Lets test with LLM only
        llm_only = get_large_llm()
        
        # Generate answer first
        answer_prompt = f"Answer the following query clearly and comprehensively: {query}"
        llm_answer = llm_only.invoke(answer_prompt)
        answer = llm_answer.content
        
        # Calculate confidence score
        confidence_prompt = f"""Analyze the following query and answer to calculate a confidence score (0-100):

Query: {query}
Answer: {answer}

Consider:
1. Intent clarity of the query
2. Query ambiguity level
3. Whether all aspects of the query are covered
4. Completeness of the answer scope

Provide only a numeric confidence score (0-100):"""
        
        confidence_score = llm_only.invoke(confidence_prompt)
        try:
            confidence_score = float(confidence_score.content.strip())
        except:
            confidence_score = 30.0
            
        logger.info("LLM ONLY answer:%s with confidence score:%s",answer,confidence_score)
        
        # Return answer with confidence score
        final_answer = f"{answer}\n\nConfidence Score: {confidence_score}%"
        answer = final_answer
        agents = self._get_registered_agents()

        if methods_config.get('llm_judge', False):
            # 4️⃣ Forward Query
            logger.info("Forwarding query to Telecom Agent")
            telecom_agent = self._find_agent_by_name(agents, "telecom")
            
            if not telecom_agent:
                return self._reply(message, "Telecom Agent not found")

            answer = self._send_to_agent(telecom_agent["url"], query)
            logger.info("Finished with Telecom Agent:%s",answer)

            match = re.search(r"```json\s*(\{.*\})\s*```", answer, re.DOTALL)
            if match: 
                inner_json_str = match.group(1) 
                # Step 4: Parse the inner JSON 
                inner_data = json.loads(inner_json_str) 
                # Step 5: Extract fields 
                user_query = inner_data.get("user_query") 
                query_entities = inner_data.get("query_entities")
                retrieved_evidence =  inner_data.get("retrieved_evidence")
                evidence_entities = inner_data.get("evidence_entities")
                final_llm_answer = inner_data.get("final_llm_answer")
                confidence_score = inner_data.get("confidence_score")
                risk_level = inner_data.get("risk_level")

                print("User Query:", user_query) 
                print("Query Entities:", query_entities) 
            else:
                logger.warning("Response is a JSON.")
                inner_data = json.loads(answer) 
                # Step 5: Extract fields 
                user_query = inner_data.get("user_query") 
                query_entities = inner_data.get("query_entities")
                retrieved_evidence =  inner_data.get("retrieved_evidence")
                evidence_entities = inner_data.get("evidence_entities")
                final_llm_answer = inner_data.get("final_llm_answer")
                confidence_score = inner_data.get("confidence_score")
                risk_level = inner_data.get("risk_level")
                logger.warning("Returning from Response is a JSON.")     


            answer = final_llm_answer    
            
            # Hallucination Detection
            try:
                logger.info("ML HALLUCINATION_CHECK: Checking for hallucinations %s",methods_config.get('ml_eval', False))
                if methods_config.get('ml_eval', False):
                    logger.info("2 ML HALLUCINATION_CHECK: Checking for hallucinations %s",methods_config.get('ml_eval', False))
                #if check:
                    total_confidence = 0.0
                    spans = self.detector.predict(retrieved_evidence, answer, output_format="spans")
                    for span in spans:
                        total_confidence += span["confidence"]
                    total_span_confidence = total_confidence * 100
                    if total_span_confidence > 0:
                        hallucinated = True
                        logger.info("HALLUCINATION DETECTED: %s", total_span_confidence)
                    else:
                        logger.info("NO HALLUCINATION DETECTED")

                    
                    total_confidence = 0.0
                    tokens = self.detector.predict(retrieved_evidence, answer, output_format="tokens")
                    for token in tokens:
                        total_confidence += token["confidence"]
                    total_token_confidence = total_confidence * 100

                    if total_token_confidence > 0:
                        hallucinated = True
                        logger.info("HALLUCINATION DETECTED: %s", total_token_confidence)
                    else:
                        logger.info("NO HALLUCINATION DETECTED")
                logger.info("LLM EVAL: %s",methods_config.get('llm_eval', False))
                if methods_config.get('llm_eval', False):
                    logger.info("INSIDE LLM EVAL: %s",methods_config.get('llm_eval', False))
                    context_list = [retrieved_evidence] if retrieved_evidence else []
                    hallucination_spans = self.hallucination_detector.predict(
                        context=context_list,
                        answer=final_llm_answer,
                        question=user_query
                    )
                    detection_method="LLM-Based Detection"
                    hallucinated_reason = ""
                    if hallucination_spans:
                        hallucinated = True
                        hallucinated_texts = [span.get('text', '') for span in hallucination_spans]
                        hallucinated_reason = f"Found {len(hallucination_spans)} hallucination(s) in response: {hallucinated_texts}"
                        logger.warning("HALLUCINATION_DETECTED: Found %d hallucination(s) in response: %s", 
                                len(hallucination_spans), hallucinated_texts)
                    else:
                        hallucinated_reason = "NO HALLUCINATION_DETECTED"
                        logger.info("HALLUCINATION_CHECK: No hallucinations detected in response")
            except Exception as e:
                logger.error("HALLUCINATION_ERROR: Failed to detect hallucinations: %s", str(e))

            try:
                if risk_level.lower() == "high" or risk_level.lower() == "medium":
                    logger.info("LLM AS JUDGE: %s",methods_config.get('llm_judge', False))
                    if methods_config.get('llm_judge', False):
                        logger.info("INSIDE LLM AS JUDGE: %s",methods_config.get('llm_judge', False))
                        critique_agent_resp = critique_agent(
                            user_query,
                            query_entities,
                            evidence_entities,
                            retrieved_evidence,
                            final_llm_answer,
                            confidence_score,
                            hallucinated,
                            risk_level
                        )
                        logger.info("Critique Agent Response %s", critique_agent_resp)
            except Exception as e:
                logger.error("CRITIQUE_AGENT_ERROR: Failed to critique response: %s", str(e))
                
            if methods_config.get('neg_kw', False):
                missing_entities = list(set(query_entities) ^ set(evidence_entities)) 
                logger.info("NEG KW: %s",methods_config.get('neg_kw', False))
                print(missing_entities)
                trace.log("Applying Negative Knowledge Injection")
                nki = NegativeKnowledgeInjector()
                safe_prompt = nki.apply(
                    user_query,
                    missing_information=missing_entities
                )
                msa = MultiSampleAgreement(self._llm)
                msa_result = msa.run(safe_prompt)
                validated_answer = msa_result["responses"][0]

                validator = ClaimGroundingValidator()
                validation = validator.validate(validated_answer, retrieved_evidence)
            #check = True
            if methods_config.get('completeness_check', False):
                logger.info("completeness_check: %s",methods_config.get('completeness_check', False))
                answer = response_system_prompt(
                    user_query,
                    missing_entities,
                    confidence_score,
                    final_llm_answer,
                    retrieved_evidence
                )
                logger.info("COMPLETENESS CHECK:%s", answer)
            logger.info("FINISHED WITH ALL CHEcKS")

            if total_span_confidence > 0 or total_token_confidence > 0:
                detection_method = "ML-Based Detection"
                hallucinated_reason = f"Found hallucination(s) in response: {final_llm_answer}"
            if total_span_confidence > total_token_confidence:
                hallucination_score = total_span_confidence * 100
            else: 
                hallucination_score = total_token_confidence * 100
            hallucination_score = hallucination_score * 100
            confidence_score = confidence_score * 100
            critique_agent_resp.revaluated_score = critique_agent_resp.revaluated_score * 100

            try:
                conv_db_id = insert_conversation(
                    db=db,
                    conversation_id=random_id,
                    user_message=query,
                    ai_response=final_llm_answer,
                    confidence_score=confidence_score,
                    hallucination_score=hallucination_score,
                    critique_score=critique_agent_resp.revaluated_score,
                    critique_verdict=critique_agent_resp.reason,
                    completeness=answer,
                    sources=["internal_policy_doc"],
                )
                insert_hallucination_detection(
                    db=db,
                    conversation_db_id=conv_db_id,
                    detection_id=1,
                    detection_method=detection_method,
                    hallucination_score=hallucination_score,
                    hallucination_reason=hallucinated_reason,
                    severity=risk_level,
                )

            finally:
                db.close()
        else:
            try:

                #hallucination_score = hallucination_score * 100
                #confidence_score = confidence_score * 100
                #critique_agent_resp.revaluated_score = critique_agent_resp.revaluated_score * 100

                conv_db_id = insert_conversation(
                    db=db,
                    conversation_id=random_id,
                    user_message=query,
                    ai_response=answer,
                    confidence_score=confidence_score,
                    hallucination_score=hallucination_score,
                    critique_score=critique_agent_resp.revaluated_score,
                    critique_verdict=critique_agent_resp.reason,
                    completeness=answer,
                    sources=["internal_policy_doc"],
                )
                insert_hallucination_detection(
                    db=db,
                    conversation_db_id=conv_db_id,
                    detection_id=1,
                    detection_method=detection_method,
                    hallucination_score=hallucination_score,
                    hallucination_reason=hallucinated_reason,
                    severity=risk_level,
                )

            finally:
                db.close()
            


        logger.warning("FINAAAALLLL answer is %s.", answer)
        return Message(
            content=TextContent(text=answer),
            role=MessageRole.AGENT,
            parent_message_id=message.message_id,
            conversation_id=message.conversation_id
        )

    # --------------------------------------------------
    # Helper
    # --------------------------------------------------
    def _reply(self, message: Message, text: str) -> Message:
        return Message(
            role=MessageRole.AGENT,
            content=TextContent(text=text),
            parent_message_id=message.message_id,
            conversation_id=message.conversation_id
        )
