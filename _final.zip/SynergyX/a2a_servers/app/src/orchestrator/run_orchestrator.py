from python_a2a import AgentCard
from python_a2a.discovery import enable_discovery
from python_a2a.server import run_server
from a2a_orchestrator_agent import A2AOrchestratorAgent

REGISTRY_URL = "http://localhost:9100"

card = AgentCard(
    name="A2A Orchestrator Agent",
    description="Enterprise A2A control-plane orchestrator",
    url="http://localhost:9091",
    version="1.0.0",
    capabilities={
        "skills": [
            {"name": "orchestration", "intent": "orchestration"},
            {"name": "intent_routing", "intent": "intent_routing"},
            {"name": "agent_selection", "intent": "agent_selection"},
            {"name": "safety_enforcement", "intent": "safety_enforcement"}
        ]
    }
)

agent = A2AOrchestratorAgent(card, registry_url=REGISTRY_URL)

enable_discovery(agent, registry_url=REGISTRY_URL)

run_server(agent, host="0.0.0.0", port=9091)
