#!/usr/bin/env python
import re
import requests
from python_a2a import A2AClient, Message, TextContent, MessageRole


# -----------------------
# STEP 1: Fetch agents
# -----------------------
def get_registered_agents(registry_url: str):
    url = f"{registry_url}/registry/agents"
    resp = requests.get(url, timeout=5)
    resp.raise_for_status()
    return resp.json()


def call_llm_intent_agent(llm_agent_url: str, query: str) -> str:
    """
    Sends user query to the A2A LLM Agent, expecting a single intent string.
    """
    client = A2AClient(llm_agent_url)

    msg = Message(
        role=MessageRole.USER,
        content=TextContent(text=query)
    )

    resp = client.send_message(msg)

    if not resp or not resp.content:
        return "general"

    intent = resp.content.text.strip().lower()
    return intent


def extract_intent(text: str) -> str:
    text = text.strip().lower()
    if "intent" in text:
        return text.split(":")[-1].strip()
    return text


# -----------------------
# STEP 2: Simple Intent Detection
# -----------------------
def detect_intent(query: str, llm_agent_url: str) -> str:
    print("\n🤖 Sending query to A2A LLM Intent Agent...")
    intent = call_llm_intent_agent(llm_agent_url, query)
    intent = extract_intent(intent)
    return intent


# -----------------------
# STEP 3: Agent Picker
# -----------------------
def pick_agent_by_intent(intent: str, agents: list, query: str):
    query = query.lower()
    print("\n🔍 Matching skills for intent:", intent)

    for agent in agents:
        caps = agent.get("capabilities", {})
        skills = caps.get("skills", [])

        for skill in skills:

            if "intent" in skill and intent in skill["intent"].lower():
                print(f"   ✔ Intent match: {skill['intent']}")
                return agent

            if "pattern" in skill:
                pattern = skill["pattern"]
                if re.search(pattern, query):
                    print(f"   ✔ Pattern match: {pattern}")
                    return agent

    return None


# -----------------------
# STEP 4: Send message
# -----------------------
def send_to_agent(agent_url: str, text: str):
    client = A2AClient(agent_url)
    msg = Message(
        role=MessageRole.USER,
        content=TextContent(text=text)
    )
    resp = client.send_message(msg)
    print("📧 Agent Response:", resp)
    return resp.content.text if resp and resp.content else None


# -----------------------
# STEP 5: Full Routing Flow
# -----------------------
def route_query(registry_url: str, query: str):
    agents = get_registered_agents(registry_url)
    print("🧭 Agents Discovered:", [a["name"] for a in agents])

    pii_agent = next((a for a in agents if "PII" in a["name"]), None)

    if not pii_agent:
        raise RuntimeError("❌ No A2A PII Agent found in registry!")
    
    pii_url = pii_agent["url"]
    pii_reply = send_to_agent(pii_url, query)
    if pii_reply:
        print("\n🔒 PII Agent Response:\n", pii_reply)
        if "False" in pii_reply.strip():
            print("\n⚠️ PII Agent detected potentially sensitive or Inappropriate content.Please rephrase your query")
            return "Inappropriate content. Please rephrase your query."
        else:
            llm_agent = next((a for a in agents if "LLM" in a["name"]), None)
            if not llm_agent:
                raise RuntimeError("❌ No A2A LLM Intent Agent found in registry!")

            llm_url = llm_agent["url"]
            intent = detect_intent(query, llm_url)
            agent = pick_agent_by_intent(intent, agents, query)
            if not agent:
                print("⚠️ No matching agent found — using first available agent.")
                agent = agents[0]
            print(f"\n🤖 Routing query to: {agent['name']} ({agent['url']})")
            reply = send_to_agent(agent["url"], query)
            print("\n💬 Agent Response:\n", reply)


# -----------------------
# INTERACTIVE CLI CHAT LOOP (ADDED)
# -----------------------
if __name__ == "__main__":
    registry = "http://localhost:9100"

    print("\n===============================")
    print("     🤖 A2A Router Console     ")
    print("===============================")
    print("Type 'exit' or 'quit' to stop.\n")

    while True:
        query = input("You: ").strip()

        if query.lower() in ("exit", "quit"):
            print("\n👋 Goodbye!")
            break

        if query == "":
            continue

        try:
            route_query(registry, query)
        except Exception as e:
            print("\n❌ ERROR:", e)
        print("\n--------------------------------\n")
