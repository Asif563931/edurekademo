#!/usr/bin/env python
"""
A2A Client to test runtime-created agents from the registry.

Usage:
    python a2a_client.py --registry http://localhost:9100 --agent "IT Support Agent" --message "Hello!"
"""

import argparse
import requests
from python_a2a import A2AClient, Message, TextContent, MessageRole


def get_registered_agents(registry_url: str):
    """Fetch the list of registered agents from the registry."""
    try:
        url = f"{registry_url}/registry/agents"
        resp = requests.get(url, timeout=5)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        print(f"❌ Error fetching agents: {e}")
        return []


def find_agent(agents, name: str):
    """Return agent card by name."""
    for agent in agents:
        if agent["name"].lower() == name.lower():
            return agent
    return None


def send_message_to_agent(agent_url: str, text: str):
    """Send a message to an agent and return its response."""

    client = A2AClient(agent_url)

    msg = Message(
        role=MessageRole.USER,
        content=TextContent(text=text)
    )

    print(f"➡️ Sending: {text}")

    response = client.send_message(msg)

    if response and response.content:
        print(f"⬅️ Response: {response.content.text}")
    else:
        print("⚠️ No response received.")


def main():
    parser = argparse.ArgumentParser(description="A2A Client Tester")
    parser.add_argument("--registry", type=str, required=True,
                        help="Registry URL (e.g., http://localhost:9100)")
    parser.add_argument("--agent", type=str, required=False,
                        help="Agent name to send message to")
    parser.add_argument("--message", type=str, default="Hello from A2A Client!",
                        help="Message text")

    args = parser.parse_args()

    registry_url = args.registry
    agents = get_registered_agents(registry_url)

    if not agents:
        print("No agents found in registry.")
        return

    print("\nAvailable Agents:")
    for a in agents:
        print(f"- {a['name']} ({a['url']})")

    print()

    # Determine agent
    if args.agent:
        agent = find_agent(agents, args.agent)
        if not agent:
            print(f"❌ Agent '{args.agent}' not found in registry.")
            return
    else:
        # Pick the first agent if user didn't choose
        agent = agents[0]

    print(f"🔗 Using agent: {agent['name']} at {agent['url']}")

    # Send message
    send_message_to_agent(agent["url"], args.message)


if __name__ == "__main__":
    main()
