#!/usr/bin/env python
import re
import requests
from python_a2a import A2AClient, Message, TextContent, MessageRole
import asyncio
import sys
import time
import random
import threading
import argparse
from typing import AsyncGenerator, Dict, Any, List, Optional, Callable, Union


# ANSI colors for prettier output
GREEN = "\033[32m"
YELLOW = "\033[33m"
BLUE = "\033[34m"
RED = "\033[31m"
CYAN = "\033[36m"
BOLD = "\033[1m"
RESET = "\033[0m"


# -----------------------
# STEP 1: Fetch agents
# -----------------------
def get_registered_agents(registry_url: str):
    url = f"{registry_url}/registry/agents"
    resp = requests.get(url, timeout=5)
    resp.raise_for_status()
    return resp.json()


async def call_llm_intent_agent(llm_agent_url: str, query: str) -> str:
    """
    Calls the LLM Intent Agent and extracts the final intent.
    Works for both streaming and non-streaming responses.
    """
    client = A2AClient(llm_agent_url)
    msg = Message(
        role=MessageRole.USER,
        content=TextContent(text=query)
    )

    try:
        # -------- TRY STREAMING FIRST --------
        final_text = ""
        async for chunk in client.stream_response(msg):
            # Handle dictionary chunks
            if isinstance(chunk, dict):
                text = (
                    chunk.get("content")
                    or chunk.get("text")
                    or ""
                )
            else:
                text = str(chunk)

            final_text += text

        if final_text.strip():
            return final_text.strip().lower()

    except Exception:
        # If streaming fails → fallback to normal send_message()
        pass

    # -------- NON-STREAMING FALLBACK --------
    try:
        resp = client.send_message(msg)
        if resp and resp.content and hasattr(resp.content, "text"):
            return resp.content.text.strip().lower()
    except Exception:
        pass

    return "general"


def extract_intent(text: str) -> str:
    text = text.strip().lower()
    #print("Extracting intent from:", text)
    if "intent" in text:
        return text.split(":")[-1].strip()
    return text


# -----------------------
# STEP 2: Simple Intent Detection
# (LLM can replace this later)
# -----------------------
async def detect_intent(query: str, llm_agent_url: str) -> str:
    print("\n🤖 Sending query to A2A LLM Intent Agent...")
    intent = await call_llm_intent_agent(llm_agent_url, query)
    #print(f"🎯 LLM Agent Returned Intent: {intent}")
    intent = extract_intent(intent)
    #print(f"🎯 Extracted Intent: {intent}")
    return intent


# -----------------------
# STEP 3: Agent Picker (matches intents + patterns)
# -----------------------
def pick_agent_by_intent(intent: str, agents: list, query: str):
    query = query.lower()
    print("\n🔍 Matching skills for intent:", intent)

    for agent in agents:
        caps = agent.get("capabilities", {})
        skills = caps.get("skills", [])
        #print("Agent:", agent)
        #print("Agent skills are :", skills)
        #print(f"\n➡ Agent: {agent['name']}")
        #print(f"   Skills: {[s['name'] for s in skills]}")

        for skill in skills:
            
            #print("Skill for agent is :", skill)
            # Match by intent (prefix match)
            if "intent" in skill and intent in skill["intent"].lower():
                print(f"   ✔ Intent match: {skill['intent']}")
                return agent

            # Match by regex pattern
            if "pattern" in skill:
                pattern = skill["pattern"]
                if re.search(pattern, query):
                    print(f"   ✔ Pattern match: {pattern}")
                    return agent

    return None

# ===============================================================
# Client and Demo Functions
# ===============================================================

class StreamingVisualizer:
    """
    Visualize streaming responses with real-time metrics.
    """
    
    def __init__(self, show_tokens: bool = True, show_timing: bool = True):
        """Initialize visualizer with display options."""
        self.show_tokens = show_tokens
        self.show_timing = show_timing
        
        # Metrics
        self.start_time = time.time()
        self.token_count = 0
        self.total_chars = 0
        self.tokens = []
        self.full_text = ""
        
        # Display state
        self.last_update = 0
        self.update_interval = 0.2  # seconds
    
    def update_display(self):
        """Update the streaming metrics display."""
        current_time = time.time()
        elapsed = current_time - self.start_time
        
        # Only update occasionally to prevent flicker
        if current_time - self.last_update < self.update_interval:
            return
            
        self.last_update = current_time
        
        # Calculate metrics
        tokens_per_sec = self.token_count / elapsed if elapsed > 0 else 0
        chars_per_sec = self.total_chars / elapsed if elapsed > 0 else 0
        
        # Clear line and update
        sys.stdout.write("\r" + " " * 80 + "\r")
        sys.stdout.write(
            f"{CYAN}[{self.token_count} tokens | {self.total_chars} chars | "
            f"{elapsed:.1f}s | {tokens_per_sec:.1f} t/s | {chars_per_sec:.1f} c/s]{RESET}"
        )
        sys.stdout.flush()
    
    async def process_chunk(self, chunk: Union[str, Dict]):
        """
        Process a streaming chunk and update display.
        
        Args:
            chunk: Text chunk from the stream (string or dict)
        """
        # Extract text if it's a dictionary
        if isinstance(chunk, dict):
            if "content" in chunk:
                text = chunk["content"]
            elif "text" in chunk:
                text = chunk["text"]
            else:
                # Last resort, convert to string
                text = str(chunk)
        else:
            text = str(chunk)
        
        # Update metrics
        self.token_count += 1
        self.total_chars += len(text)
        self.tokens.append(text)
        self.full_text += text
        
        # Display the token if enabled
        if self.show_tokens:
            # Highlight tokens for visibility
            if self.token_count % 10 == 0:
                print(f"{YELLOW}{text}{RESET}", end="", flush=True)
            else:
                print(text, end="", flush=True)
        
        # Update metrics display
        if self.show_timing:
            self.update_display()
        
        # Small delay to allow UI updates
        await asyncio.sleep(0)
    
    def print_final_stats(self):
        """Print final statistics after streaming completes."""
        # Clear metrics line
        if self.show_timing:
            sys.stdout.write("\r" + " " * 80 + "\r")
            sys.stdout.flush()
        
        # Calculate final metrics
        elapsed = time.time() - self.start_time
        tokens_per_sec = self.token_count / elapsed if elapsed > 0 else 0
        chars_per_sec = self.total_chars / elapsed if elapsed > 0 else 0
        avg_token_size = self.total_chars / self.token_count if self.token_count else 0
        
        # Print summary
        print("\n" + "-" * 60)
        print(f"{GREEN}{BOLD}LLM Response Complete{RESET}")
        print(f"{GREEN}✓ Generated {self.token_count} tokens ({self.total_chars} characters){RESET}")
        print(f"{GREEN}✓ Time: {elapsed:.2f} seconds ({tokens_per_sec:.1f} tokens/sec){RESET}")
        if self.token_count > 0:
            print(f"{GREEN}✓ Average token size: {avg_token_size:.1f} characters{RESET}")

async def send_message_async(url: str, query: str):
    """
    Run the LLM streaming demo.
    
    Args:
        url: Server URL
        query: Query to send to the LLM
    """
    print(f"\n{BLUE}Query: \"{query}\"{RESET}")
    print(f"\n{BLUE}Streaming LLM response:{RESET}")
    print("-" * 60)

    client = A2AClient(url)

    # Create message
    message = Message(
        content=TextContent(text=query),
        role=MessageRole.USER
    )
    
    # Set up visualizer
    visualizer = StreamingVisualizer(show_tokens=True, show_timing=True)
    
    try:
        # Stream the response
        async for chunk in client.stream_response(message):
            await visualizer.process_chunk(chunk)
        
        # Print final stats
        visualizer.print_final_stats()
        
        return visualizer.full_text
        
    except Exception as e:
        print(f"\n\n{RED}Error during streaming: {str(e)}{RESET}")
        if visualizer.total_chars > 0:
            print(f"\n{YELLOW}Partial response ({visualizer.token_count} tokens):{RESET}")
            print(visualizer.full_text)
        return None

async def route_query_async(registry_url: str, query: str):
    """
    Main async function.
    
    Args:
        args: Command line arguments
    """
    agents = get_registered_agents(registry_url)
    print("🧭 Agents Discovered:", [a["name"] for a in agents])

    pii_agent = next((a for a in agents if "PII" in a["name"]), None)

    if not pii_agent:
        raise RuntimeError("❌ No A2A PII Agent found in registry!")
    
    pii_url = pii_agent["url"]
    pii_reply = await send_message_async(pii_url, query)
    if pii_reply:
        print("\n🔒 PII Agent Response:\n", pii_reply)
        
    # Find the LLM intent agent in registry
    llm_agent = next((a for a in agents if "LLM" in a["name"]), None)

    if not llm_agent:
        raise RuntimeError("❌ No A2A LLM Intent Agent found in registry!")

    llm_url = llm_agent["url"]

    # Detect intent using LLM agent
    intent = await detect_intent(query, llm_url)

    # Select the right agent
    agent = pick_agent_by_intent(intent, agents, query)

    if not agent:
        print("⚠️ No matching agent found — using first available agent.")
        agent = agents[0]

    print(f"\n🤖 Routing query to: {agent['name']} ({agent['url']})")
    # Run initial demo
    reply = await send_message_async(agent["url"], query)
    print("\n💬 Agent Response:\n", reply)
# -----------------------
# MAIN
# -----------------------
if __name__ == "__main__":
    registry = "http://localhost:9100"
    try:
        while True:
            print(f"\n{BLUE}Enter a query (or Ctrl+C to exit):{RESET}")
            next_query = input("> ")
            if next_query.strip():
                asyncio.run(route_query_async(registry, next_query))
            else:
                print(f"{YELLOW}Query cannot be empty{RESET}")
    except KeyboardInterrupt:
        print(f"\n{BLUE}Exiting interactive mode{RESET}")


    
