import asyncio
from langchain_mcp_adapters.client import MultiServerMCPClient


async def create_agent_workflow():
    """Create agent workflows based on subagent list."""
    mcp_client = MultiServerMCPClient({"mcp_server":{"url":"http://mcp:8001/sse", "transport":"sse"}})
    audit_tools = await mcp_client.get_tools()
    print(audit_tools)    

if __name__ == "__main__":
    asyncio.run(create_agent_workflow())