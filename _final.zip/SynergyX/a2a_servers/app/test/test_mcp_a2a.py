#!/usr/bin/env python
"""
Direct A2A Client to test any MCP Agent (SmartMCPAgent or others)
without using the A2A registry.

Usage:
    python a2a_direct_client.py --url http://localhost:9123/a2a \
                                --message "Hello Agent!"
"""

import argparse
from python_a2a import A2AClient, Message, TextContent, MessageRole


def send_message_to_agent(agent_url: str, text: str):
    """Send a message directly to the agent and print the response."""
    print(f"🔗 Connecting to agent at: {agent_url}")

    client = A2AClient(agent_url)

    msg = Message(
        role=MessageRole.USER,
        content=TextContent(text=text)
    )

    print(f"➡️ Sending: {text}")

    try:
        response = client.send_message(msg)
    except Exception as e:
        print(f"❌ Error contacting agent: {e}")
        return

    if response and response.content:
        print("⬅️ Response:")
        print(response.content.text)
    else:
        print("⚠️ No response received.")


def main():
    parser = argparse.ArgumentParser(description="Direct A2A Agent Tester")

    parser.add_argument("--url", type=str, required=True,
                        help="Full MCP Agent A2A endpoint, e.g. http://localhost:9123/a2a")

    parser.add_argument("--message", type=str, default="add 2 and 2",
                        help="Message text")

    args = parser.parse_args()

    send_message_to_agent(args.url, args.message)


if __name__ == "__main__":
    main()
