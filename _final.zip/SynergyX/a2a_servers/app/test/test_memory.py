#!/usr/bin/env python
"""
Test script for agent memory functionality
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from memory import MemoryManager
from core.database import init_database
import uuid

def test_memory_system():
    print("🧠 Testing Agent Memory System...")
    
    try:
        # Initialize database
        db_manager = init_database()
        memory_manager = MemoryManager()
        
        if not memory_manager.is_enabled():
            print("❌ Memory system is disabled")
            return
        
        print("✅ Memory system initialized")
        
        # Test conversation creation and message saving
        conversation_id = str(uuid.uuid4())
        user_id = "test_user"
        agent_name = "test_agent"
        
        print(f"📝 Testing conversation: {conversation_id}")
        
        # Save some test messages
        messages = [
            ("user", "Hello, I need help with my account"),
            ("agent", "I'd be happy to help you with your account. What specific issue are you experiencing?"),
            ("user", "I can't log in to my banking app"),
            ("agent", "I understand you're having trouble logging into your banking app. Let me help you troubleshoot this.")
        ]
        
        for role, content in messages:
            success = memory_manager.save_message(
                conversation_id=conversation_id,
                role=role,
                content=content,
                user_id=user_id,
                agent_name=agent_name
            )
            if success:
                print(f"✅ Saved {role} message")
            else:
                print(f"❌ Failed to save {role} message")
        
        # Test context retrieval
        print("\n🔍 Testing context retrieval...")
        context = memory_manager.get_context_for_llm(conversation_id)
        
        if context:
            print("✅ Context retrieved successfully:")
            print(f"Context length: {len(context)} characters")
            print("Context preview:")
            print(context[:200] + "..." if len(context) > 200 else context)
        else:
            print("❌ No context retrieved")
        
        # Test conversation history
        print("\n📚 Testing conversation history...")
        history = memory_manager.get_conversation_history(conversation_id)
        
        if history:
            print(f"✅ Retrieved {len(history)} messages from history")
            for msg in history:
                print(f"  {msg.role}: {msg.content[:50]}...")
        else:
            print("❌ No history retrieved")
        
        # Test agent state
        print("\n🤖 Testing agent state...")
        test_state = {"last_action": "login_help", "user_preferences": {"language": "en"}}
        
        success = memory_manager.save_agent_state(conversation_id, agent_name, test_state)
        if success:
            print("✅ Agent state saved")
            
            retrieved_state = memory_manager.get_agent_state(conversation_id, agent_name)
            if retrieved_state == test_state:
                print("✅ Agent state retrieved correctly")
            else:
                print("❌ Agent state mismatch")
        else:
            print("❌ Failed to save agent state")
        
        print("\n🎉 Memory system test completed!")
        
    except Exception as e:
        print(f"❌ Memory system test failed: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_memory_system()