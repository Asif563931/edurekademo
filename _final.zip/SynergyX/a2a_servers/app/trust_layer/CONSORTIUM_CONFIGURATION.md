# Consortium Consistency Configuration

## Overview
This document describes the enterprise configuration options for the Consortium Consistency hallucination mitigation system.

## Environment Variables

### Core Configuration
```bash
# Similarity threshold for clustering responses (0.0 - 1.0)
CONSORTIUM_SIMILARITY_THRESHOLD=0.5

# Entropy threshold for hallucination detection (0.0 - 3.0)
CONSORTIUM_ENTROPY_THRESHOLD=1.0

# Custom stopwords file path
CONSORTIUM_STOPWORDS_FILE=trust_layer/stopwords.json

# Custom entity filters file path
CONSORTIUM_ENTITY_FILTERS_FILE=trust_layer/entity_filters.json

# Fallback stopwords (comma-separated)
CONSORTIUM_STOPWORDS="the,is,a,an,of,in,to,for,and,or,with,by,from,at,on"

# Fallback entity filters (comma-separated)
CONSORTIUM_ENTITY_FILTERS="city,country,language,programming,used,great,better,than"
```

## Configuration Files

### Stopwords Configuration (`trust_layer/stopwords.json`)
Contains words to exclude from semantic analysis:
```json
[
  "the", "is", "a", "an", "of", "in", "to", "for", "and", "or",
  "with", "by", "from", "at", "on", "this", "that", "these", "those"
]
```

**Use Cases:**
- **Multi-language support**: Add stopwords for different languages
- **Domain-specific**: Remove domain-specific common words
- **Performance tuning**: Optimize clustering accuracy

### Entity Filters Configuration (`trust_layer/entity_filters.json`)
Contains descriptive words to filter out during entity extraction:
```json
[
  "city", "country", "language", "programming", "used", "great", 
  "better", "than", "very", "much", "more", "most", "less"
]
```

**Use Cases:**
- **Domain adaptation**: Filter domain-specific descriptors
- **Entity precision**: Improve entity conflict detection
- **Custom business logic**: Add business-specific filters

## Configuration Hierarchy

1. **JSON Configuration Files** (highest priority)
   - `trust_layer/stopwords.json`
   - `trust_layer/entity_filters.json`

2. **Environment Variables** (fallback)
   - `CONSORTIUM_STOPWORDS`
   - `CONSORTIUM_ENTITY_FILTERS`

3. **Default Values** (lowest priority)
   - Built-in English stopwords
   - Common entity filters

## Enterprise Customization Examples

### Financial Services
```json
// stopwords.json - Add financial terms
[
  "the", "is", "a", "an", "of", "in", "to", "for", "and", "or",
  "bank", "banking", "financial", "finance", "money", "currency",
  "investment", "trading", "market", "stock", "bond", "fund"
]

// entity_filters.json - Add financial descriptors
[
  "city", "country", "language", "programming", "used", "great",
  "profitable", "expensive", "cheap", "valuable", "risky", "safe",
  "bullish", "bearish", "volatile", "stable", "liquid", "illiquid"
]
```

### Healthcare
```json
// stopwords.json - Add medical terms
[
  "the", "is", "a", "an", "of", "in", "to", "for", "and", "or",
  "patient", "medical", "clinical", "health", "healthcare", "treatment",
  "diagnosis", "symptom", "disease", "condition", "therapy", "medicine"
]

// entity_filters.json - Add medical descriptors
[
  "city", "country", "language", "programming", "used", "great",
  "acute", "chronic", "severe", "mild", "critical", "stable",
  "positive", "negative", "normal", "abnormal", "healthy", "sick"
]
```

### Technology
```json
// stopwords.json - Add tech terms
[
  "the", "is", "a", "an", "of", "in", "to", "for", "and", "or",
  "software", "hardware", "system", "application", "platform", "service",
  "cloud", "server", "database", "network", "security", "data"
]

// entity_filters.json - Add tech descriptors
[
  "city", "country", "language", "programming", "used", "great",
  "scalable", "reliable", "secure", "fast", "slow", "efficient",
  "modern", "legacy", "cutting-edge", "outdated", "innovative", "traditional"
]
```

## Performance Tuning

### Similarity Threshold
- **Lower values (0.3-0.4)**: More strict clustering, more clusters
- **Higher values (0.6-0.7)**: More lenient clustering, fewer clusters
- **Recommended**: 0.5 for balanced performance

### Entropy Threshold
- **Lower values (0.5-0.8)**: More sensitive hallucination detection
- **Higher values (1.2-1.5)**: Less sensitive, fewer false positives
- **Recommended**: 1.0 for balanced detection

## Monitoring & Validation

### Configuration Validation
The system automatically validates configuration files on startup:
- JSON syntax validation
- Array type checking
- Fallback to environment variables on error

### Runtime Monitoring
Monitor these metrics to optimize configuration:
- Average entropy scores
- Clustering distribution
- Processing time
- Hallucination detection rate

## Best Practices

1. **Version Control**: Keep configuration files in version control
2. **Environment-Specific**: Use different configs for dev/staging/prod
3. **Regular Updates**: Review and update configurations based on domain evolution
4. **Testing**: Test configuration changes with representative data
5. **Documentation**: Document custom configurations for team knowledge

## Troubleshooting

### Common Issues
- **High false positives**: Increase entropy threshold or refine stopwords
- **Missed hallucinations**: Decrease entropy threshold or improve entity filters
- **Poor clustering**: Adjust similarity threshold or update stopwords
- **Performance issues**: Optimize stopwords list size

### Debug Logging
Enable debug logging to see configuration loading:
```python
import logging
logging.getLogger("llm_helper").setLevel(logging.DEBUG)
```