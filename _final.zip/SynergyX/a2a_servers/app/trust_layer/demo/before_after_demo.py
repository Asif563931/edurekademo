from trust_layer.observability.metrics import Metrics
from trust_layer.observability.traces import Trace
from trust_layer.methods.negative_knowledge import NegativeKnowledgeInjector
from trust_layer.methods.multi_sample_agreement import MultiSampleAgreement
from trust_layer.methods.claim_grounding import ClaimGroundingValidator
from helpers.get_llm import get_large_llm
llm = get_large_llm()

rag_chunks = [
    {
        "content": "Plan X supports international roaming in Europe.",
        "source": "Plan_X_Terms.pdf"
    }
]

query = "Does Plan X support international roaming and how many countries?"

metrics = Metrics()
trace = Trace("Hallucination-Mitigation-Demo")

# -------- BEFORE --------
trace.log("Running without guardrails")
before_answer = llm.invoke(query).content

print("\n❌ BEFORE:\n", before_answer)

# -------- AFTER --------
trace.log("Applying Negative Knowledge Injection")
nki = NegativeKnowledgeInjector()
safe_prompt = nki.apply(
    query,
    missing_information=["Exact country count"]
)

msa = MultiSampleAgreement(llm)
msa_result = msa.run(safe_prompt)

metrics.emit("agreement_score", msa_result["agreement_score"])

validated_answer = msa_result["responses"][0]

validator = ClaimGroundingValidator()
validation = validator.validate(validated_answer, rag_chunks)

metrics.emit("final_confidence", validation["overall_confidence"])

print("\n✅ AFTER:\n", validated_answer)
print("\n📊 CLAIM ANALYSIS:\n", validation)
print("\n📈 METRICS:\n", metrics.report())
print("\n🧭 TRACE:\n", trace.end())
