#!/usr/bin/env python
"""Interactive test script for LLM detector."""

import os
import sys
import tempfile

# Add parent directories to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from detectors.llm import LLMDetector

def interactive_test():
    """Interactive testing of LLM detector."""
    
    print("LLM Hallucination Detector - Interactive Test")
    print("=" * 50)
    
    detector = LLMDetector(cache_file=tempfile.mktemp())
    
    while True:
        print("\nEnter your test case (or 'quit' to exit):")
        
        context = input("Context: ").strip()
        if context.lower() == 'quit':
            break
            
        answer = input("Answer: ").strip()
        if answer.lower() == 'quit':
            break
        
        try:
            spans = detector.predict([context], answer)
            
            print(f"\nResults:")
            if spans:
                print(f"Hallucinations detected: {len(spans)}")
                for i, span in enumerate(spans, 1):
                    print(f"  {i}. '{span['text']}' (positions {span['start']}-{span['end']})")
            else:
                print("No hallucinations detected")
                
        except Exception as e:
            print(f"Error: {e}")
        
        print("-" * 50)

if __name__ == "__main__":
    interactive_test()