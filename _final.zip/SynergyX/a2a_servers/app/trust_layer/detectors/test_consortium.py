#!/usr/bin/env python
"""Test consortium consistency functionality."""

import os
import sys
from unittest.mock import Mock, patch

# Add parent directories to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from helpers.get_llm import aggregate_responses, _get_stopwords, _get_entity_filters

def test_consortium_clustering():
    """Test response clustering logic."""
    responses = [
        "The capital of France is Paris",
        "Paris is the capital of France",
        "The capital of France is London"  # Conflicting
    ]
    
    result = aggregate_responses(responses)
    assert "Paris" in result or "London" in result
    print("✓ Consortium clustering test passed")

def test_stopwords_loading():
    """Test stopwords configuration loading."""
    stopwords = _get_stopwords()
    assert isinstance(stopwords, set)
    assert len(stopwords) > 0
    print("✓ Stopwords loading test passed")

def test_entity_filters():
    """Test entity filters configuration."""
    filters = _get_entity_filters()
    assert isinstance(filters, set)
    assert len(filters) > 0
    print("✓ Entity filters test passed")

def test_entropy_calculation():
    """Test entropy-based hallucination detection."""
    # High agreement responses
    similar_responses = [
        "Paris is the capital",
        "Paris is the capital", 
        "Paris is the capital"
    ]
    
    result1 = aggregate_responses(similar_responses)
    
    # High disagreement responses  
    different_responses = [
        "Paris is the capital",
        "London is the capital",
        "Berlin is the capital"
    ]
    
    result2 = aggregate_responses(different_responses)
    
    assert result1 is not None
    assert result2 is not None
    print("✓ Entropy calculation test passed")

if __name__ == "__main__":
    test_consortium_clustering()
    test_stopwords_loading()
    test_entity_filters()
    test_entropy_calculation()
    print("All consortium tests passed!")