"""
Compare 'tokens' vs 'spans' output formats.
Run: python3 app/trust_layer/detectors/test_formats.py
"""
import sys
import os

# Path setup to allow imports
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(current_dir, "../../../"))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.trust_layer.detectors import TransformerDetector

def main():
    print("⏳ Loading Detector...")
    detector = TransformerDetector(
        model_path="local_lettuce_model",
        device="cpu"
    )

    context = ["The capital of France is Paris. It is a city in Europe."]
    # "London" is a hallucination. "Mars" is a hallucination.
    answer = "The capital of France is Paris. It is a city on Mars."

    print("\n" + "="*60)
    print(f"🤖 Answer: {answer}")
    print("="*60)

    # ---------------------------------------------------------
    # MODE 1: SPANS (Clean, Human Readable)
    # ---------------------------------------------------------
    print("\n1️⃣  OUTPUT FORMAT: 'spans' (Best for UI/Highlighting)")
    spans = detector.predict(context, answer, output_format="spans")
    
    for span in spans:
        print(f"   👉 Found: '{span['text']}'")
        print(f"      Confidence: {span['confidence']:.4f}")
        print(f"      Position:   {span['start']} - {span['end']}")
        print("-" * 30)

    # ---------------------------------------------------------
    # MODE 2: TOKENS (Raw, Machine Readable)
    # ---------------------------------------------------------
    print("\n2️⃣  OUTPUT FORMAT: 'tokens' (Best for Heatmaps/Debug)")
    print("   (Showing only the hallucinated parts for brevity)\n")
    
    tokens = detector.predict(context, answer, output_format="tokens")
    
    print(f"   {'TOKEN':<15} | {'PRED':<5} | {'PROB (%)'}")
    print("-" * 40)
    
    for t in tokens:
        # Only printing interesting ones, but the list contains ALL tokens
        if t['pred'] == 1: 
            status = "🔴" # Hallucination
        else:
            status = "🟢" # Safe
            
        print(f"   {t['token']:<15} |  {status}   | {t['prob']:.4f}")

if __name__ == "__main__":
    main()