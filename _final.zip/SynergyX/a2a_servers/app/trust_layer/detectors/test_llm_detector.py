#!/usr/bin/env python
"""Test script for LLM hallucination detector."""

import json
import os
import sys
import tempfile
from unittest.mock import Mock, patch

# Add parent directories to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from helpers.get_llm import get_large_llm, aggregate_responses
from detectors.llm import LLMDetector

def test_basic_detection():
    """Test basic hallucination detection."""
    # Mock LangChain LLM response
    mock_response = Mock()
    mock_response.content = '{"hallucination_list": ["fake fact"]}'
    
    with patch('helpers.get_llm.get_large_llm') as mock_get_llm:
        mock_llm = Mock()
        mock_llm.invoke.return_value = mock_response
        mock_get_llm.return_value = mock_llm
        
        detector = LLMDetector(model="gpt-4", cache_file=tempfile.mktemp())
        
        context = ["The sky is blue."]
        answer = "The sky is blue and fake fact about aliens."
        
        spans = detector.predict(context, answer)
        
        assert len(spans) == 1
        assert "fake fact" in spans[0]["text"]
        print("✓ Basic detection test passed")

def test_batch_prediction():
    """Test batch prediction."""
    mock_response = Mock()
    mock_response.content = '{"hallucination_list": []}'
    
    with patch('helpers.get_llm.get_large_llm') as mock_get_llm:
        mock_llm = Mock()
        mock_llm.invoke.return_value = mock_response
        mock_get_llm.return_value = mock_llm
        
        detector = LLMDetector(cache_file=tempfile.mktemp())
        
        prompts = ["What is 2+2?", "What is the capital of France?"]
        answers = ["2+2 equals 4", "Paris is the capital"]
        
        results = detector.predict_prompt_batch(prompts, answers)
        
        assert len(results) == 2
        print("✓ Batch prediction test passed")

def test_invalid_format():
    """Test invalid output format handling."""
    detector = LLMDetector(cache_file=tempfile.mktemp())
    
    try:
        detector.predict(["context"], "answer", output_format="invalid")
        assert False, "Should have raised ValueError"
    except ValueError as e:
        assert "doesn't support 'invalid' format" in str(e)
        print("✓ Invalid format test passed")

def test_llm_integration():
    """Test integration with helpers.get_llm."""
    with patch('helpers.get_llm.ChatOpenAI') as mock_chat:
        mock_llm = Mock()
        mock_chat.return_value = mock_llm
        
        llm = get_large_llm()
        assert llm is not None
        print("✓ LLM integration test passed")

def test_detector_initialization():
    """Test detector initialization with helpers LLM."""
    with patch('helpers.get_llm.get_large_llm') as mock_get_llm:
        mock_llm = Mock()
        mock_get_llm.return_value = mock_llm
        
        detector = LLMDetector(cache_file=tempfile.mktemp())
        assert detector.llm is not None
        print("✓ Detector initialization test passed")

def test_consortium_aggregation():
    """Test consortium response aggregation."""
    responses = [
        "The capital of France is Paris",
        "Paris is the capital of France", 
        "France's capital city is Paris"
    ]
    
    result = aggregate_responses(responses)
    assert "Paris" in result
    print("✓ Consortium aggregation test passed")

if __name__ == "__main__":
    # Create mock dependencies
    os.makedirs("prompts", exist_ok=True)
    
    # Create mock prompt template
    with open("prompts/hallucination_detection.txt", "w") as f:
        f.write("Detect hallucinations in: $context\nAnswer: $answer\nLanguage: $lang\n$fewshot_block")
    
    # Create mock examples
    with open("prompts/examples_en.json", "w") as f:
        json.dump([{
            "source": "test context",
            "answer": "test answer", 
            "hallucination_list": ["fake"]
        }], f)
    
    test_basic_detection()
    test_batch_prediction()
    test_invalid_format()
    test_llm_integration()
    test_consortium_aggregation()
    test_detector_initialization()
    print("All tests passed!")