#!/usr/bin/env python
"""Integration test for LLM detector with real API calls."""

import os
import sys

# Add parent directories to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from helpers.get_llm import get_large_llm, get_small_llm
from detectors.llm import LLMDetector

def test_real_detection():
    """Test with real LLM via helpers (requires configuration)."""
    try:
        detector = LLMDetector(model="gpt-4o-mini", temperature=0.0)
        
        # Test case with obvious hallucination
        context = ["Paris is the capital of France."]
        answer = "Paris is the capital of France and has purple rivers."
        
        spans = detector.predict(context, answer)
        
        print(f"Detected {len(spans)} hallucination spans:")
        for span in spans:
            print(f"  - '{span['text']}' at {span['start']}-{span['end']}")
        
        # Test with no hallucination
        answer_clean = "Paris is the capital of France."
        spans_clean = detector.predict(context, answer_clean)
        
        print(f"Clean answer spans: {len(spans_clean)}")
        
    except Exception as e:
        print(f"⚠️ Skipping real LLM test - configuration issue: {e}")

def test_helpers_llm():
    """Test helpers LLM functions."""
    try:
        llm = get_large_llm()
        print("✓ Large LLM initialized successfully")
        
        small_llm = get_small_llm()
        print("✓ Small LLM initialized successfully")
        
        # Test LLM invoke method
        test_response = llm.invoke("Test prompt")
        print(f"✓ LLM invoke test: {type(test_response)}")
        
    except Exception as e:
        print(f"⚠️ LLM initialization failed: {e}")

if __name__ == "__main__":
    test_real_detection()
    test_helpers_llm()