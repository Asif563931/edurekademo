#!/usr/bin/env python
"""Test script for different queries with LLM detector."""

import os
import sys
import tempfile

# Add parent directories to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from detectors.llm import LLMDetector

def test_queries():
    """Test different types of queries."""
    
    # Create detector
    detector = LLMDetector(cache_file=tempfile.mktemp())
    
    # Test cases: (context, answer, description)
    test_cases = [
        (
            ["Paris is the capital of France."],
            "Paris is the capital of France and has purple rivers.",
            "Obvious hallucination"
        ),
        (
            ["The sky appears blue during the day."],
            "The sky is blue because of light scattering.",
            "Factual answer"
        ),
        (
            ["Apple Inc. was founded in 1976."],
            "Apple was founded in 1976 by Steve Jobs and Bill Gates.",
            "Mixed fact and hallucination"
        ),
        (
            ["Water boils at 100°C at sea level."],
            "Water boils at 90°C and freezes at 10°C.",
            "Multiple incorrect facts"
        ),
        (
            ["The moon orbits Earth."],
            "The moon orbits Earth and is made of cheese.",
            "Fact plus obvious fiction"
        )
    ]
    
    print("Testing LLM Detector with different queries:\n")
    
    for i, (context, answer, description) in enumerate(test_cases, 1):
        print(f"Test {i}: {description}")
        print(f"Context: {context[0]}")
        print(f"Answer: {answer}")
        
        try:
            spans = detector.predict(context, answer)
            
            if spans:
                print(f"Hallucinations detected: {len(spans)}")
                for span in spans:
                    print(f"  - '{span['text']}' at positions {span['start']}-{span['end']}")
            else:
                print("No hallucinations detected")
                
        except Exception as e:
            print(f"Error: {e}")
        
        print("-" * 60)

if __name__ == "__main__":
    test_queries()