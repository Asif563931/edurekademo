#!/usr/bin/env python
"""Test real queries with mock LLM for consistent results."""

import os
import sys
import tempfile
from unittest.mock import Mock, patch

# Add parent directories to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from detectors.llm import LLMDetector

def test_with_mock():
    """Test with mocked LLM for predictable results."""
    
    test_cases = [
        {
            "context": "My name is asif and I work in TCS",
            "answer": "My name is asif and I work in Wipro",
            "expected_hallucination": "Wipro",
            "description": "Company name hallucination"
        },
        {
            "context": "Paris is the capital of France",
            "answer": "Paris is the capital of France and has golden streets",
            "expected_hallucination": "golden streets", 
            "description": "Added fictional detail"
        },
        {
            "context": "Water boils at 100°C",
            "answer": "Water boils at 90°C",
            "expected_hallucination": "90°C",
            "description": "Incorrect temperature"
        }
    ]
    
    for i, case in enumerate(test_cases, 1):
        print(f"\nTest {i}: {case['description']}")
        print(f"Context: {case['context']}")
        print(f"Answer: {case['answer']}")
        
        # Mock response to detect the expected hallucination
        mock_response = Mock()
        mock_response.content = f'{{"hallucination_list": ["{case["expected_hallucination"]}"]}}'
        
        with patch('helpers.get_llm.get_large_llm') as mock_get_llm:
            mock_llm = Mock()
            mock_llm.invoke.return_value = mock_response
            mock_get_llm.return_value = mock_llm
            
            detector = LLMDetector(cache_file=tempfile.mktemp())
            spans = detector.predict([case['context']], case['answer'])
            
            if spans:
                print(f"✓ Detected hallucination: '{spans[0]['text']}'")
            else:
                print("✗ No hallucination detected")
        
        print("-" * 50)

if __name__ == "__main__":
    test_with_mock()