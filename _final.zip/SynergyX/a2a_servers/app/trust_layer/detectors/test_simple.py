#!/usr/bin/env python
"""Simple test to debug the issue."""

import json
import os
import sys
import tempfile
from unittest.mock import Mock, patch

# Add parent directories to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from detectors.llm import LLMDetector

def test_simple():
    """Simple test with debug output."""
    # Create mock files
    os.makedirs("prompts", exist_ok=True)
    
    with open("prompts/hallucination_detection.txt", "w") as f:
        f.write("Context: $context\nAnswer: $answer\n$fewshot_block")
    
    with open("prompts/examples_en.json", "w") as f:
        json.dump([{"source": "test", "answer": "test", "hallucination_list": []}], f)
    
    # Mock LLM response
    mock_response = Mock()
    mock_response.content = '{"hallucination_list": ["fake fact"]}'
    
    with patch('helpers.get_llm.get_large_llm') as mock_get_llm:
        mock_llm = Mock()
        mock_llm.invoke.return_value = mock_response
        mock_get_llm.return_value = mock_llm
        
        detector = LLMDetector(cache_file=tempfile.mktemp())
        
        # Test the _predict method directly
        result = detector._predict("test prompt", "test answer with fake fact")
        print(f"Direct _predict result: {result}")
        
        # Test full predict method
        spans = detector.predict(["test context"], "test answer with fake fact")
        print(f"Full predict result: {spans}")

if __name__ == "__main__":
    test_simple()