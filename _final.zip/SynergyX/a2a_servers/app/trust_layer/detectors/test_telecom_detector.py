#!/usr/bin/env python
"""Test LLM detector with telecom-specific examples."""

import os
import sys
import tempfile

# Add parent directories to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from detectors.llm import LLMDetector

def test_telecom_queries():
    """Test telecom-specific hallucination detection."""
    
    # Create detector with telecom examples
    detector = LLMDetector(
        cache_file=tempfile.mktemp(),
        fewshot_path="prompts/examples_telecom_en.json"
    )
    
    # Telecom test cases
    test_cases = [
        {
            "context": ["My name is asif and I work in TCS"],
            "answer": "My name is asif and I work in Wipro",
            "description": "Company name hallucination"
        },
        {
            "context": ["Plan X costs ₹499 per month"],
            "answer": "Plan X costs ₹299 per month with free Netflix",
            "description": "Price and service hallucination"
        },
        {
            "context": ["SIM activation takes 2-4 hours"],
            "answer": "SIM activation is instant and works immediately",
            "description": "Process time hallucination"
        },
        {
            "context": ["Plan Z does not support international roaming"],
            "answer": "Plan Z includes free roaming in 50 countries",
            "description": "Feature availability hallucination"
        }
    ]
    
    print("Testing Telecom LLM Detector:\n")
    
    for i, case in enumerate(test_cases, 1):
        print(f"Test {i}: {case['description']}")
        print(f"Context: {case['context'][0]}")
        print(f"Answer: {case['answer']}")
        
        try:
            spans = detector.predict(case['context'], case['answer'])
            
            if spans:
                print(f"✓ Hallucinations detected: {len(spans)}")
                for span in spans:
                    print(f"  - '{span['text']}' at {span['start']}-{span['end']}")
            else:
                print("✗ No hallucinations detected")
                
        except Exception as e:
            print(f"Error: {e}")
        
        print("-" * 60)

if __name__ == "__main__":
    test_telecom_queries()