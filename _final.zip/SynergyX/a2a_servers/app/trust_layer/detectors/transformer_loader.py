import os
import requests
import urllib3
from transformers import AutoTokenizer, AutoModelForTokenClassification

# Disable the "Unverified HTTPS" warnings to keep output clean
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Settings
REPO_ID = "KRLabsOrg/lettucedect-base-modernbert-en-v1"
LOCAL_DIR = "local_lettuce_model"
BASE_URL = f"https://huggingface.co/{REPO_ID}/resolve/main"

FILES_TO_FETCH = [
    "config.json",
    "tokenizer.json",
    "tokenizer_config.json",
    "special_tokens_map.json",
    "model.safetensors"
]

def download_file(filename):
    url = f"{BASE_URL}/{filename}"
    save_path = os.path.join(LOCAL_DIR, filename)
    
    print(f"⬇️  Fetching {filename}...", end=" ", flush=True)
    
    try:
        response = requests.get(url, verify=False, stream=True)
        response.raise_for_status()
        
        with open(save_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        print("✅ Done")
        return True
    except Exception as e:
        print(f"❌ FAILED")
        print(f"   Error: {e}")
        return False

def main():
    # 1. Create Directory
    if not os.path.exists(LOCAL_DIR):
        os.makedirs(LOCAL_DIR)
        print(f"📂 Created directory: {LOCAL_DIR}")

    # 2. Download Files Loop
    print(f"🌍 Downloading from {REPO_ID} (SSL Verification DISABLED)\n")
    success_count = 0
    for fname in FILES_TO_FETCH:
        if download_file(fname):
            success_count += 1
            
    if success_count != len(FILES_TO_FETCH):
        print("\n❌ CRITICAL: Some files failed to download.")
        print("   Please try Option 2 (Browser Download) below.")
        return

    # 3. Test Loading
    print("\n🔄 Testing Load from Local Folder...")
    try:
        # Force it to look at the local folder we just filled
        tokenizer = AutoTokenizer.from_pretrained(LOCAL_DIR)
        model = AutoModelForTokenClassification.from_pretrained(LOCAL_DIR)
        
        print("\n🎉 SUCCESS! The model is saved and working locally.")
        print(f"   Path: {os.path.abspath(LOCAL_DIR)}")
        print("   👉 You can now update your 'transformer.py' to use this path.")
        
    except Exception as e:
        print(f"\n❌ Load FAILED even after download.")
        print(f"Error: {e}")

if __name__ == "__main__":
    main()