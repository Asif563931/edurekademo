#!/usr/bin/env python3
"""Interactive CLI tool for testing hallucination detection."""

import sys
import os
from pathlib import Path

# Add parent directories to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from llm import LLMDetector

def print_banner():
    """Print welcome banner."""
    print("=" * 60)
    print("🔍 INTERACTIVE HALLUCINATION DETECTOR")
    print("=" * 60)
    print("Test LLM responses for hallucinations")
    print("Type 'quit' or 'exit' to stop\n")

def get_multiline_input(prompt):
    """Get multiline input from user."""
    print(f"{prompt}")
    print("(Press Enter twice to finish)")
    lines = []
    empty_count = 0
    
    while True:
        line = input()
        if line == "":
            empty_count += 1
            if empty_count >= 2:
                break
        else:
            empty_count = 0
            lines.append(line)
    
    return "\n".join(lines).strip()

def select_domain():
    """Let user select detection domain."""
    domains = ["general", "telecom", "financial", "healthcare", "ecommerce"]
    
    print("\nSelect domain:")
    for i, domain in enumerate(domains, 1):
        print(f"{i}. {domain.title()}")
    
    while True:
        try:
            choice = input("\nEnter choice (1-5) [default: 1]: ").strip()
            if not choice:
                return domains[0]
            idx = int(choice) - 1
            if 0 <= idx < len(domains):
                return domains[idx]
            print("Invalid choice. Please enter 1-5.")
        except ValueError:
            print("Invalid input. Please enter a number.")

def format_results(spans, answer):
    """Format detection results for display."""
    if not spans:
        print("✅ No hallucinations detected!")
        return
    
    print(f"🚨 Found {len(spans)} hallucination(s):")
    print("-" * 40)
    
    for i, span in enumerate(spans, 1):
        text = span.get('text', '')
        start = span.get('start', 0)
        end = span.get('end', len(text))
        
        print(f"{i}. \"{text}\"")
        print(f"   Position: {start}-{end}")
        
        # Show context around the hallucination
        context_start = max(0, start - 20)
        context_end = min(len(answer), end + 20)
        context = answer[context_start:context_end]
        
        # Highlight the hallucinated part
        highlight_start = start - context_start
        highlight_end = end - context_start
        highlighted = (
            context[:highlight_start] + 
            f"[{context[highlight_start:highlight_end]}]" + 
            context[highlight_end:]
        )
        print(f"   Context: ...{highlighted}...")
        print()

def main():
    """Main interactive loop."""
    print_banner()
    
    # Initialize detector
    domain = select_domain()
    print(f"\nInitializing detector for {domain} domain...")
    
    try:
        detector = LLMDetector(
            model="gpt-4o-mini",
            temperature=0.0,
            lang="en",
            domain=domain
        )
        print("✅ Detector initialized successfully!\n")
    except Exception as e:
        print(f"❌ Failed to initialize detector: {e}")
        return
    
    # Main testing loop
    while True:
        try:
            print("\n" + "=" * 60)
            print("NEW TEST CASE")
            print("=" * 60)
            
            # Get context
            context_input = get_multiline_input("📝 Enter CONTEXT (background information):")
            if context_input.lower() in ['quit', 'exit']:
                break
            
            # Get query
            query = input("\n❓ Enter QUERY (optional, press Enter to skip): ").strip()
            if query.lower() in ['quit', 'exit']:
                break
            
            # Get LLM answer
            answer = get_multiline_input("\n🤖 Enter LLM ANSWER to analyze:")
            if answer.lower() in ['quit', 'exit']:
                break
            
            # Perform detection
            print("\n🔍 Analyzing for hallucinations...")
            
            context_list = [context_input] if context_input else []
            query_param = query if query else None
            
            spans = detector.predict(
                context=context_list,
                answer=answer,
                question=query_param
            )
            
            # Display results
            print("\n" + "=" * 40)
            print("DETECTION RESULTS")
            print("=" * 40)
            format_results(spans, answer)
            
            # Ask to continue
            continue_choice = input("\n🔄 Test another case? (y/n) [default: y]: ").strip().lower()
            if continue_choice in ['n', 'no']:
                break
                
        except KeyboardInterrupt:
            print("\n\n👋 Goodbye!")
            break
        except Exception as e:
            print(f"\n❌ Error during detection: {e}")
            continue_choice = input("Continue testing? (y/n) [default: y]: ").strip().lower()
            if continue_choice in ['n', 'no']:
                break
    
    print("\n👋 Thanks for using the Hallucination Detector!")

if __name__ == "__main__":
    main()