import re
from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional, Any

from trust_layer.utils.text import extract_claims


# ==========================================================
# Enums
# ==========================================================

class GroundingVerdict(str, Enum):
    SUPPORTED = "SUPPORTED"
    CONTRADICTED = "CONTRADICTED"
    NOT_FOUND = "NOT_FOUND"
    SAFE_ABSTENTION = "SAFE_ABSTENTION"
    SKIPPED = "SKIPPED"


class ClaimSeverity(str, Enum):
    FACT = "FACT"
    BENEFIT = "BENEFIT"
    PROCEDURAL = "PROCEDURAL"


# ==========================================================
# Data Structures
# ==========================================================

@dataclass
class Chunk:
    content: str
    score: Optional[float] = None
    source: Optional[str] = None


# ==========================================================
# Validator
# ==========================================================

class ClaimGroundingValidator:
    """
    Production-grade deterministic claim grounding validator (v2.2)

    Features:
    - Claim-level grounding
    - SUPPORTED / CONTRADICTED / NOT_FOUND / SAFE_ABSTENTION
    - Absence-claim verification
    - Contradiction detection via polarity mismatch
    - Claim severity classification (FACT / BENEFIT / PROCEDURAL)
    - Safe aggregation logic (mixed-truth penalty)
    - Full trace for audit & demo
    """

    # -------------------------
    # Retrieval filtering
    # -------------------------
    MAX_RETRIEVAL_SCORE = 2.0  # distance-based; set None if similarity-based

    # -------------------------
    # Thresholds
    # -------------------------
    MIN_WEIGHTED_SUPPORT = 2.6
    MIN_WEIGHTED_CONTRADICTION = 2.2
    MIN_PHRASE_MATCHES = 1

    # -------------------------
    # Language & domain config
    # -------------------------
    STOPWORDS = {
        "the", "a", "an", "and", "or", "to", "of", "in", "on", "for", "with", "by",
        "is", "are", "was", "were", "be", "been", "being",
        "it", "this", "that", "these", "those",
        "you", "your", "we", "our", "they", "their",
        "at", "from", "as", "can", "will", "may", "might", "should"
    }

    DOMAIN_WEIGHTS = {
        # billing
        "bill": 1.6, "billing": 1.6, "charge": 1.5, "fee": 1.5, "penalty": 1.7,
        "refund": 1.6, "gst": 1.3, "tax": 1.3,

        # plans / pricing
        "plan": 1.4, "price": 1.6, "₹": 1.7, "rs": 1.6, "inr": 1.6,
        "validity": 1.4, "unlimited": 1.3, "data": 1.3,
        "5g": 1.6, "4g": 1.5, "gb": 1.3,

        # network
        "outage": 1.7, "network": 1.4, "coverage": 1.3,

        # policy
        "policy": 1.3, "terms": 1.3, "eligible": 1.4
    }

    NEGATION_CUES = {
        "no", "not", "never", "cannot", "can't", "doesn't",
        "don't", "without", "unavailable", "excluded"
    }

    ABSENCE_PATTERNS = [
        r"\bnot available\b",
        r"\bnot provided\b",
        r"\bno information\b",
        r"\bnot mentioned\b",
        r"\bcannot be found\b"
    ]

    BENEFIT_KEYWORDS = {
        "free", "included", "unlimited", "addon", "add-on",
        "subscription", "netflix", "ott", "benefit", "offer"
    }

    PROCEDURAL_KEYWORDS = {
        "contact", "reach", "visit", "support",
        "customer care", "raise", "request", "complaint"
    }

    # ======================================================
    # Public API
    # ======================================================

    def validate(self, answer: str, rag_chunks: List[str]) -> Dict[str, Any]:
        claims = [c.strip() for c in extract_claims(answer) if c.strip()]
        chunks = self._filter_chunks([self._parse_chunk(c) for c in rag_chunks])

        results = [self._validate_claim(c, chunks) for c in claims]
        overall = self._aggregate(results)

        return {
            "claim_results": results,
            "overall": overall
        }

    # ======================================================
    # Claim validation
    # ======================================================

    def _validate_claim(self, claim: str, chunks: List[Chunk]) -> Dict[str, Any]:
        severity = self._classify_severity(claim)
        is_absence = self._is_absence_claim(claim)

        claim_tokens = self._tokenize(claim)
        claim_phrases = self._extract_phrases(claim)
        claim_neg = self._has_negation(claim)

        best = {
            "verdict": GroundingVerdict.NOT_FOUND,
            "confidence": 0.25,
            "source": None,
            "support": 0.0,
            "contradiction": 0.0,
            "preview": None
        }

        for ch in chunks:
            clean = self._clean(ch.content)
            text_tokens = self._tokenize(clean)
            text_neg = self._has_negation(clean)

            support = self._weighted_overlap(claim_tokens, text_tokens)
            phrases = self._phrase_hits(claim_phrases, clean)
            contradiction = self._contradiction_score(
                claim_tokens, text_tokens, claim_neg, text_neg
            )

            # -------- Absence claims --------
            if is_absence:
                if text_neg and support >= self.MIN_WEIGHTED_SUPPORT:
                    best = self._pick(best, GroundingVerdict.SUPPORTED, 0.7, ch, support, contradiction)
                elif not text_neg and support >= self.MIN_WEIGHTED_CONTRADICTION:
                    best = self._pick(best, GroundingVerdict.CONTRADICTED, 0.85, ch, support, contradiction)
                continue

            # -------- Normal claims --------
            if support >= self.MIN_WEIGHTED_SUPPORT or phrases >= self.MIN_PHRASE_MATCHES:
                if contradiction >= self.MIN_WEIGHTED_CONTRADICTION:
                    best = self._pick(best, GroundingVerdict.CONTRADICTED, 0.9, ch, support, contradiction)
                else:
                    best = self._pick(best, GroundingVerdict.SUPPORTED, 0.8, ch, support, contradiction)

        # Safe abstention
        if is_absence and best["verdict"] == GroundingVerdict.NOT_FOUND:
            best["verdict"] = GroundingVerdict.SAFE_ABSTENTION
            best["confidence"] = 0.55

        return {
            "claim": claim,
            "severity": severity.value,
            "verdict": best["verdict"].value,
            "confidence": round(best["confidence"], 2),
            "source": best["source"],
            "evidence_preview": best["preview"]
        }

    # ======================================================
    # Aggregation logic (critical)
    # ======================================================

    def _aggregate(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        if not results:
            return {"confidence": 0.0}

        confidences = []
        critical_benefit_failure = False
        contradicted = False

        for r in results:
            v = r["verdict"]
            sev = r["severity"]

            if v == GroundingVerdict.CONTRADICTED.value:
                contradicted = True
                confidences.append(0.0)

            elif v == GroundingVerdict.NOT_FOUND.value:
                confidences.append(0.25)
                if sev == ClaimSeverity.BENEFIT.value:
                    critical_benefit_failure = True

            elif v == GroundingVerdict.SAFE_ABSTENTION.value:
                confidences.append(r["confidence"])

            else:
                confidences.append(r["confidence"])

        if contradicted:
            overall = 0.1
        elif critical_benefit_failure:
            overall = min(confidences) * 0.5
        else:
            overall = sum(confidences) / len(confidences)

        return {
            "confidence": round(min(0.95, overall), 2),
            "total_claims": len(results)
        }

    # ======================================================
    # Helpers
    # ======================================================

    def _classify_severity(self, claim: str) -> ClaimSeverity:
        cl = claim.lower()
        if any(k in cl for k in self.PROCEDURAL_KEYWORDS):
            return ClaimSeverity.PROCEDURAL
        if any(k in cl for k in self.BENEFIT_KEYWORDS):
            return ClaimSeverity.BENEFIT
        return ClaimSeverity.FACT

    def _is_absence_claim(self, claim: str) -> bool:
        cl = claim.lower()
        return any(re.search(p, cl) for p in self.ABSENCE_PATTERNS) or self._has_negation(cl)

    def _has_negation(self, text: str) -> bool:
        return any(n in text.lower() for n in self.NEGATION_CUES)

    def _tokenize(self, text: str) -> set:
        tokens = re.findall(r"[a-z0-9₹]+", text.lower())
        return {t for t in tokens if t not in self.STOPWORDS}

    def _weighted_overlap(self, a: set, b: set) -> float:
        return sum(self.DOMAIN_WEIGHTS.get(t, 1.0) for t in a & b)

    def _phrase_hits(self, phrases: List[str], text: str) -> int:
        return sum(1 for p in phrases if p in text)

    def _contradiction_score(self, a: set, b: set, neg_a: bool, neg_b: bool) -> float:
        if neg_a == neg_b:
            return 0.0
        shared = a & b
        return sum(self.DOMAIN_WEIGHTS.get(t, 1.0) for t in shared)

    def _extract_phrases(self, text: str) -> List[str]:
        return re.findall(r"(₹\s*\d+|\b\d{2,5}\b)", text.lower())

    def _clean(self, text: str) -> str:
        return re.sub(r"\s+", " ", text.lower()).strip()

    def _pick(self, cur, verdict, conf, ch, support, contradiction):
        priority = {
            GroundingVerdict.CONTRADICTED: 3,
            GroundingVerdict.SUPPORTED: 2,
            GroundingVerdict.SAFE_ABSTENTION: 1,
            GroundingVerdict.NOT_FOUND: 0
        }
        if priority[verdict] >= priority[cur["verdict"]]:
            return {
                "verdict": verdict,
                "confidence": conf,
                "source": ch.source,
                "support": support,
                "contradiction": contradiction,
                "preview": ch.content[:200]
            }
        return cur

    def _parse_chunk(self, raw: str) -> Chunk:
        score = None
        source = None
        content = raw

        m = re.search(r"score:\s*([0-9.]+)", raw)
        if m:
            score = float(m.group(1))

        m = re.search(r"source:\s*([^,\n]+)", raw)
        if m:
            source = m.group(1).strip()

        m = re.search(r"content:\s*(.*)", raw, re.DOTALL)
        if m:
            content = m.group(1).strip()

        return Chunk(content=content, score=score, source=source)

    def _filter_chunks(self, chunks: List[Chunk]) -> List[Chunk]:
        if self.MAX_RETRIEVAL_SCORE is None:
            return chunks
        return [c for c in chunks if c.score is None or c.score <= self.MAX_RETRIEVAL_SCORE]
