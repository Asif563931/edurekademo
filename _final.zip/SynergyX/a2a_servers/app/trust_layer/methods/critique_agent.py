from langchain_core.output_parsers import PydanticOutputParser
from langchain_core.prompts import ChatPromptTemplate
from pydantic import BaseModel, Field
from helpers.get_llm import get_large_llm, get_small_llm

def critique_agent(
    user_query,
    query_entities,
    evidence_entities,
    retrieved_info,
    final_llm_answer,
    confidence_score,
    hallucinated,
    risk_level
):
    class CritiqueResult(BaseModel):
        revaluated_score: float = Field(
            description="Re-evaluated confidence score between 0 and 100"
        )
        reason: str = Field(
            description="Clear explanation justifying the re-evaluated score"
        )

    parser = PydanticOutputParser(pydantic_object=CritiqueResult)

    prompt = ChatPromptTemplate.from_template(
        """
    You are a **Critique and Confidence Re-evaluation Agent**.
    Your role is to assess the **factual reliability** of an LLM-generated answer
    using only the information provided.

    You are given:
    - The original user query
    - Telecom entities extracted from the user query
    - Telecom entities present in the retrieved evidence
    - Retrieved contextual information (ground truth)
    - The LLM's final answer
    - Hallucination detection result
    - Risk classification
    - The original confidence score assigned to the answer

    ─────────────────────────────────────────
    EVALUATION OBJECTIVES
    ─────────────────────────────────────────
    Re-evaluate the confidence score by strictly analyzing:

    1. **Entity Alignment**
    - Are all query entities supported by evidence entities?
    - Are there missing, extra, or mismatched entities?

    2. **Evidence Faithfulness**
    - Is every factual claim in the answer directly supported
        by the retrieved information?
    - Does the answer introduce assumptions or inferred details?

    3. **Hallucination Assessment**
    - Does the answer contain unsupported, speculative,
        or fabricated information?
    - Consider the provided hallucination signal as an input,
        but independently validate claims against evidence.

    4. **Risk Sensitivity**
    - For MEDIUM or HIGH risk queries, apply stricter scrutiny.
    - Penalize uncertainty or unsupported claims more heavily.

    ─────────────────────────────────────────
    SCORING RULES (STRICT)
    ─────────────────────────────────────────
    - You MUST NOT increase the confidence score.
    - The revised score MUST be in the range:
        0.0 ≤ revised_score ≤ original confidence score
    - If the answer is already well-supported and faithful,
    return the original confidence score unchanged.
    - Reduce the score proportionally based on:
    - Entity mismatches
    - Unsupported or hallucinated claims
    - Evidence insufficiency

    ─────────────────────────────────────────
    OUTPUT REQUIREMENTS
    ─────────────────────────────────────────
    - Provide a **single revised confidence score**
    - Provide a **clear, concise explanation** justifying the score
    - Reference specific issues (entity gaps, hallucinations, evidence mismatch)
    - Do NOT introduce new facts or assumptions
    - Do NOT suggest fixes or alternative answers

    ─────────────────────────────────────────
    INPUTS
    ─────────────────────────────────────────
    User Query:
    {user_query}

    Query Entities:
    {query_entities}

    Evidence Entities:
    {evidence_entities}

    Retrieved Information:
    {retrieved_info}

    LLM Answer:
    {final_llm_answer}

    Original Confidence Score:
    {confidence_score}

    Hallucinated:
    {hallucinated}

    Risk Level:
    {risk_level}

    {format_instructions}
    """
    )


    llm = get_small_llm()

    chain = prompt | llm | parser

    result = chain.invoke({
        "user_query": user_query,
        "query_entities": query_entities,
        "evidence_entities": evidence_entities,
        "retrieved_info": retrieved_info,
        "final_llm_answer": final_llm_answer,
        "confidence_score": confidence_score,
        "hallucinated": hallucinated,
        "risk_level": risk_level,
        "format_instructions": parser.get_format_instructions()
    })

    return result
