from typing import Any, List, Set, Dict
import re
from trust_layer.utils.text import extract_claims


class MultiSampleAgreement:
    """
    Detects instability across multiple LLM samples.

    IMPORTANT:
    - High agreement does NOT imply correctness
    - Low agreement implies instability → increase scrutiny
    - This module must NEVER override grounding validation
    """

    MIN_SAMPLES = 2
    MAX_SAMPLES = 5

    PROCEDURAL_PHRASES = {
        "contact customer support",
        "contact support",
        "reach out to support",
        "please contact",
        "visit the store",
        "raise a ticket"
    }

    BENEFIT_KEYWORDS = {
        "free", "included", "unlimited", "addon", "add-on",
        "subscription", "netflix", "ott", "complimentary"
    }

    STOPWORDS = {
        "the", "a", "an", "and", "or", "to", "of", "in", "on",
        "for", "with", "is", "are", "was", "were", "be"
    }

    def __init__(self, llm: Any, samples: int = 3):
        if samples < self.MIN_SAMPLES:
            raise ValueError("At least 2 samples required for agreement check")
        self.llm = llm
        self.samples = min(samples, self.MAX_SAMPLES)

    # --------------------------------------------------
    # Public API
    # --------------------------------------------------

    def run(self, prompt: str) -> Dict[str, Any]:
        responses: List[str] = []
        claim_sets: List[Set[str]] = []
        evasive_count = 0

        for _ in range(self.samples):
            raw = self.llm.invoke(prompt)
            text = self._safe_text(getattr(raw, "content", raw))

            responses.append(text)

            claims = extract_claims(text)
            norm_claims = {
                self._normalize_claim(c)
                for c in claims
                if self._is_substantive_claim(c)
            }

            if not norm_claims and self._is_evasive(text):
                evasive_count += 1

            claim_sets.append(norm_claims)

        instability = self._compute_instability(claim_sets)

        return {
            "responses": responses,
            "instability_score": round(instability, 2),
            "evasive_ratio": round(evasive_count / self.samples, 2),
            "common_claims": sorted(self._safe_intersection(claim_sets)),
            "divergent_claims": sorted(self._safe_divergence(claim_sets)),
            "note": self._interpret(instability, evasive_count)
        }

    # --------------------------------------------------
    # Core logic
    # --------------------------------------------------

    def _compute_instability(self, claim_sets: List[Set[str]]) -> float:
        if all(len(c) == 0 for c in claim_sets):
            return 1.0  # total uncertainty

        union = self._safe_union(claim_sets)
        intersection = self._safe_intersection(claim_sets)

        if not union:
            return 1.0

        raw_disagreement = 1.0 - (len(intersection) / len(union))

        benefit_penalty = self._benefit_disagreement_penalty(union, intersection)

        return min(1.0, raw_disagreement + benefit_penalty)

    # --------------------------------------------------
    # Claim normalization
    # --------------------------------------------------

    def _normalize_claim(self, claim: str) -> str:
        text = claim.lower()
        text = re.sub(r"[₹$,]", "", text)
        text = re.sub(r"\b(rs|inr)\b", "", text)
        text = re.sub(r"\s+", " ", text).strip()

        tokens = [
            t for t in re.findall(r"\w+", text)
            if t not in self.STOPWORDS
        ]

        return " ".join(tokens)

    def _is_substantive_claim(self, claim: str) -> bool:
        cl = claim.lower()
        banned = [
            "not available",
            "no information",
            "cannot be found",
            "not mentioned"
        ]
        return not any(b in cl for b in banned)

    # --------------------------------------------------
    # Risk heuristics
    # --------------------------------------------------

    def _benefit_disagreement_penalty(
        self, union: Set[str], intersection: Set[str]
    ) -> float:
        benefit_claims = {
            c for c in union
            if any(k in c for k in self.BENEFIT_KEYWORDS)
        }

        if not benefit_claims:
            return 0.0

        agreed_benefits = benefit_claims & intersection
        disagreement_ratio = 1.0 - (len(agreed_benefits) / len(benefit_claims))

        return disagreement_ratio * 0.4  # bounded risk amplifier

    # --------------------------------------------------
    # Evasion detection
    # --------------------------------------------------

    def _is_evasive(self, text: str) -> bool:
        tl = text.lower()
        return any(p in tl for p in self.PROCEDURAL_PHRASES)

    # --------------------------------------------------
    # Set safety
    # --------------------------------------------------

    def _safe_union(self, sets: List[Set[str]]) -> Set[str]:
        return set.union(*sets) if sets else set()

    def _safe_intersection(self, sets: List[Set[str]]) -> Set[str]:
        return set.intersection(*sets) if sets else set()

    def _safe_divergence(self, sets: List[Set[str]]) -> Set[str]:
        return self._safe_union(sets) - self._safe_intersection(sets)

    # --------------------------------------------------
    # Interpretation
    # --------------------------------------------------

    def _interpret(self, instability: float, evasive: int) -> str:
        if evasive == self.samples:
            return "All samples were evasive; model avoided factual claims."
        if instability > 0.7:
            return "High instability across samples; increase scrutiny."
        if instability > 0.4:
            return "Moderate instability; verify critical claims."
        return "Low instability; no action required."

    # --------------------------------------------------
    # Utils
    # --------------------------------------------------

    def _safe_text(self, content: Any) -> str:
        if content is None:
            return ""
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            return "\n".join(str(c) for c in content)
        if isinstance(content, dict):
            return str(content)
        return str(content)
