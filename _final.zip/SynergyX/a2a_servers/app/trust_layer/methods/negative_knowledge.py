from typing import List


class NegativeKnowledgeInjector:
    """
    Prompt guard to explicitly declare unavailable information
    and STRICTLY prevent hallucinated completion of missing facts.

    This guard is designed to work in tandem with
    post-generation claim grounding validation.
    """

    MAX_ITEMS = 8  # prevent prompt bloat

    def apply(
        self,
        user_query: str,
        missing_information: List[str]
    ) -> str:
        missing = list({
            item.strip()
            for item in missing_information
            if item and item.strip()
        })[:self.MAX_ITEMS]

        # -----------------------------
        # HARD CONSTRAINTS (NON-NEGOTIABLE)
        # -----------------------------
        guard_lines = [
            "SYSTEM CONSTRAINTS (HARD RULES):",
            "1. You are NOT allowed to guess, infer, generalize, or estimate missing information.",
            "2. You may ONLY state facts that are explicitly supported by the provided evidence.",
            "3. If a required fact is missing, you MUST respond using the exact refusal phrase defined below.",
            "4. Do NOT use hedging language such as 'typically', 'usually', 'often', or 'may'.",
            "5. Do NOT introduce examples, norms, or industry practices unless explicitly provided."
        ]

        # -----------------------------
        # NEGATIVE KNOWLEDGE DECLARATION
        # -----------------------------
        if missing:
            guard_lines.append("\nUNAVAILABLE INFORMATION (DO NOT ATTEMPT TO ANSWER):")
            for item in missing:
                guard_lines.append(f"- {item}")

            guard_lines.append(
                "\nMANDATORY REFUSAL FORMAT FOR MISSING FACTS:\n"
                "\"This information is not available in the provided data.\""
            )
        else:
            guard_lines.append(
                "\nAll required information is available. Answer strictly from evidence."
            )

        guard = "\n".join(guard_lines)

        # -----------------------------
        # FINAL PROMPT
        # -----------------------------
        final_prompt = f"""{guard}

USER QUESTION:
{user_query}

RESPONSE RULES:
- Answer ONLY what is directly supported by evidence.
- If a question has multiple parts, answer ONLY the supported parts.
- For unsupported parts, use the mandatory refusal format verbatim.
- Do NOT combine supported and unsupported facts into a single sentence.
- Be concise, factual, and neutral in tone.
"""

        return final_prompt
