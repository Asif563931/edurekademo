#!/usr/bin/env python
"""Mock dependencies for testing LLM detector."""

import json
import os
from pathlib import Path

class MockPromptUtils:
    @staticmethod
    def format_context(context, question, lang):
        if question:
            return f"Question: {question}\nContext: {' '.join(context)}"
        return f"Context: {' '.join(context)}"
    
    @staticmethod
    def get_full_language_name(lang):
        return {"en": "English", "de": "German"}.get(lang, "English")

class MockCacheManager:
    def __init__(self, file_path):
        self.data = {}
    
    def get(self, key):
        return self.data.get(key)
    
    def set(self, key, value):
        self.data[key] = value
    
    @staticmethod
    def _hash(*parts):
        return str(hash("||".join(parts)))

def setup_mock_files():
    """Create necessary mock files for testing."""
    os.makedirs("prompts", exist_ok=True)
    
    # Mock prompt template compatible with LangChain
    prompt_content = """You are detecting hallucinations in $lang.
Context: $context
Answer: $answer
$fewshot_block
Return JSON with hallucination_list format: {"hallucination_list": ["text1", "text2"]}."""
    
    with open("prompts/hallucination_detection.txt", "w") as f:
        f.write(prompt_content)
    
    # Mock examples
    examples = [{
        "source": "The sky is blue",
        "answer": "The sky is blue and made of cheese",
        "hallucination_list": ["made of cheese"]
    }]
    
    with open("prompts/examples_en.json", "w") as f:
        json.dump(examples, f)

if __name__ == "__main__":
    setup_mock_files()
    print("Mock files created successfully")