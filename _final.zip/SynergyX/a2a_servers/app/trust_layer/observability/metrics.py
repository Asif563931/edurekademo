class Metrics:
    def __init__(self):
        self.data = {}

    def emit(self, name: str, value):
        self.data[name] = value

    def report(self):
        return self.data
