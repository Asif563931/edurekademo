import time

class Trace:
    def __init__(self, name):
        self.name = name
        self.start = time.time()
        self.events = []

    def log(self, message, data=None):
        self.events.append({
            "message": message,
            "data": data
        })

    def end(self):
        return {
            "trace": self.name,
            "duration_ms": int((time.time() - self.start) * 1000),
            "events": self.events
        }
