# Hallucination Detection Guidelines

## Core Principles

### 1. Precision Over Recall
- Only flag definitive hallucinations
- When in doubt, do not flag
- Better to miss some hallucinations than create false positives

### 2. Context Dependency
- All claims must be verifiable against provided context
- Absence of information in context ≠ hallucination
- Consider context completeness and scope

### 3. Granular Detection
- Flag specific phrases, not entire sentences
- Identify exact boundaries of hallucinated content
- Separate factual from hallucinated parts

## Hallucination Categories

### Critical (Always Flag)
- **Contradictory Facts**: Direct contradiction of context
- **Fabricated Numbers**: Specific prices, dates, quantities not in context
- **False Attribution**: Incorrect source or company names
- **Made-up Features**: Technical specs not mentioned in context

### Moderate (Flag if Clear)
- **Overgeneralization**: Broad claims from limited context
- **Temporal Errors**: Outdated info presented as current
- **Scope Violations**: Claims outside context domain
- **Inference Errors**: Wrong conclusions from context

### Low Priority (Flag Only if Obvious)
- **Minor Inconsistencies**: Small discrepancies in details
- **Ambiguous Statements**: Unclear or vague claims
- **Stylistic Issues**: Tone or presentation problems

## Domain-Specific Rules

### Telecom/Technology
- Verify all pricing information
- Check service availability claims
- Validate technical specifications
- Confirm feature compatibility

### Financial/Business
- Verify monetary amounts
- Check regulatory compliance claims
- Validate business processes
- Confirm policy details

### Healthcare/Safety
- Strict verification of medical claims
- Validate safety procedures
- Check regulatory compliance
- Confirm dosage/usage information

## Detection Process

1. **Parse Context**: Understand available information
2. **Analyze Claims**: Break down answer into verifiable statements
3. **Cross-Reference**: Match claims against context
4. **Flag Violations**: Identify unsupported or contradictory content
5. **Validate Spans**: Ensure precise text boundaries

## Quality Assurance

- Review flagged spans for accuracy
- Ensure no false positives
- Verify span boundaries are correct
- Check for missed obvious hallucinations