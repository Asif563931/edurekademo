#!/usr/bin/env python
"""Run all LLM detector tests."""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from mock_dependencies import setup_mock_files

def run_all_tests():
    """Run all test suites."""
    print("Setting up mock files...")
    setup_mock_files()
    
    print("\n=== Running Unit Tests ===")
    try:
        import test_llm_detector
        print("Unit tests completed successfully")
    except Exception as e:
        print(f"Unit tests failed: {e}")
    
    print("\n=== Running Integration Tests ===")
    try:
        import test_llm_integration
        print("Integration tests completed")
    except Exception as e:
        print(f"Integration tests failed: {e}")
    
    print("\n=== Running Consortium Tests ===")
    try:
        import test_consortium
        print("Consortium tests completed")
    except Exception as e:
        print(f"Consortium tests failed: {e}")

if __name__ == "__main__":
    run_all_tests()