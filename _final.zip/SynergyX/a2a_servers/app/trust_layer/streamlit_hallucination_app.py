#!/usr/bin/env python3
"""Streamlit app for interactive hallucination detection."""

import streamlit as st
import sys
import os
from pathlib import Path

# Add parent directories to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from detectors.llm import LLMDetector

# Page config
st.set_page_config(
    page_title="Hallucination Detector",
    page_icon="🔍",
    layout="wide"
)

def init_detector():
    """Initialize detector with caching."""
    if 'detector' not in st.session_state:
        domain = st.session_state.get('domain', 'general')
        try:
            st.session_state.detector = LLMDetector(
                model="gpt-4o-mini",
                temperature=0.0,
                lang="en",
                domain=domain
            )
            return True
        except Exception as e:
            st.error(f"Failed to initialize detector: {e}")
            return False
    return True

def highlight_hallucinations(text, spans):
    """Highlight hallucinated spans in text."""
    if not spans:
        return text
    
    # Sort spans by start position (reverse order for replacement)
    sorted_spans = sorted(spans, key=lambda x: x.get('start', 0), reverse=True)
    
    highlighted_text = text
    for span in sorted_spans:
        start = span.get('start', 0)
        end = span.get('end', len(span.get('text', '')))
        hallucinated_part = text[start:end]
        
        # Replace with highlighted version
        highlighted_text = (
            highlighted_text[:start] + 
            f":red[**{hallucinated_part}**]" + 
            highlighted_text[end:]
        )
    
    return highlighted_text

def main():
    """Main Streamlit app."""
    
    # Header
    st.title("🔍 Hallucination Detector")
    st.markdown("Detect factual errors and inconsistencies in AI-generated responses")
    
    # Sidebar for settings
    with st.sidebar:
        st.header("⚙️ Settings")
        
        domain = st.selectbox(
            "Detection Domain",
            ["general", "telecom", "financial", "healthcare", "ecommerce"],
            index=0
        )
        
        if 'domain' not in st.session_state or st.session_state.domain != domain:
            st.session_state.domain = domain
            if 'detector' in st.session_state:
                del st.session_state.detector
        
        st.markdown("---")
        st.markdown("### Domain Focus")
        domain_info = {
            "general": "General fact-checking",
            "telecom": "Pricing, plans, services",
            "financial": "Rates, fees, compliance",
            "healthcare": "Medical claims, dosages",
            "ecommerce": "Products, pricing, shipping"
        }
        st.info(domain_info[domain])
    
    # Initialize detector
    if not init_detector():
        st.stop()
    
    # Main interface
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.header("📝 Input")
        
        # Context input
        context = st.text_area(
            "Context (Background Information)",
            height=150,
            placeholder="Enter the factual context or source material..."
        )
        
        # Query input
        query = st.text_input(
            "Query (Optional)",
            placeholder="Enter the original question..."
        )
        
        # Answer input
        answer = st.text_area(
            "LLM Answer to Analyze",
            height=200,
            placeholder="Enter the AI-generated response to check for hallucinations..."
        )
        
        # Analyze button
        analyze_btn = st.button("🔍 Analyze for Hallucinations", type="primary")
    
    with col2:
        st.header("📊 Results")
        
        if analyze_btn:
            if not answer.strip():
                st.warning("Please enter an answer to analyze.")
            else:
                with st.spinner("Analyzing for hallucinations..."):
                    try:
                        # Perform detection
                        context_list = [context] if context.strip() else []
                        query_param = query.strip() if query.strip() else None
                        
                        spans = st.session_state.detector.predict(
                            context=context_list,
                            answer=answer,
                            question=query_param
                        )
                        
                        # Display results
                        if spans:
                            st.error(f"🚨 Found {len(spans)} hallucination(s)")
                            
                            # Highlighted text
                            st.subheader("Highlighted Answer")
                            highlighted = highlight_hallucinations(answer, spans)
                            st.markdown(highlighted)
                            
                            # Detailed results
                            st.subheader("Detected Hallucinations")
                            for i, span in enumerate(spans, 1):
                                with st.expander(f"Hallucination {i}: \"{span.get('text', '')}\""):
                                    st.write(f"**Text:** {span.get('text', '')}")
                                    st.write(f"**Position:** {span.get('start', 0)}-{span.get('end', 0)}")
                                    
                                    # Context around hallucination
                                    start = span.get('start', 0)
                                    end = span.get('end', 0)
                                    context_start = max(0, start - 30)
                                    context_end = min(len(answer), end + 30)
                                    context_snippet = answer[context_start:context_end]
                                    st.write(f"**Context:** ...{context_snippet}...")
                        else:
                            st.success("✅ No hallucinations detected!")
                            st.balloons()
                            
                    except Exception as e:
                        st.error(f"Error during analysis: {e}")
    
    # Chat interface section
    st.markdown("---")
    st.header("💬 Chat Interface")
    
    # Initialize chat history
    if "messages" not in st.session_state:
        st.session_state.messages = []
    
    # Display chat messages
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            if message["role"] == "assistant" and "spans" in message:
                # Show highlighted text for assistant messages with hallucinations
                if message["spans"]:
                    st.markdown("**Analysis Result:**")
                    highlighted = highlight_hallucinations(message["content"], message["spans"])
                    st.markdown(highlighted)
                    st.caption(f"Found {len(message['spans'])} hallucination(s)")
                else:
                    st.markdown(message["content"])
                    st.caption("✅ No hallucinations detected")
            else:
                st.markdown(message["content"])
    
    # Chat input
    if prompt := st.chat_input("Enter context | query | answer (separated by |)"):
        # Add user message to chat history
        st.session_state.messages.append({"role": "user", "content": prompt})
        
        # Parse input (context | query | answer)
        parts = [p.strip() for p in prompt.split("|")]
        
        if len(parts) >= 2:
            chat_context = parts[0] if parts[0] else ""
            chat_query = parts[1] if len(parts) > 2 and parts[1] else ""
            chat_answer = parts[-1]
            
            # Perform analysis
            try:
                context_list = [chat_context] if chat_context else []
                query_param = chat_query if chat_query else None
                
                spans = st.session_state.detector.predict(
                    context=context_list,
                    answer=chat_answer,
                    question=query_param
                )
                
                # Add assistant response
                result_msg = f"Analyzed: \"{chat_answer[:50]}{'...' if len(chat_answer) > 50 else ''}\""
                st.session_state.messages.append({
                    "role": "assistant", 
                    "content": result_msg,
                    "spans": spans
                })
                
            except Exception as e:
                st.session_state.messages.append({
                    "role": "assistant", 
                    "content": f"Error: {e}"
                })
        else:
            st.session_state.messages.append({
                "role": "assistant", 
                "content": "Please use format: context | query | answer (query is optional)"
            })
        
        st.rerun()

if __name__ == "__main__":
    main()