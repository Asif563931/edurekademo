def extract_claims(text: str) -> list[str]:
    sentences = text.replace("\n", ".").split(".")
    return [s.strip() for s in sentences if len(s.strip()) > 5]
