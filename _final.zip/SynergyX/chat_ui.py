import streamlit as st
import requests

API_URL = "http://localhost:9090/chat"

st.set_page_config(page_title="A2A Chat", page_icon="💬")
st.title("💬 A2A Agent Chat")

if "history" not in st.session_state:
    st.session_state.history = []

# Show chat history
for msg in st.session_state.history:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# Chat input
user_input = st.chat_input("Ask something...")

if user_input:
    # Show user message
    st.session_state.history.append(
        {"role": "user", "content": user_input}
    )
    with st.chat_message("user"):
        st.markdown(user_input)

    # Call FastAPI GET /chat
    with st.spinner("Agent thinking..."):
        try:
            resp = requests.get(
                API_URL,
                params={"query": user_input},
                timeout=130
            )
            resp.raise_for_status()

            # A2A usually returns structured content
            data = resp.json() if resp.headers.get("content-type", "").startswith("application/json") else resp.text

            answer = (
                data.get("content", {}).get("text")
                if isinstance(data, dict)
                else str(data)
            )

        except Exception as e:
            answer = f"❌ API error: {e}"

    # Show assistant message
    st.session_state.history.append(
        {"role": "assistant", "content": answer}
    )
    with st.chat_message("assistant"):
        st.markdown(answer)
