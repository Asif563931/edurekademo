import psycopg2
import os
from contextlib import contextmanager

DATABASE_URL = os.getenv("HAL_DATABASE_URL", "postgresql://hal_admin:hal_password@hal-postgres:5432/hal_db")

@contextmanager
def get_db_connection():
    conn = None
    try:
        conn = psycopg2.connect(DATABASE_URL)
        yield conn
    finally:
        if conn:
            conn.close()

def get_conversation_count():
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(DISTINCT conversation_id) FROM conversations")
            result = cursor.fetchone()[0]
            print(f"Database query result: {result}")
            return result
    except Exception as e:
        print(f"Database error: {str(e)}")
        raise e

def get_hallucination_count():
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM hallucination_detection WHERE hallucination_reason != 'NO HALLUCINATION_DETECTED'")
            result = cursor.fetchone()[0]
            print(f"Hallucination count: {result}")
            return result
    except Exception as e:
        print(f"Hallucination count error: {str(e)}")
        raise e

def get_avg_confidence_score():
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT AVG(confidence_score) FROM conversations WHERE confidence_score IS NOT NULL")
            result = cursor.fetchone()[0]
            avg_confidence = round(result, 1) if result else 0
            print(f"Average confidence: {avg_confidence}%")
            return avg_confidence
    except Exception as e:
        print(f"Average confidence error: {str(e)}")
        raise e

def get_recent_conversations(page=1, limit=10):
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            offset = (page - 1) * limit
            cursor.execute("""
                SELECT created_at, user_message, ai_response, confidence_score 
                FROM conversations 
                ORDER BY created_at DESC 
                LIMIT %s OFFSET %s
            """, (limit, offset))
            results = cursor.fetchall()
            conversations = []
            for row in results:
                conversations.append({
                    "timestamp": row[0].strftime("%Y-%m-%d %H:%M:%S") if row[0] else "",
                    "query": row[1] or "",
                    "response": row[2] or "",
                    "confidence": round(row[3], 1) if row[3] else 0
                })
            print(f"Recent conversations fetched: {len(conversations)}")
            return conversations
    except Exception as e:
        print(f"Recent conversations error: {str(e)}")
        raise e

def get_hallucinated_conversations():
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT 
                    c.id,
                    c.created_at,
                    c.user_message,
                    c.ai_response,
                    c.confidence_score,
                    c.critique_score,
                    c.critique_verdict,
                    c.completeness,
                    h.hallucination_score,
                    h.hallucination_reason,
                    h.severity
                FROM conversations c
                JOIN hallucination_detection h ON c.id = h.conversation_id
                WHERE h.hallucination_reason != 'NO HALLUCINATION_DETECTED'
                ORDER BY c.created_at DESC
                LIMIT 5
            """)
            results = cursor.fetchall()
            conversations = []
            for row in results:
                conversations.append({
                    "id": row[0],
                    "timestamp": row[1].strftime("%Y-%m-%d %H:%M:%S") if row[1] else "",
                    "query": row[2] or "",
                    "response": row[3] or "",
                    "confidence": round(row[4], 1) if row[4] else 0,
                    "critiqueScore": round(row[5], 1) if row[5] else 0,
                    "critiqueVerdict": row[6] or "",
                    "completeness": row[7] or "",
                    "hallucinationScore": round(row[8], 1) if row[8] else 0,
                    "hallucinationReason": row[9] or "",
                    "severity": row[10] or "medium"
                })
            print(f"Hallucinated conversations fetched: {len(conversations)}")
            return conversations
    except Exception as e:
        print(f"Hallucinated conversations error: {str(e)}")
        raise e

def get_all_conversations(page=1, limit=5):
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            offset = (page - 1) * limit
            cursor.execute("""
                SELECT 
                    c.id,
                    c.created_at,
                    c.user_message,
                    c.ai_response,
                    c.confidence_score,
                    c.critique_score,
                    c.critique_verdict,
                    c.completeness,
                    COALESCE(h.hallucination_score, 0) as hallucination_score,
                    COALESCE(h.hallucination_reason, 'NO HALLUCINATION_DETECTED') as hallucination_reason,
                    COALESCE(h.severity, 'low') as severity
                FROM conversations c
                LEFT JOIN hallucination_detection h ON c.id = h.conversation_id
                ORDER BY c.created_at DESC
                LIMIT %s OFFSET %s
            """, (limit, offset))
            results = cursor.fetchall()
            conversations = []
            for row in results:
                is_hallucinated = row[9] != 'NO HALLUCINATION_DETECTED'
                conversations.append({
                    "id": row[0],
                    "timestamp": row[1].strftime("%Y-%m-%d %H:%M:%S") if row[1] else "",
                    "query": row[2] or "",
                    "response": row[3] or "",
                    "confidence": round(row[4], 1) if row[4] else 0,
                    "critiqueScore": round(row[5], 1) if row[5] else 0,
                    "critiqueVerdict": row[6] or "",
                    "completeness": row[7] or "",
                    "hallucinationScore": round(row[8], 1) if row[8] else 0,
                    "hallucinationReason": row[9] or "",
                    "severity": row[10] or "low",
                    "isHallucinated": is_hallucinated
                })
            print(f"All conversations fetched: {len(conversations)}")
            return conversations
    except Exception as e:
        print(f"All conversations error: {str(e)}")
        raise e

def get_current_methods():
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT llm_eval, ml_eval, llm_judge, completeness_check, neg_kw, claim_ground, msa, ensemble, hybrid_rag, query_expansion FROM methods WHERE id = 1")
            result = cursor.fetchone()
            if result:
                return {
                    'generative_quality_assessment_layer': result[0],  # llm_eval
                    'ml_powered_hallucination_detection': result[1],   # ml_eval
                    'red_team_reasoner': result[2],                    # llm_judge
                    'grounding_based_on_entities': result[3],          # completeness_check
                    'anti_hallucination_knowledge_gate': result[4],   # neg_kw
                    'evidence_binding_layer': result[5],              # claim_ground
                    'consensus_validation_engine': result[7],         # ensemble
                    'hybrid_rag': result[8],                          # hybrid_rag
                    'contextual_query_amplifier': result[9]           # query_expansion
                }
            return {}
    except Exception as e:
        print(f"Get methods error: {str(e)}")
        return {}

def update_methods(techniques):
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO methods (id, llm_eval, ml_eval, llm_judge, completeness_check, 
                    neg_kw, claim_ground, msa, ensemble, hybrid_rag, query_expansion)
                VALUES (1, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (id) DO UPDATE SET
                    llm_eval = EXCLUDED.llm_eval,
                    ml_eval = EXCLUDED.ml_eval,
                    llm_judge = EXCLUDED.llm_judge,
                    completeness_check = EXCLUDED.completeness_check,
                    neg_kw = EXCLUDED.neg_kw,
                    claim_ground = EXCLUDED.claim_ground,
                    msa = EXCLUDED.msa,
                    ensemble = EXCLUDED.ensemble,
                    hybrid_rag = EXCLUDED.hybrid_rag,
                    query_expansion = EXCLUDED.query_expansion,
                    updated_at = CURRENT_TIMESTAMP
            """, (
                techniques.get('llm_eval', False),
                techniques.get('ml_eval', False),
                techniques.get('llm_judge', False),
                techniques.get('completeness_check', False),
                techniques.get('neg_kw', False),
                techniques.get('claim_ground', False),
                techniques.get('msa', False),
                techniques.get('ensemble', False),
                techniques.get('hybrid_rag', False),
                techniques.get('query_expansion', False)
            ))
            conn.commit()
            return True
    except Exception as e:
        print(f"Update methods error: {str(e)}")
        raise e