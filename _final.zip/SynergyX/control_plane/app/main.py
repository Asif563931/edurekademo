from fastapi import FastAPI
import uuid
from fastapi.responses import StreamingResponse
import time
import re
import requests
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from database import get_conversation_count, get_hallucination_count, get_avg_confidence_score, get_recent_conversations, get_hallucinated_conversations, get_all_conversations, update_methods, get_current_methods

from python_a2a import A2AClient, Message, TextContent, MessageRole
URL = "http://backend:9091"
app = FastAPI()
# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins (restrict in production)
    allow_credentials=True,
    allow_methods=["*"],  # Allow all HTTP methods
    allow_headers=["*"],  # Allow all headers
)

tasks = {}

@app.post("/tasks")
def create_task(payload: dict):
    task_id = str(uuid.uuid4())
    tasks[task_id] = payload["message"]
    return {"task_id": task_id}


def agent_stream(task_id: str):
    user_message = tasks[task_id]
    client = A2AClient(orchestrator_url)
    msg = Message(
        role=MessageRole.USER,
        content=TextContent(text=user_message)
    )
    # Simulate agent reasoning / LLM tokens
    resp = client.send_message(user_message)
    print("Response from Orcestrator: ", resp)
    return resp

@app.get("/tasks/{task_id}/stream")
def stream_task(task_id: str):
    return StreamingResponse(
        agent_stream(task_id),
        media_type="text/event-stream"
    )

class ChatRequest(BaseModel):
    message: str
    methods: list = []
    preset: str = "balanced"

@app.post("/api/chat")
def chat_endpoint(request: ChatRequest):
    try:
        client = A2AClient(orchestrator_url)
        msg = Message(
            role=MessageRole.USER,
            content=TextContent(text=request.message)
        )
        
        resp = client.send_message(msg)
        print("Response from Orchestrator: ", resp)
        
        # Get current applied methods
        current_methods = get_current_methods()
        applied_methods = [name.replace('_', ' ').title() for name, enabled in current_methods.items() if enabled]
        
        return {
            "id": int(time.time() * 1000),
            "type": "assistant",
            "content": resp.content.text if hasattr(resp.content, 'text') else str(resp),
            "timestamp": time.strftime("%H:%M:%S"),
            "confidence": 0.89,
            "methods": applied_methods,
            "sources": ["Knowledge Base", "Fact Checker"]
        }
    except Exception as e:
        print(f"Error: {e}")
        return {
            "id": int(time.time() * 1000),
            "type": "error",
            "content": f"Error: {str(e)}",
            "timestamp": time.strftime("%H:%M:%S"),
            "confidence": 0.0,
            "methods": [],
            "sources": []
        }

@app.get("/api/agent-steps")
def get_agent_steps():
    return [
        {"agent_id": "retrieval_agent", "action": "Searching knowledge base", "execution_time_ms": 850, "status": "completed", "agent_type": "RETRIEVAL"},
        {"agent_id": "fact_checker_agent", "action": "Fact-checking information", "execution_time_ms": 1200, "status": "completed", "agent_type": "FACT_CHECKER"},
        {"agent_id": "confidence_scorer_agent", "action": "Calculating confidence", "execution_time_ms": 650, "status": "completed", "agent_type": "CONFIDENCE_SCORER"}
    ]

@app.get("/api/conversation-count")
def get_conversation_count_endpoint():
    try:
        count = get_conversation_count()
        print(f"Conversation count fetched: {count}")
        return {"count": count}
    except Exception as e:
        print(f"Error fetching conversation count: {str(e)}")
        return {"count": 0, "error": str(e)}

@app.get("/api/hallucination-count")
def get_hallucination_count_endpoint():
    try:
        count = get_hallucination_count()
        print(f"Hallucination count fetched: {count}")
        return {"count": count}
    except Exception as e:
        print(f"Error fetching hallucination count: {str(e)}")
        return {"count": 0, "error": str(e)}

@app.get("/api/avg-confidence")
def get_avg_confidence_endpoint():
    try:
        avg_confidence = get_avg_confidence_score()
        print(f"Average confidence fetched: {avg_confidence}")
        return {"avgConfidence": avg_confidence}
    except Exception as e:
        print(f"Error fetching average confidence: {str(e)}")
        return {"avgConfidence": 0, "error": str(e)}

@app.get("/api/recent-conversations")
def get_recent_conversations_endpoint(page: int = 1, limit: int = 10):
    try:
        conversations = get_recent_conversations(page, limit)
        print(f"Recent conversations fetched: {len(conversations)}")
        return {"conversations": conversations}
    except Exception as e:
        print(f"Error fetching recent conversations: {str(e)}")
        return {"conversations": [], "error": str(e)}

@app.get("/api/hallucinated-conversations")
def get_hallucinated_conversations_endpoint():
    try:
        conversations = get_hallucinated_conversations()
        print(f"Hallucinated conversations fetched: {len(conversations)}")
        return {"conversations": conversations}
    except Exception as e:
        print(f"Error fetching hallucinated conversations: {str(e)}")
        return {"conversations": [], "error": str(e)}

@app.get("/api/all-conversations")
def get_all_conversations_endpoint(page: int = 1, limit: int = 5):
    try:
        conversations = get_all_conversations(page, limit)
        print(f"All conversations fetched: {len(conversations)}")
        return {"conversations": conversations}
    except Exception as e:
        print(f"Error fetching all conversations: {str(e)}")
        return {"conversations": [], "error": str(e)}

@app.get("/chat")
def chat_stream(query: str):
    client = A2AClient(orchestrator_url)
    msg = Message(
        role=MessageRole.USER,
        content=TextContent(text=query)
    )
    resp = client.send_message(msg)
    print("Response from Orcestrator: ", resp)
    return resp.content.text

@app.get("/api/get-methods")
def get_methods_endpoint():
    try:
        methods = get_current_methods()
        return {"success": True, "methods": methods}
    except Exception as e:
        return {"success": False, "methods": {}, "error": str(e)}

@app.post("/api/update-methods")
def update_methods_endpoint(request_data: dict):
    # Map frontend method names to database column names
    method_mapping = {
        'anti_hallucination_knowledge_gate': 'neg_kw',
        'evidence_binding_layer': 'claim_ground', 
        'grounding_based_on_entities': 'completeness_check',
        'consensus_validation_engine': 'ensemble',
        'red_team_reasoner': 'llm_judge',
        'generative_quality_assessment_layer': 'llm_eval',
        'ml_powered_hallucination_detection': 'ml_eval',
        'contextual_query_amplifier': 'query_expansion',
        'hybrid_rag': 'hybrid_rag'
    }
    
    # Convert frontend names to database column names
    techniques = {}
    for frontend_name, enabled in request_data.items():
        db_column = method_mapping.get(frontend_name, frontend_name)
        techniques[db_column] = enabled
    
    try:
        update_methods(techniques)
        print(f"Methods updated: {techniques}")
        return {"success": True, "message": "Mitigation methods updated successfully!"}
    except Exception as e:
        return {"success": False, "error": str(e)}
