#!/bin/bash

BASE_URL="http://localhost:9090/stream"

# Array of queries to test
QUERIES=(
  "Hello agent"
  "What is the weather today?"
  "Explain quantum computing"
  "Generate a haiku about AI"
  "Summarize FastAPI features"
)

# Loop through queries and call the endpoint
for q in "${QUERIES[@]}"; do
  echo "Testing query: $q"
  curl -s -G "$BASE_URL" --data-urlencode "query=$q"
  echo -e "\n-----------------------------\n"
done
