import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { useNavigate, useLocation } from 'react-router-dom';
import { LayoutDashboard, MessageSquare, Settings, AlertTriangle } from 'lucide-react';
import { AppProvider, useAppContext } from './context/AppContext';
import Dashboard from './pages/Dashboard';
import Chat from './pages/Chat';
import Analysis from './pages/Analysis';
import MitigationDashboard from './components/MitigationDashboard';

const Sidebar = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const menuItems = [
    { key: '/', icon: LayoutDashboard, label: 'Dashboard' },
    { key: '/chat', icon: MessageSquare, label: 'Chat Interface' },
    { key: '/analysis', icon: AlertTriangle, label: 'Analysis' },
    { key: '/mitigation', icon: Settings, label: 'Mitigation Control' }
  ];

  return (
    <div className="h-full flex flex-col">
      <div className="p-4 text-lg font-bold border-b border-gray-700">
        AI Hallucination Platform
      </div>
      <nav className="mt-4 flex-1">
        {menuItems.map(({ key, icon: Icon, label }) => (
          <button
            key={key}
            onClick={() => navigate(key)}
            className={`w-full flex items-center px-4 py-3 text-left hover:bg-gray-700 transition-colors ${
              location.pathname === key ? 'bg-blue-600' : ''
            }`}
          >
            <Icon className="w-5 h-5 mr-3" />
            {label}
          </button>
        ))}
      </nav>
    </div>
  );
};

const AppContent = () => {
  const { stats } = useAppContext();
  
  return (
    <div className="flex h-screen bg-gray-100">
      <div className="w-64 bg-gray-900 text-white flex-shrink-0">
        <Sidebar />
      </div>
      <main className="flex-1 overflow-y-auto p-6">
        <Routes>
          <Route path="/" element={<Dashboard stats={stats} />} />
          <Route path="/chat" element={<Chat />} />
          <Route path="/analysis" element={<Analysis />} />
          <Route path="/mitigation" element={<MitigationDashboard />} />
        </Routes>
      </main>
    </div>
  );
};

function App() {
  return (
    <AppProvider>
      <Router>
        <AppContent />
      </Router>
    </AppProvider>
  );
}

export default App;