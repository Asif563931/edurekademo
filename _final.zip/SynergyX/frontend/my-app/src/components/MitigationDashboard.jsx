import React, { useState, useEffect } from 'react';
import { Settings, Zap, Shield, Activity } from 'lucide-react';

const MitigationDashboard = ({ onConfigChange }) => {
  const [applyStatus, setApplyStatus] = useState('');
  const [techniques] = useState({
    knowledge_based: {
      name: 'Knowledge-Based Methods',
      techniques: [
        {
          id: 'anti_hallucination_knowledge_gate',
          name: 'Anti-Hallucination Knowledge Gate',
          description: 'Knowledge-based filtering to prevent hallucinations',
          confidence_impact: 0.88,
          innovation_level: 'advanced'
        },
        {
          id: 'evidence_binding_layer',
          name: 'Evidence Binding Layer',
          description: 'Binds responses to verifiable evidence',
          confidence_impact: 0.85,
          innovation_level: 'cutting_edge'
        },
        {
          id: 'grounding_based_on_entities',
          name: 'Grounding Based on Entities',
          description: 'Entity-based response grounding',
          confidence_impact: 0.82,
          innovation_level: 'standard'
        }
      ]
    },
    consensus_validation: {
      name: 'Consensus & Validation Methods',
      techniques: [
        {
          id: 'consensus_validation_engine',
          name: 'Consensus Validation Engine',
          description: 'Multi-source consensus validation',
          confidence_impact: 0.90,
          innovation_level: 'cutting_edge'
        },
        {
          id: 'red_team_reasoner',
          name: 'Red Team Reasoner',
          description: 'Adversarial reasoning for validation',
          confidence_impact: 0.87,
          innovation_level: 'experimental'
        }
      ]
    },
    quality_assessment: {
      name: 'Quality Assessment Methods',
      techniques: [
        {
          id: 'generative_quality_assessment_layer',
          name: 'Generative Quality Assessment Layer',
          description: 'AI-powered quality assessment',
          confidence_impact: 0.83,
          innovation_level: 'advanced'
        },
        {
          id: 'ml_powered_hallucination_detection',
          name: 'ML Powered Hallucination Detection',
          description: 'Machine learning based detection',
          confidence_impact: 0.86,
          innovation_level: 'cutting_edge'
        }
      ]
    },
    retrieval_enhancement: {
      name: 'Retrieval Enhancement Methods',
      techniques: [
        {
          id: 'contextual_query_amplifier',
          name: 'Contextual Query Amplifier',
          description: 'Enhanced query context understanding',
          confidence_impact: 0.80,
          innovation_level: 'standard'
        },
        {
          id: 'hybrid_rag',
          name: 'Hybrid RAG',
          description: 'Advanced retrieval-augmented generation',
          confidence_impact: 0.89,
          innovation_level: 'cutting_edge'
        }
      ]
    }
  });
  
  const [config, setConfig] = useState({
    anti_hallucination_knowledge_gate: { enabled: false },
    consensus_validation_engine: { enabled: false },
    evidence_binding_layer: { enabled: false },
    red_team_reasoner: { enabled: false },
    grounding_based_on_entities: { enabled: false },
    generative_quality_assessment_layer: { enabled: false },
    ml_powered_hallucination_detection: { enabled: false },
    contextual_query_amplifier: { enabled: false },
    hybrid_rag: { enabled: false }
  });

  useEffect(() => {
    const loadCurrentMethods = async () => {
      try {
        const response = await fetch('/api/get-methods');
        const data = await response.json();
        if (data.success && data.methods) {
          const newConfig = {};
          Object.keys(config).forEach(key => {
            newConfig[key] = { enabled: data.methods[key] || false };
          });
          setConfig(newConfig);
        }
      } catch (error) {
        console.error('Failed to load methods:', error);
      }
    };
    loadCurrentMethods();
  }, []);
  
  const [presets] = useState({
    balanced: {
      name: 'Balanced',
      description: 'Good balance of accuracy and performance',
      techniques: ['rag_retrieval', 'multi_agent_consensus']
    },
    high_accuracy: {
      name: 'High Accuracy',
      description: 'Maximum accuracy, slower performance',
      techniques: ['rag_retrieval', 'knowledge_graph', 'multi_agent_consensus']
    }
  });
  
  const [selectedPreset, setSelectedPreset] = useState('balanced');

  const updateTechniqueConfig = (techniqueId, updates) => {
    setConfig(prev => ({
      ...prev,
      [techniqueId]: { ...prev[techniqueId], ...updates }
    }));
    
    onConfigChange?.(techniqueId, updates);
    
    if (window.refreshMitigationMethods) {
      window.refreshMitigationMethods();
    }
  };

  const applyMitigation = async () => {
    const techniques = {
      anti_hallucination_knowledge_gate: config.anti_hallucination_knowledge_gate?.enabled || false,
      evidence_binding_layer: config.evidence_binding_layer?.enabled || false,
      grounding_based_on_entities: config.grounding_based_on_entities?.enabled || false,
      consensus_validation_engine: config.consensus_validation_engine?.enabled || false,
      red_team_reasoner: config.red_team_reasoner?.enabled || false,
      generative_quality_assessment_layer: config.generative_quality_assessment_layer?.enabled || false,
      ml_powered_hallucination_detection: config.ml_powered_hallucination_detection?.enabled || false,
      contextual_query_amplifier: config.contextual_query_amplifier?.enabled || false,
      hybrid_rag: config.hybrid_rag?.enabled || false
    };
    
    try {
      const response = await fetch('/api/update-methods', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(techniques)
      });
      const data = await response.json();
      if (data.success) {
        setApplyStatus('✓ Methods updated successfully!');
        setTimeout(() => setApplyStatus(''), 3000);
      } else {
        setApplyStatus('✗ Failed to update methods');
        setTimeout(() => setApplyStatus(''), 3000);
      }
    } catch (error) {
      console.error('Failed to update methods:', error);
      setApplyStatus('✗ Error updating methods');
      setTimeout(() => setApplyStatus(''), 3000);
    }
  };

  const getCategoryIcon = (category) => {
    const icons = {
      retrieval_based: Shield,
      consensus_based: Zap,
      uncertainty_based: Activity,
      knowledge_grounding: Settings
    };
    return icons[category] || Settings;
  };

  const getInnovationColor = (level) => {
    const colors = {
      standard: 'bg-blue-100 text-blue-800',
      advanced: 'bg-green-100 text-green-800',
      cutting_edge: 'bg-orange-100 text-orange-800',
      experimental: 'bg-red-100 text-red-800'
    };
    return colors[level] || 'bg-gray-100 text-gray-800';
  };

  const TechniqueCard = ({ technique, techniqueConfig }) => (
    <div className="bg-white p-4 rounded-lg shadow border">
      <div className="flex items-center justify-between mb-3">
        <h4 className="font-medium">{technique.name}</h4>
        <label className="relative inline-flex items-center cursor-pointer">
          <input
            type="checkbox"
            checked={techniqueConfig?.enabled || false}
            onChange={(e) => updateTechniqueConfig(technique.id, { enabled: e.target.checked })}
            className="sr-only peer"
          />
          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
        </label>
      </div>
      
      <p className="text-sm text-gray-600 mb-4">{technique.description}</p>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <p className="text-xs text-gray-500">Impact</p>
          <p className="text-lg font-bold text-blue-600">
            {(technique.confidence_impact * 100).toFixed(0)}%
          </p>
        </div>
        <div>
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getInnovationColor(technique.innovation_level)}`}>
            {technique.innovation_level}
          </span>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Mitigation Control Center</h2>
        <div className="flex gap-2">
          <select
            value={selectedPreset}
            onChange={(e) => setSelectedPreset(e.target.value)}
            className="px-3 py-2 border rounded"
          >
            {Object.entries(presets).map(([key, preset]) => (
              <option key={key} value={key}>{preset.name}</option>
            ))}
          </select>
          <button onClick={applyMitigation} className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
            Apply Mitigation
          </button>
          {applyStatus && (
            <span className={`text-sm ${applyStatus.includes('✓') ? 'text-green-600' : 'text-red-600'}`}>
              {applyStatus}
            </span>
          )}
        </div>
      </div>

      <div className="space-y-6">
        {Object.entries(techniques).map(([categoryKey, category]) => {
          const IconComponent = getCategoryIcon(categoryKey);
          return (
            <div key={categoryKey} className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center space-x-2 mb-4">
                <IconComponent className="w-5 h-5 text-blue-600" />
                <h3 className="text-lg font-semibold">{category.name}</h3>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {category.techniques.map(technique => (
                  <TechniqueCard
                    key={technique.id}
                    technique={technique}
                    techniqueConfig={config[technique.id]}
                  />
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default MitigationDashboard;