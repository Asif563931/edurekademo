import React, { createContext, useContext, useState, useEffect } from 'react';

const AppContext = createContext();

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within AppProvider');
  }
  return context;
};

export const AppProvider = ({ children }) => {
  const [stats, setStats] = useState({
    totalRequests: 0,
    hallucinationsDetected: 0,
    mitigationSuccess: 94.2,
    avgConfidence: 0
  });

  const [messages, setMessages] = useState(() => {
    const saved = localStorage.getItem('chatMessages');
    return saved ? JSON.parse(saved) : [
      {
        id: 1,
        type: 'assistant',
        content: 'Hi! How can I assist you today?',
        timestamp: new Date().toLocaleTimeString(),
        confidence: null,
        methods: []
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem('chatMessages', JSON.stringify(messages));
  }, [messages]);

  const fetchStats = async () => {
    try {
      const convResponse = await fetch('/api/conversation-count');
      const convData = await convResponse.json();
      
      const halResponse = await fetch('/api/hallucination-count');
      const halData = await halResponse.json();
      
      const confResponse = await fetch('/api/avg-confidence');
      const confData = await confResponse.json();
      
      setStats(prev => ({ 
        ...prev, 
        totalRequests: convData.count,
        hallucinationsDetected: halData.count,
        avgConfidence: confData.avgConfidence
      }));
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  useEffect(() => {
    fetchStats();
    const interval = setInterval(fetchStats, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <AppContext.Provider value={{
      stats,
      setStats,
      messages,
      setMessages,
      fetchStats
    }}>
      {children}
    </AppContext.Provider>
  );
};