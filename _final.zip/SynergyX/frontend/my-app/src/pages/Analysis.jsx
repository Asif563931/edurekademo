import React, { useState, useEffect } from 'react';
import { AlertTriangle, ChevronDown, ChevronUp, Activity, FileText, TrendingDown, ChevronLeft, ChevronRight } from 'lucide-react';

const Analysis = () => {
  const [conversations, setConversations] = useState([]);
  const [expandedId, setExpandedId] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const conversationsPerPage = 5;

  useEffect(() => {
    const fetchAllConversations = async () => {
      try {
        const response = await fetch(`/api/all-conversations?page=${currentPage}&limit=${conversationsPerPage}`);
        const data = await response.json();
        setConversations(data.conversations || []);
        setTotalPages(Math.ceil(20 / conversationsPerPage));
      } catch (error) {
        console.error('Error fetching conversations:', error);
      }
    };
    fetchAllConversations();
  }, [currentPage]);

  const getSeverityColor = (severity) => {
    const colors = {
      low: 'bg-yellow-100 text-yellow-800 border-yellow-300',
      medium: 'bg-orange-100 text-orange-800 border-orange-300',
      high: 'bg-red-100 text-red-800 border-red-300'
    };
    return colors[severity] || colors.medium;
  };

  const MetricCard = ({ icon: Icon, label, value, color }) => (
    <div className={`p-3 rounded-lg border ${color}`}>
      <div className="flex items-center space-x-2 mb-1">
        <Icon className="w-4 h-4" />
        <span className="text-xs font-medium">{label}</span>
      </div>
      <p className="text-lg font-bold">{value}</p>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <AlertTriangle className="w-8 h-8 text-red-600" />
        <h1 className="text-3xl font-bold bg-gradient-to-r from-red-600 to-orange-600 bg-clip-text text-transparent">
          Analysis
        </h1>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">All Conversations (Last 20)</h3>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-2 rounded-lg border disabled:opacity-50 hover:bg-gray-50"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-sm text-gray-600">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-2 rounded-lg border disabled:opacity-50 hover:bg-gray-50"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
        
        {conversations.length > 0 ? (
          <div className="space-y-4">
            {conversations.map((conv) => (
              <div key={conv.id} className="border rounded-lg overflow-hidden">
                <div 
                  className="p-4 bg-gray-50 cursor-pointer hover:bg-gray-100 transition-colors"
                  onClick={() => setExpandedId(expandedId === conv.id ? null : conv.id)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                          conv.isHallucinated 
                            ? getSeverityColor(conv.severity || 'medium')
                            : 'bg-green-100 text-green-800 border-green-300'
                        }`}>
                          {conv.isHallucinated ? (conv.severity || 'MEDIUM').toUpperCase() : 'VERIFIED'}
                        </span>
                        <span className="text-xs text-gray-500">{conv.timestamp}</span>
                      </div>
                      <p className="text-sm font-medium text-gray-800 truncate">{conv.query}</p>
                    </div>
                    <button className="ml-4 p-2 hover:bg-gray-200 rounded-full transition-colors">
                      {expandedId === conv.id ? (
                        <ChevronUp className="w-5 h-5 text-gray-600" />
                      ) : (
                        <ChevronDown className="w-5 h-5 text-gray-600" />
                      )}
                    </button>
                  </div>
                </div>

                {expandedId === conv.id && (
                  <div className="p-4 bg-white border-t">
                    <div className="space-y-4">
                      <div>
                        <h4 className="text-sm font-semibold text-gray-700 mb-2">User Query</h4>
                        <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded">{conv.query}</p>
                      </div>

                      <div>
                        <h4 className="text-sm font-semibold text-gray-700 mb-2">AI Response</h4>
                        <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded">{conv.response}</p>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        <MetricCard
                          icon={Activity}
                          label="Confidence Score"
                          value={`${conv.confidence}%`}
                          color="bg-blue-50 border-blue-200 text-blue-800"
                        />
                        <MetricCard
                          icon={TrendingDown}
                          label="Hallucination Score"
                          value={`${conv.hallucinationScore}%`}
                          color="bg-red-50 border-red-200 text-red-800"
                        />
                        <MetricCard
                          icon={FileText}
                          label="Critique Score"
                          value={`${conv.critiqueScore}%`}
                          color="bg-purple-50 border-purple-200 text-purple-800"
                        />
                        <MetricCard
                          icon={AlertTriangle}
                          label="Severity"
                          value={conv.severity}
                          color={getSeverityColor(conv.severity)}
                        />
                      </div>

                      {conv.isHallucinated && (
                        <>
                          <div>
                            <h4 className="text-sm font-semibold text-gray-700 mb-2">Hallucination Reason</h4>
                            <p className="text-sm text-red-600 bg-red-50 p-3 rounded border border-red-200">
                              {conv.hallucinationReason}
                            </p>
                          </div>

                          <div>
                            <h4 className="text-sm font-semibold text-gray-700 mb-2">Critique Verdict</h4>
                            <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded">{conv.critiqueVerdict}</p>
                          </div>

                          <div>
                            <h4 className="text-sm font-semibold text-gray-700 mb-2">Completeness Check</h4>
                            <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded">{conv.completeness}</p>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <AlertTriangle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">No conversations found</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Analysis;