import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Eye, CheckCircle, Lightbulb, AlertTriangle, Loader, ChevronDown } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import ReactMarkdown from 'react-markdown';

const MethodsDropdown = ({ methods }) => {
  const [isOpen, setIsOpen] = useState(false);
  
  return (
    <div className="mt-3 pt-2 border-t border-gray-200">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-1 text-xs text-gray-500 hover:text-gray-700"
      >
        <span>Applied Methods ({methods.length})</span>
        <ChevronDown className={`w-3 h-3 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="mt-2 flex flex-wrap gap-1">
          {methods.map((method, idx) => (
            <span key={idx} className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded">
              {method}
            </span>
          ))}
        </div>
      )}
    </div>
  );
};

const Chat = () => {
  const { messages, setMessages } = useAppContext();
  
  const [inputValue, setInputValue] = useState('');
  const [loading, setLoading] = useState(false);
  const [selectedMethods, setSelectedMethods] = useState(['rag_retrieval', 'multi_agent_consensus']);
  const [selectedPreset, setSelectedPreset] = useState('balanced');
  const [availablePresets] = useState({
    balanced: { name: 'Balanced', description: 'Good balance of accuracy and performance' },
    high_accuracy: { name: 'High Accuracy', description: 'Maximum accuracy, slower performance' }
  });
  const messagesEndRef = useRef(null);
  const [currentAgentStep, setCurrentAgentStep] = useState(null);
  const [streamingStatus, setStreamingStatus] = useState('idle');
  const abortControllerRef = useRef(null);
  const timeoutsRef = useRef([]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    return () => {
      // Cleanup on unmount
      timeoutsRef.current.forEach(clearTimeout);
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, []);

  const handleSend = async () => {
    if (!inputValue.trim() || loading) return;

    // Clear any existing timeouts and abort controller
    timeoutsRef.current.forEach(clearTimeout);
    timeoutsRef.current = [];
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    const userMessage = {
      id: Date.now(),
      type: 'user',
      content: inputValue,
      timestamp: new Date().toLocaleTimeString(),
      confidence: null,
      methods: []
    };

    setMessages(prev => [...prev, userMessage]);
    const currentInput = inputValue;
    const messageId = userMessage.id;
    setInputValue('');
    setLoading(true);
    setStreamingStatus('streaming');

    // Create new abort controller for this request
    abortControllerRef.current = new AbortController();

    try {
      // Fetch agent steps
      const stepsResponse = await fetch('/api/agent-steps', {
        signal: abortControllerRef.current.signal
      });
      const mockSteps = await stepsResponse.json();

      // Simulate agent processing with cleanup
      for (let i = 0; i < mockSteps.length; i++) {
        const timeout = setTimeout(() => {
          if (!abortControllerRef.current?.signal.aborted) {
            setCurrentAgentStep(mockSteps[i]);
          }
        }, i * 1000);
        timeoutsRef.current.push(timeout);
      }

      // Send chat request
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: currentInput,
          methods: selectedMethods,
          preset: selectedPreset
        }),
        signal: abortControllerRef.current.signal
      });

      const aiResponse = await response.json();
      
      const finalTimeout = setTimeout(() => {
        if (!abortControllerRef.current?.signal.aborted) {
          setMessages(prev => [...prev, aiResponse]);
          setCurrentAgentStep(null);
          setStreamingStatus('idle');
          setLoading(false);
        }
      }, mockSteps.length * 1000);
      timeoutsRef.current.push(finalTimeout);
      
    } catch (error) {
      if (error.name === 'AbortError') {
        console.log('Request aborted');
        return;
      }
      
      console.error('Error:', error);
      const errorMessage = {
        id: Date.now() + 1,
        type: 'error',
        content: 'Error processing request. Please try again.',
        timestamp: new Date().toLocaleTimeString(),
        confidence: 0,
        methods: [],
        sources: []
      };
      
      setMessages(prev => [...prev, errorMessage]);
      setCurrentAgentStep(null);
      setStreamingStatus('idle');
      setLoading(false);
    }
  };

  return (
    <div className="h-screen flex flex-col">
      <div className="flex items-center space-x-2 mb-4">
        <Bot className="w-6 h-6 text-blue-600" />
        <h3 className="text-xl font-semibold">AI Chat Interface</h3>
      </div>
      

      
      <div className="flex-1 bg-white rounded-lg shadow flex flex-col">
        <div className="p-3 border-b">
          <h4 className="font-medium">Chat Messages</h4>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4 space-y-4 min-h-0">
          {messages.map((message) => (
            <div key={message.id}>
              <div className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`flex items-start space-x-2 max-w-2xl ${
                  message.type === 'user' ? 'flex-row-reverse space-x-reverse' : ''
                }`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    message.type === 'user' ? 'bg-blue-600' : 'bg-gray-600'
                  }`}>
                    <span className="text-white text-xs font-medium">
                      {message.type === 'user' ? 'U' : 'AI'}
                    </span>
                  </div>
                  <div className={`px-4 py-3 rounded-2xl shadow-sm ${
                    message.type === 'user' 
                      ? 'bg-blue-600 text-white rounded-br-md' 
                      : 'bg-white text-gray-800 rounded-bl-md border'
                  }`}>
                    {message.type === 'user' ? (
                      <p className="text-sm leading-relaxed">{message.content}</p>
                    ) : (
                      <div>
                        <div className="text-sm leading-relaxed prose prose-sm max-w-none">
                          <ReactMarkdown>{message.content}</ReactMarkdown>
                        </div>
                        {message.methods && message.methods.length > 0 && (
                          <MethodsDropdown methods={message.methods} />
                        )}
                      </div>
                    )}
                    <p className={`text-xs mt-2 ${
                      message.type === 'user' ? 'text-blue-100' : 'text-gray-500'
                    }`}>{message.timestamp}</p>
                  </div>
                </div>
              </div>
              
              {message.type === 'user' && streamingStatus === 'streaming' && message.id === messages[messages.length - 1]?.id && (
                <div className="flex justify-start mt-3">
                  <div className="flex items-start space-x-2">
                    <div className="w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center flex-shrink-0">
                      <span className="text-white text-xs font-medium">AI</span>
                    </div>
                    <div className="bg-white px-4 py-3 rounded-2xl rounded-bl-md border shadow-sm">
                      <div className="flex items-center space-x-2">
                        <div className="flex space-x-1">
                          <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce"></div>
                          <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                          <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                        </div>
                        <span className="text-xs text-gray-600">Processing...</span>
                      </div>
                      {currentAgentStep && (
                        <p className="text-xs text-gray-500 mt-1">{currentAgentStep.action}</p>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        <div className="p-3 border-t bg-white">
          <div className="flex space-x-2">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Type your message..."
              className="flex-1 p-2 border rounded-lg text-sm"
              onKeyPress={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleSend();
                }
              }}
            />
            <button
              onClick={handleSend}
              disabled={loading}
              className="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
            >
              {loading ? <Loader className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Chat;