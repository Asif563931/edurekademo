import React, { useState, useEffect } from 'react';
import { Bot, Eye, Lightbulb, Clock, CheckCircle, AlertTriangle } from 'lucide-react';

const Dashboard = ({ stats }) => {
  
  const [realtimeMetrics] = useState({
    conversationsLastHour: 24,
    avgResponseTime: 1200,
    systemLoad: 'normal'
  });

  const hallucinationDetectionRate = stats.totalRequests > 0 
    ? Math.round((stats.hallucinationsDetected / stats.totalRequests) * 100)
    : 0;

  const mitigationSuccessRate = stats.totalRequests > 0
    ? Math.round(((stats.totalRequests - stats.hallucinationsDetected) / stats.totalRequests) * 100)
    : 0;
  

  
  const [recentRequests, setRecentRequests] = useState([]);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [convRes, halRes, confRes, recentRes] = await Promise.all([
          fetch('/api/conversation-count'),
          fetch('/api/hallucination-count'),
          fetch('/api/avg-confidence'),
          fetch(`/api/recent-conversations?page=${currentPage}&limit=10`)
        ]);
        
        const [convData, halData, confData, recentData] = await Promise.all([
          convRes.json(),
          halRes.json(),
          confRes.json(),
          recentRes.json()
        ]);
        
        stats.totalRequests = convData.count;
        stats.hallucinationsDetected = halData.count;
        stats.avgConfidence = confData.avgConfidence;
        setRecentRequests(recentData.conversations || []);
        setTotalPages(Math.ceil(30 / 10)); // 30 total records, 10 per page
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
    
    fetchData();
    
    if (autoRefresh) {
      const interval = setInterval(fetchData, 5000);
      return () => clearInterval(interval);
    }
  }, [autoRefresh, stats, currentPage]);

  const StatCard = ({ title, value, icon: Icon, gradient, subtitle }) => (
    <div className={`${gradient} text-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-white/80 text-sm">{title}</p>
          <p className="text-3xl font-bold">{value}</p>
          {subtitle && <p className="text-white/70 text-xs mt-2">{subtitle}</p>}
        </div>
        <Icon className="w-8 h-8 text-white/80" />
      </div>
    </div>
  );

  const CircularProgress = ({ percent, size = 200 }) => {
    const radius = (size - 20) / 2;
    const circumference = 2 * Math.PI * radius;
    const strokeDasharray = circumference;
    const strokeDashoffset = circumference - (percent / 100) * circumference;

    return (
      <div className="relative inline-flex items-center justify-center">
        <svg width={size} height={size} className="transform -rotate-90">
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="currentColor"
            strokeWidth="8"
            fill="transparent"
            className="text-gray-200"
          />
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="currentColor"
            strokeWidth="8"
            fill="transparent"
            strokeDasharray={strokeDasharray}
            strokeDashoffset={strokeDashoffset}
            className={percent < 25 ? "text-red-500" : percent < 75 ? "text-yellow-500" : "text-green-500"}
            strokeLinecap="round"
          />
        </svg>
        <span className="absolute text-2xl font-bold">{percent}%</span>
      </div>
    );
  };

  const StatusBadge = ({ status }) => {
    const colors = {
      verified: 'bg-green-100 text-green-800',
      mitigated: 'bg-yellow-100 text-yellow-800',
      flagged: 'bg-red-100 text-red-800'
    };
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${colors[status]}`}>
        {status.toUpperCase()}
      </span>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Lightbulb className="w-8 h-8 text-blue-600" />
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            AI Hallucination Mitigation Dashboard
          </h1>
          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
            realtimeMetrics.systemLoad === 'high' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'
          }`}>
            {realtimeMetrics.systemLoad === 'high' ? 'HIGH LOAD' : 'NORMAL'}
          </span>
        </div>
        <label className="flex items-center space-x-2 cursor-pointer">
          <span className="text-sm">Auto-refresh</span>
          <input type="checkbox" checked={autoRefresh} onChange={(e) => setAutoRefresh(e.target.checked)} className="w-4 h-4" />
        </label>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Conversations"
          value={stats.totalRequests}
          icon={Bot}
          gradient="bg-gradient-to-br from-purple-600 to-blue-600"
          subtitle={`+${realtimeMetrics.conversationsLastHour} in last hour`}
        />
        <StatCard
          title="Hallucinations Detected"
          value={stats.hallucinationsDetected}
          icon={Eye}
          gradient="bg-gradient-to-br from-pink-500 to-red-500"
          subtitle={`${hallucinationDetectionRate}% detection rate`}
        />
        <StatCard
          title="Mitigation Success"
          value={`${mitigationSuccessRate}%`}
          icon={CheckCircle}
          gradient="bg-gradient-to-br from-blue-500 to-cyan-400"
        />
        <StatCard
          title="Avg Response Time"
          value={`${realtimeMetrics.avgResponseTime}ms`}
          icon={Clock}
          gradient="bg-gradient-to-br from-pink-400 to-yellow-400"
          subtitle={`System Load: ${realtimeMetrics.systemLoad}`}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-lg">
          <div className="flex items-center space-x-2 mb-4">
            <Eye className="w-5 h-5 text-blue-600" />
            <h3 className="text-lg font-semibold">Hallucination Risk Monitor</h3>
          </div>
          <div className="flex flex-col items-center space-y-4">
            <CircularProgress percent={hallucinationDetectionRate} />
            <span className={`px-4 py-2 rounded-full text-sm font-medium ${
              hallucinationDetectionRate < 10 ? 'bg-green-100 text-green-800' :
              hallucinationDetectionRate < 25 ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'
            }`}>
              {hallucinationDetectionRate < 10 ? 'LOW RISK' : 
               hallucinationDetectionRate < 25 ? 'MEDIUM RISK' : 'HIGH RISK'}
            </span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-lg">
          <div className="flex items-center space-x-2 mb-4">
            <Lightbulb className="w-5 h-5 text-blue-600" />
            <h3 className="text-lg font-semibold">Confidence Level</h3>
          </div>
          <div className="flex flex-col items-center space-y-4">
            <CircularProgress percent={stats.avgConfidence} />
            <span className={`px-4 py-2 rounded-full text-sm font-medium ${
              stats.avgConfidence > 80 ? 'bg-green-100 text-green-800' :
              stats.avgConfidence > 60 ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'
            }`}>
              {stats.avgConfidence > 80 ? 'HIGH CONFIDENCE' : 
               stats.avgConfidence > 60 ? 'MEDIUM CONFIDENCE' : 'LOW CONFIDENCE'}
            </span>
          </div>
        </div>
      </div>
      
      <div className="bg-white p-6 rounded-lg shadow-lg">
          <h3 className="text-lg font-semibold mb-4">Recent Conversations</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2">Timestamp</th>
                  <th className="text-left py-2">Query</th>
                  <th className="text-left py-2">AI Response</th>
                  <th className="text-left py-2">Confidence</th>
                </tr>
              </thead>
              <tbody>
                {recentRequests.length > 0 ? recentRequests.map((request, index) => (
                  <tr key={index} className="border-b">
                    <td className="py-2 text-xs">{request.timestamp}</td>
                    <td className="py-2 max-w-xs truncate text-sm">{request.query}</td>
                    <td className="py-2 max-w-xs truncate text-sm">{request.response}</td>
                    <td className="py-2">
                      <div className="flex items-center space-x-2">
                        <div className="w-16 bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${
                              request.confidence > 70 ? 'bg-green-500' : 
                              request.confidence > 40 ? 'bg-yellow-500' : 'bg-red-500'
                            }`}
                            style={{ width: `${request.confidence}%` }}
                          />
                        </div>
                        <span className="text-xs">{request.confidence}%</span>
                      </div>
                    </td>
                  </tr>
                )) : (
                  <tr>
                    <td colSpan="4" className="py-4 text-center text-gray-500 text-sm">
                      No conversations yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          <div className="flex justify-between items-center mt-4">
            <button 
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="px-3 py-1 bg-blue-600 text-white rounded disabled:opacity-50"
            >
              Previous
            </button>
            <span className="text-sm text-gray-600">
              Page {currentPage} of {totalPages}
            </span>
            <button 
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="px-3 py-1 bg-blue-600 text-white rounded disabled:opacity-50"
            >
              Next
            </button>
          </div>
        </div>
    </div>
  );
};

export default Dashboard;