from tools.registry import get_rag_tool
def _retrieve_from_rag(db_name: str, query: str, k: int = 5):
    tool = get_rag_tool(db_name)
    if not tool:
        raise ValueError(f"RAG tool not found for DB: {db_name}")

    results = tool.retrieve(query, k=k)
    return results
