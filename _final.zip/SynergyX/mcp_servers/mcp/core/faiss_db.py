import os
from typing import List, Optional
from langchain_community.document_loaders import (
    PyPDFLoader,
    TextLoader,
    Docx2txtLoader,
    DirectoryLoader
)
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
import httpx
from tools.schemas.custom_state import RAGChunk
import os
tiktoken_cache_dir = "tiktoken_cache"
os.environ["TIKTOKEN_CACHE_DIR"] = tiktoken_cache_dir
assert os.path.exists(os.path.join(tiktoken_cache_dir, "9b5ad71b2ce5302211f9c61530b329a4922fc6a4"))
http_client = httpx.Client(verify=False) 
from typing import Dict, Any, List


class DocumentFaissDB:
    """Document ingestion and retrieval system using LangChain and FAISS with L2 indexing."""
    
    def __init__(self, embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"):
        """
        Initialize the document database.
        
        Args:
            embedding_model: HuggingFace model name for embeddings
        """
        self.embeddings = OpenAIEmbeddings(
            base_url="https://genailab.tcs.in",
            model="azure/genailab-maas-text-embedding-3-large",
            api_key="sk-D83phfp7sQOC4FIk98EheQ",
            http_client=http_client
        )
        self.vectorstore = None
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200,
            length_function=len
        )
    
    def load_document(self, file_path: str) -> List[Document]:
        """
        Load a single document based on file extension.
        
        Args:
            file_path: Path to the document file
            
        Returns:
            List of Document objects
        """
        file_extension = os.path.splitext(file_path)[1].lower()
        
        try:
            if file_extension == '.pdf':
                loader = PyPDFLoader(file_path)
            elif file_extension == '.txt':
                loader = TextLoader(file_path, encoding='utf-8')
            elif file_extension in ['.docx', '.doc']:
                loader = Docx2txtLoader(file_path)
            else:
                raise ValueError(f"Unsupported file type: {file_extension}")
            
            documents = loader.load()
            print(f"Loaded {len(documents)} pages/sections from {file_path}")
            return documents
        
        except Exception as e:
            print(f"Error loading {file_path}: {str(e)}")
            return []
    
    def load_directory(self, directory_path: str, glob_pattern: str = "**/*.*") -> List[Document]:
        """
        Load all documents from a directory.
        
        Args:
            directory_path: Path to the directory
            glob_pattern: Pattern to match files (e.g., "**/*.pdf" for PDFs only)
            
        Returns:
            List of Document objects
        """
        all_documents = []
        
        # Load PDFs
        try:
            pdf_loader = DirectoryLoader(
                directory_path,
                glob="**/*.pdf",
                loader_cls=PyPDFLoader
            )
            all_documents.extend(pdf_loader.load())
        except Exception as e:
            print(f"Error loading PDFs: {str(e)}")
        
        # Load text files
        try:
            txt_loader = DirectoryLoader(
                directory_path,
                glob="**/*.txt",
                loader_cls=TextLoader,
                loader_kwargs={'encoding': 'utf-8'}
            )
            all_documents.extend(txt_loader.load())
        except Exception as e:
            print(f"Error loading text files: {str(e)}")
        
        # Load Word documents
        try:
            docx_loader = DirectoryLoader(
                directory_path,
                glob="**/*.docx",
                loader_cls=Docx2txtLoader
            )
            all_documents.extend(docx_loader.load())
        except Exception as e:
            print(f"Error loading Word documents: {str(e)}")
        
        print(f"Loaded total {len(all_documents)} documents from directory")
        return all_documents
    
    def ingest(self, file_paths: Optional[List[str]] = None, 
               directory_path: Optional[str] = None):
        """
        Ingest documents into the FAISS vector store.
        
        Args:
            file_paths: List of file paths to ingest
            directory_path: Directory path to ingest all documents from
        """
        all_documents = []
        
        # Load individual files
        if file_paths:
            for file_path in file_paths:
                docs = self.load_document(file_path)
                all_documents.extend(docs)
        
        # Load from directory
        if directory_path:
            docs = self.load_directory(directory_path)
            all_documents.extend(docs)
        
        if not all_documents:
            print("No documents to ingest")
            return
        
        # Split documents into chunks
        split_docs = self.text_splitter.split_documents(all_documents)
        print(f"Split into {len(split_docs)} chunks")
        
        # Create or update vector store
        if self.vectorstore is None:
            self.vectorstore = FAISS.from_documents(
                split_docs,
                self.embeddings,
                distance_strategy="EUCLIDEAN_DISTANCE"  # L2 distance
            )
            print(f"Created new FAISS index with {len(split_docs)} chunks")
        else:
            self.vectorstore.add_documents(split_docs)
            print(f"Added {len(split_docs)} chunks to existing index")
    
    def retrieve(self, query: str, k: int = 5):
        """
        MCP-compatible retrieval tool.
        Returns a single formatted STRING as content,
        plus metadata as the second tuple element.
        """

        if self.vectorstore is None:
            return (
                "No documents available in the knowledge base.",
                {
                    "source": "faiss",
                    "status": "empty_index"
                }
            )

        results = self.vectorstore.similarity_search_with_score(query, k=k)

        lines = []
        for idx, (doc, score) in enumerate(results, start=1):
            chunk_text = doc.page_content.replace("\n", " ").strip()
            metadata = doc.metadata

            lines.append(
                f"--- Chunk {idx} ---\n"
                f"Score: {float(score)}\n"
                f"Source: {metadata.get('source', 'unknown')}\n"
                f"Metadata: {metadata}\n"
                f"Content:\n{chunk_text}\n"
            )

        final_content = "\n".join(lines)

        return final_content


    
    def save(self, index_path: str = "faiss_index"):
        """Save the FAISS index to disk."""
        if self.vectorstore is None:
            print("No index to save")
            return
        
        self.vectorstore.save_local(index_path)
        print(f"Index saved to {index_path}")
    
    def load(self, index_path: str = "faiss_index"):
        """Load a FAISS index from disk."""
        try:
            self.vectorstore = FAISS.load_local(
                index_path,
                self.embeddings,
                allow_dangerous_deserialization=True
            )
            print(f"Index loaded from {index_path}")
        except Exception as e:
            print(f"Error loading index: {str(e)}")


# Example usage
if __name__ == "__main__":
    # Initialize the database
    db = DocumentFaissDB()
    
    # Example 1: Ingest individual files
    print("=" * 80)
    print("Example 1: Ingesting individual files")
    print("=" * 80)
    # db.ingest(file_paths=[
    #     "document1.pdf",
    #     "document2.txt",
    #     "document3.docx"
    # ])
    
    # Example 2: Ingest all documents from a directory
    print("\n" + "=" * 80)
    print("Example 2: Ingesting from directory")
    print("=" * 80)
    # db.ingest(directory_path="./documents")
    
    # Example 3: Combined approach
    print("\n" + "=" * 80)
    print("Example 3: Combined ingestion")
    print("=" * 80)
    # db.ingest(
    #     file_paths=["important_doc.pdf"],
    #     directory_path="./more_documents"
    # )
    
    # Example 4: Retrieve relevant documents
    print("\n" + "=" * 80)
    print("Example 4: Retrieval")
    print("=" * 80)
    # results = db.retrieve("What is machine learning?", k=3)
    
    # Example 5: Save and load index
    print("\n" + "=" * 80)
    print("Example 5: Save and Load")
    print("=" * 80)
    # db.save("my_faiss_index")
    # 
    # # Later, load the index
    # new_db = DocumentFaissDB()
    # new_db.load("my_faiss_index")
    # new_db.retrieve("your query here", k=5)
    
    print("\n" + "=" * 80)
    print("Setup complete! Uncomment examples to test.")
    print("=" * 80)