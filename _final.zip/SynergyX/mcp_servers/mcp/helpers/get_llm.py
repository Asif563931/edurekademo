from langchain_openai import ChatOpenAI, OpenAIEmbeddings 
import tempfile 
import os 
import httpx 
import tiktoken 
from core.settings import API_KEY, BASE_URL, SMALL_LLM_MODEL, REASONING_LLM_MODEL, LARGE_LLM_MODEL
from core.logger import get_logger, log_critical_operation, log_security_event

tiktoken_cache_dir = "./token"
os.environ["TIKTOKEN_CACHE_DIR"] = tiktoken_cache_dir

logger = get_logger("llm_helper")
def get_small_llm():
    """Initialize small LLM client"""
    logger.info(f"Initializing small LLM: {SMALL_LLM_MODEL}")
    log_security_event(logger, "LLM_CLIENT_INIT", {"model": SMALL_LLM_MODEL, "base_url": BASE_URL})
    
    try:
        client = httpx.Client(verify=False) 
        llm = ChatOpenAI( 
            base_url=BASE_URL, 
            model=SMALL_LLM_MODEL, 
            api_key=API_KEY, 
            http_client=client 
        )
        logger.info("Small LLM client initialized successfully")
        return llm
    except Exception as e:
        logger.error(f"Failed to initialize small LLM: {e}")
        raise

def get_reasoning_llm():
    """Initialize reasoning LLM client"""
    logger.info(f"Initializing reasoning LLM: {REASONING_LLM_MODEL}")
    log_security_event(logger, "LLM_CLIENT_INIT", {"model": REASONING_LLM_MODEL, "base_url": BASE_URL})
    
    try:
        client = httpx.Client(verify=False) 
        llm = ChatOpenAI( 
            base_url=BASE_URL, 
            model=REASONING_LLM_MODEL, 
            api_key=API_KEY, 
            http_client=client 
        )
        logger.info("Reasoning LLM client initialized successfully")
        return llm
    except Exception as e:
        logger.error(f"Failed to initialize reasoning LLM: {e}")
        raise

def get_large_llm():
    """Initialize large LLM client"""
    logger.info(f"Initializing large LLM: {LARGE_LLM_MODEL}")
    log_security_event(logger, "LLM_CLIENT_INIT", {"model": LARGE_LLM_MODEL, "base_url": BASE_URL})
    
    try:
        client = httpx.Client(verify=False) 
        llm = ChatOpenAI( 
            base_url=BASE_URL, 
            model=LARGE_LLM_MODEL, 
            api_key=API_KEY, 
            http_client=client 
        )
        logger.info("Large LLM client initialized successfully")
        log_critical_operation(logger, "LARGE_LLM_READY", {"model": LARGE_LLM_MODEL})
        return llm
    except Exception as e:
        logger.error(f"Failed to initialize large LLM: {e}")
        raise