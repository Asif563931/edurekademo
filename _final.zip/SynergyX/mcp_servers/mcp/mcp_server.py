import glob
import logging
import logging.config
import os
import sys
import time
from datetime import datetime
from pathlib import Path
from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP
from tools.mcp_tools import process_text_with_safety
from common import _retrieve_from_rag

# ============================================================
# Centralized Logging Setup
# ============================================================
def setup_mcp_logging():
    """Setup logging for MCP server"""
    logs_dir = Path("./logs")
    logs_dir.mkdir(exist_ok=True)
    
    # Try to use centralized config
    config_path = Path("./log.conf")
    if config_path.exists():
        try:
            logging.config.fileConfig(config_path, disable_existing_loggers=False)
        except Exception as e:
            _setup_fallback_logging()
            logging.error(f"Failed to load logging config: {e}")
    else:
        _setup_fallback_logging()

def _setup_fallback_logging():
    """Fallback logging configuration"""
    formatter = logging.Formatter(
        fmt="[%(asctime)s] [%(name)s] [%(levelname)s] [%(filename)s:%(lineno)d] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setFormatter(formatter)
    console_handler.setLevel(logging.INFO)
    
    # File handler
    file_handler = logging.FileHandler("./logs/mcp_server.log")
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.DEBUG)
    
    # Root logger
    root_logger = logging.getLogger()
    root_logger.handlers.clear()
    root_logger.addHandler(console_handler)
    root_logger.addHandler(file_handler)
    root_logger.setLevel(logging.INFO)

# Initialize logging
setup_mcp_logging()
logger = logging.getLogger("mcp_server")

# ============================================================
# Environment & Startup
# ============================================================
load_dotenv()
logger.info("Starting FusionAI-Server (FastMCP) - MCP")
logger.info(f"Python {sys.version.split()[0]} | Process ID: {os.getpid()}")
logger.critical(f"CRITICAL_OP: MCP_SERVER_STARTUP | Details: {{\"pid\": {os.getpid()}, \"python_version\": \"{sys.version.split()[0]}\"}}")

# ============================================================
# FastMCP Server
# ============================================================
app = FastMCP("FusionAI-MCP",host="0.0.0.0",port=8001)

# ============================================================
# Tools
# ============================================================
@app.tool()
async def process_text_with_safety_tool(text:str):
    """Check for safety, PII and Guardrails"""
    start_time = time.time()
    logger.info("Tool process_text_with_safety_tool called")
    logger.debug(f"Processing text length: {len(text)} characters")
    
    try:
        result = process_text_with_safety(text)
        processing_time = (time.time() - start_time) * 1000
        logger.info(f"PERFORMANCE: safety_check_time={processing_time:.2f}ms")
        logger.info(f"Safety check completed: {result}")
        
        # Log security event if issues found
        if "unsafe" in str(result).lower() or "pii" in str(result).lower():
            logger.warning(f"SECURITY: safety_issue_detected | Details: {{\"result\": \"{result}\", \"text_length\": {len(text)}}}")
        
        return result
    except Exception as e:
        logger.error(f"Safety tool execution failed: {e}")
        raise

# ============================================================
# Additional Dummy Tools from YAML
# ============================================================

# ------------------ LLM Intent Classifier Tools ------------------
@app.tool()
async def semantic_search(query: str):
    logger.info(f"[semantic_search] Called with query: {query}")
    return {"result": "semantic_search_result_placeholder"}

@app.tool()
async def text_classification(query: str):
    logger.info(f"[text_classification] Called with query: {query}")
    return {"result": "text_classification_result_placeholder"}

@app.tool()
async def similarity_matcher(query: str):
    logger.info(f"[similarity_matcher] Called with query: {query}")
    return {"result": "similarity_matcher_result_placeholder"}

@app.tool()
async def retrieve_internal_faq(query: str, k: int = 5):
    """
    Retrieve low-risk internal FAQ information such as
    customer care, store timings, SIM activation, app usage.
    """
    logger.info(f"[retrieve_internal_faq] query={query}")
    return _retrieve_from_rag("internal_faq_db", query, k)

@app.tool()
async def retrieve_plan_product(query: str, k: int = 5):
    """
    Retrieve telecom plan and product information such as
    plan features, data limits, roaming, pricing.
    """
    logger.info(f"[retrieve_plan_product] query={query}")
    return _retrieve_from_rag("plan_product_db", query, k)

@app.tool()
async def retrieve_policy_compliance(query: str, k: int = 5):
    """
    Retrieve regulatory, compliance, and policy-related documents.
    High-risk authoritative source.
    """
    logger.info(f"[retrieve_policy_compliance] query={query}")
    return _retrieve_from_rag("policy_compliance_db", query, k)

@app.tool()
async def retrieve_support_troubleshooting(query: str, k: int = 5):
    """
    Retrieve troubleshooting and operational support documents
    related to network, SIM, connectivity issues.
    """
    logger.info(f"[retrieve_support_troubleshooting] query={query}")
    return _retrieve_from_rag("support_troubleshooting_db", query, k)

# ============================================================
# Main Entry Point
# ============================================================
if __name__ == "__main__":
    try:
        cwd = os.getcwd()
        logger.info("Starting MCP server with SSE transport %s", cwd)
        logger.info("Starting MCP server with SSE transport")
        logger.critical("CRITICAL_OP: MCP_SERVER_START | Details: {\"transport\": \"sse\", \"host\": \"0.0.0.0\", \"port\": 8001}")
        app.run(transport="sse")
    except Exception as e:
        logger.error(f"MCP server startup failed: {e}")
        raise