from abc import ABC
from typing import List
from core.faiss_db import DocumentFaissDB

class BaseRAGTool(ABC):
    """
    Base class for all RAG DB tools.
    Each tool wraps a shared FAISS utility with its own index path.
    """

    def __init__(self, index_path: str):
        self.index_path = index_path
        self.db = DocumentFaissDB()
        self._load_index()

    def _load_index(self):
        try:
            self.db.load(self.index_path)
        except Exception:
            # Index not found → empty DB
            pass

    def ingest_directory(self, directory_path: str):
        self.db.ingest(directory_path=directory_path)
        self.db.save(self.index_path)

    def retrieve(self, query: str, k: int = 5):
        return self.db.retrieve(query, k=k)
