from .base_rag_tool import BaseRAGTool

class InternalFAQRAGTool(BaseRAGTool):
    def __init__(self):
        super().__init__(index_path="rag/internal_faq_db")
