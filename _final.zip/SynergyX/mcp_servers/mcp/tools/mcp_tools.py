#!/usr/bin/env python
import sys
import yaml
import os
import re
import logging
import time
from pathlib import Path

# Setup logging for MCP tools
logger = logging.getLogger("mcp_tools")

# ===========================================================
# 1. SAFETY GUARDRAILS (same as your script)
# ===========================================================
def run_input_guardrails(SAFETY_CFG: dict, text: str):
    """Run input safety guardrails"""
    logger.debug(f"Running input guardrails on text length: {len(text)}")
    
    cm = SAFETY_CFG.get("content_moderation", {})
    if cm.get("enabled", True):
        banned_keywords = cm.get("banned_keywords", [])
        logger.debug(f"Checking {len(banned_keywords)} banned keywords")
        
        for keyword in banned_keywords:
            if keyword.lower() in text.lower():
                logger.warning(f"SECURITY: content_blocked | Details: {{\"keyword\": \"{keyword}\", \"reason\": \"banned_keyword\"}}")
                return False, f"Blocked by content moderation: '{keyword}'"

        max_length = cm.get("max_input_length", 2000)
        if len(text) > max_length:
            logger.warning(f"SECURITY: content_blocked | Details: {{\"length\": {len(text)}, \"max_length\": {max_length}, \"reason\": \"too_long\"}}")
            return False, "Blocked: Input too long."

        if cm.get("require_nonempty", True) and not text.strip():
            logger.warning("SECURITY: content_blocked | Details: {\"reason\": \"empty_input\"}")
            return False, "Blocked: Empty input is not allowed."

    inj = SAFETY_CFG.get("prompt_injection", {})
    if inj.get("enabled", True):
        forbidden_phrases = inj.get("forbidden_phrases", [])
        logger.debug(f"Checking {len(forbidden_phrases)} forbidden phrases")
        
        for phrase in forbidden_phrases:
            if phrase.lower() in text.lower():
                logger.warning(f"SECURITY: prompt_injection_blocked | Details: {{\"phrase\": \"{phrase}\"}}")
                return False, "Blocked: Prompt injection attempt."

    jb = SAFETY_CFG.get("jailbreak_prevention", {})
    if jb.get("enabled", True):
        disallowed_requests = jb.get("disallowed_requests", [])
        logger.debug(f"Checking {len(disallowed_requests)} jailbreak patterns")
        
        for phrase in disallowed_requests:
            if phrase.lower() in text.lower():
                logger.warning(f"SECURITY: jailbreak_blocked | Details: {{\"phrase\": \"{phrase}\"}}")
                return False, "Blocked: Jailbreak attempt."

    logger.debug("Input guardrails passed")
    return True, None

def apply_output_filter(SAFETY_CFG: dict, text: str) -> str:
    """Apply output safety filters"""
    cfg = SAFETY_CFG.get("output_filtering", {})
    if not cfg.get("enabled", True):
        logger.debug("Output filtering disabled")
        return text

    blocked_content = cfg.get("block_if_contains", [])
    logger.debug(f"Checking output against {len(blocked_content)} blocked patterns")
    
    for banned in blocked_content:
        if banned.lower() in text.lower():
            replacement = cfg.get("replacement_text", "[REDACTED_SAFETY]")
            logger.warning(f"SECURITY: output_filtered | Details: {{\"pattern\": \"{banned}\", \"replacement\": \"{replacement}\"}}")
            return replacement

    logger.debug("Output filter passed")
    return text

# ===========================================================
# 2. PII ENGINE
# ===========================================================
class PiiMatch:
    def __init__(self, kind, value):
        self.kind = kind
        self.value = value

class PiiRedactor:
    def __init__(self, cfg):
        self.cfg = cfg

    def detect(self, text):
        """Detect PII in text"""
        matches = []
        enabled_detectors = [d for d in self.cfg.get("detectors", []) if d.get("enabled", True)]
        logger.debug(f"Running PII detection with {len(enabled_detectors)} detectors")
        
        for det in enabled_detectors:
            pattern = det.get("pattern")
            kind = det.get("name")
            group_index = det.get("group", 0)

            for m in re.finditer(pattern, text, re.IGNORECASE):
                pii_value = m.group(group_index)
                matches.append(PiiMatch(kind, pii_value))
                logger.warning(f"SECURITY: pii_detected | Details: {{\"type\": \"{kind}\", \"position\": {m.start()}}}")
        
        logger.info(f"PII detection completed: {len(matches)} matches found")
        return matches

    def redact(self, text):
        """Redact PII from text"""
        redacted = text
        redaction_count = 0
        
        for det in self.cfg.get("detectors", []):
            if not det.get("enabled", True):
                continue
            pattern = det.get("pattern")
            kind = det.get("name")
            
            # Count matches before redaction
            matches = list(re.finditer(pattern, redacted, re.IGNORECASE))
            if matches:
                redaction_count += len(matches)
                logger.info(f"Redacting {len(matches)} instances of {kind}")
            
            redacted = re.sub(pattern, f"[REDACTED_{kind}]", redacted, flags=re.IGNORECASE)
        
        if redaction_count > 0:
            logger.info(f"PII redaction completed: {redaction_count} total redactions")
        
        return redacted

# ===========================================================
# 3. PROCESS PIPELINE
# ===========================================================
def process_text_with_safety(text: str):
    """Process text through safety and PII pipeline"""
    start_time = time.time()
    logger.info(f"Starting safety processing for text length: {len(text)}")
    
    try:
        # ===========================================================
        # LOAD CONFIG FILES
        # ===========================================================
        logger.debug("Loading configuration files")
        logger.info(os.getcwd())
        pii_config_path = "./tools/tools_config/pii.yaml"
        safety_config_path = "./tools/tools_config/safety.yaml"

        if os.path.exists(pii_config_path) and os.path.isfile(pii_config_path):
            logger.error(f"PII config file found: {pii_config_path}")
        else:
            logger.error(f"PII config file not found: {pii_config_path}")
            return False
        if os.path.exists(safety_config_path) and os.path.isfile(safety_config_path):
            logger.error(f"PII config file found: {safety_config_path}")
        else:
            logger.error(f"PII config file not found: {safety_config_path}")
            return False
        
        with open(pii_config_path, "r", encoding="utf-8") as f:
            PII_CFG = yaml.safe_load(f)["pii"]

        with open(safety_config_path, "r", encoding="utf-8") as f:
            SAFETY_CFG = yaml.safe_load(f)["ai_safety"]
        
        logger.debug("Configuration files loaded successfully")

        # ===========================================================
        # SAFETY PIPELINE
        # ===========================================================
        
        # Step 1: Input guardrails
        guardrail_start = time.time()
        ok, msg = run_input_guardrails(SAFETY_CFG, text)
        guardrail_time = (time.time() - guardrail_start) * 1000
        logger.info(f"PERFORMANCE: guardrail_check_time={guardrail_time:.2f}ms")
        
        if not ok:
            logger.warning(f"Input blocked by guardrails: {msg}")
            return False

        # Step 2: PII detection and redaction
        pii_start = time.time()
        RED = PiiRedactor(PII_CFG)
        pii_matches = RED.detect(text)
        redacted = RED.redact(text)
        pii_time = (time.time() - pii_start) * 1000
        logger.info(f"PERFORMANCE: pii_processing_time={pii_time:.2f}ms")
        
        # Step 3: Output filtering
        filter_start = time.time()
        final_text = apply_output_filter(SAFETY_CFG, redacted)
        filter_time = (time.time() - filter_start) * 1000
        logger.info(f"PERFORMANCE: output_filter_time={filter_time:.2f}ms")
        
        # Final decision
        total_time = (time.time() - start_time) * 1000
        logger.info(f"PERFORMANCE: total_safety_processing_time={total_time:.2f}ms")
        
        if pii_matches:
            logger.warning(f"Text blocked due to {len(pii_matches)} PII matches")
            logger.critical(f"CRITICAL_OP: PII_BLOCKED | Details: {{\"pii_count\": {len(pii_matches)}, \"text_length\": {len(text)}}}")
            return "rejected"
        else:
            logger.info("Safety processing completed successfully")
            return final_text
            
    except Exception as e:
        logger.error(f"Safety processing failed: {e}")
        logger.critical(f"CRITICAL_OP: SAFETY_PROCESSING_ERROR | Details: {{\"error\": \"{str(e)}\", \"text_length\": {len(text)}}}")
        raise



# ===========================================================
# DUMMY TOOLS IMPLEMENTATION FOR YAML AGENTS
# ===========================================================

# ------------------ LLM Intent Classifier Tools ------------------
def semantic_search(query: str, **kwargs):
    logger.info(f"[semantic_search] Called with query: {query}")
    time.sleep(0.01)
    return {"result": "semantic_search_result_placeholder"}

def text_classification(query: str, **kwargs):
    logger.info(f"[text_classification] Called with query: {query}")
    time.sleep(0.01)
    return {"result": "text_classification_result_placeholder"}

def similarity_matcher(query: str, **kwargs):
    logger.info(f"[similarity_matcher] Called with query: {query}")
    time.sleep(0.01)
    return {"result": "similarity_matcher_result_placeholder"}



