from .faq_rag_tool import InternalFAQRAGTool
from .plan_rag_tool import PlanProductRAGTool
from .policy_rag_tool import PolicyComplianceRAGTool
from .support_rag_tool import SupportTroubleshootingRAGTool

RAG_TOOL_REGISTRY = {
    "internal_faq_db": InternalFAQRAGTool(),
    "plan_product_db": PlanProductRAGTool(),
    "policy_compliance_db": PolicyComplianceRAGTool(),
    "support_troubleshooting_db": SupportTroubleshootingRAGTool()
}

def get_rag_tool(db_name: str):
    return RAG_TOOL_REGISTRY.get(db_name)
