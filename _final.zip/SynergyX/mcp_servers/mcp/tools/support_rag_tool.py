from .base_rag_tool import BaseRAGTool

class SupportTroubleshootingRAGTool(BaseRAGTool):
    def __init__(self):
        super().__init__(index_path="rag/support_troubleshooting_db")
