from trust_layer.utils.text import extract_claims

class ClaimGroundingValidator:

    def validate(self, answer: str, rag_chunks: list[dict]):
        claims = extract_claims(answer)
        results = []

        for claim in claims:
            supported = False
            source = None

            for chunk in rag_chunks:
                if claim.lower() in chunk["content"].lower():
                    supported = True
                    source = chunk["source"]
                    break

            results.append({
                "claim": claim,
                "supported": supported,
                "source": source,
                "confidence": 0.9 if supported else 0.2
            })

        overall_confidence = round(
            sum(r["confidence"] for r in results) / len(results),
            2
        ) if results else 0

        return {
            "claim_results": results,
            "overall_confidence": overall_confidence
        }
