from trust_layer.utils.text import extract_claims

class MultiSampleAgreement:
    def __init__(self, llm: any, samples: int = 3):
        self.llm = llm
        self.samples = samples

    def run(self, prompt: str):
        responses = []
        claims_sets = []

        for _ in range(self.samples):
            resp = self.llm.invoke(prompt).content
            responses.append(resp)
            claims_sets.append(set(extract_claims(resp)))

        common_claims = set.intersection(*claims_sets)
        all_claims = set.union(*claims_sets)

        agreement_score = (
            len(common_claims) / len(all_claims)
            if all_claims else 0
        )

        return {
            "responses": responses,
            "agreement_score": round(agreement_score, 2),
            "common_claims": list(common_claims),
            "divergent_claims": list(all_claims - common_claims)
        }
