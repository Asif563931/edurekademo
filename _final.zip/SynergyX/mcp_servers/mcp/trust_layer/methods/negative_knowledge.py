class NegativeKnowledgeInjector:
    """
    Plug-and-play prompt guard.
    """

    def apply(
        self,
        user_query: str,
        missing_information: list[str]
    ) -> str:
        guard = (
            "IMPORTANT CONSTRAINTS:\n"
            "The following information is NOT available.\n"
            "DO NOT guess, infer, or fabricate.\n\n"
        )

        for item in missing_information:
            guard += f"- {item}\n"

        final_prompt = f"""
        {guard}

        User Query:
        {user_query}

        If information is missing, explicitly say:
        'This information is not available in the provided data.'
        """

        return final_prompt
