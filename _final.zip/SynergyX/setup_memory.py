#!/usr/bin/env python
"""
SynergyX Memory System Setup Script
"""
import os
import sys
import subprocess
from pathlib import Path

def setup_memory_system():
    """Setup the memory management system"""
    print("🚀 Setting up SynergyX Memory System...")
    
    # 1. Install dependencies
    print("📦 Installing dependencies...")
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "-r", "a2a_servers/requirements.txt"], 
                      check=True, cwd=Path(__file__).parent)
        print("✅ Dependencies installed")
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install dependencies: {e}")
        return False
    
    # 2. Create .env file if it doesn't exist
    env_file = Path(__file__).parent / ".env"
    env_example = Path(__file__).parent / ".env.example"
    
    if not env_file.exists() and env_example.exists():
        print("📝 Creating .env file...")
        env_file.write_text(env_example.read_text())
        print("✅ .env file created from template")
    
    # 3. Start database (optional)
    print("🐘 Database setup:")
    print("   Option 1: Run 'docker-compose up postgres -d' to start PostgreSQL")
    print("   Option 2: Use your existing PostgreSQL instance")
    print("   Option 3: Set MEMORY_ENABLED=false in .env to disable memory")
    
    # 4. Initialize database
    print("🗄️  To initialize database tables, run:")
    print("   python a2a_servers/app/memory/init_db.py")
    
    print("\n✨ Memory system setup complete!")
    print("\n📋 Next steps:")
    print("1. Configure DATABASE_URL in .env file")
    print("2. Start PostgreSQL database")
    print("3. Run database initialization script")
    print("4. Start your application normally")
    
    return True

if __name__ == "__main__":
    success = setup_memory_system()
    sys.exit(0 if success else 1)