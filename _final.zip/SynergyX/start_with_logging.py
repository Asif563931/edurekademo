#!/usr/bin/env python
"""
SynergyX Startup Script with Centralized Logging
"""
import os
import sys
import argparse
import subprocess
from pathlib import Path

# Add the project root to Python path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from a2a_servers.app.core.logger import setup_logging, get_logger, log_critical_operation

def main():
    """Main startup function with logging"""
    # Setup logging first
    setup_logging()
    logger = get_logger("synergyx_startup")
    
    logger.info("=" * 60)
    logger.info("SynergyX System Starting Up")
    logger.info("=" * 60)
    
    log_critical_operation(logger, "SYSTEM_STARTUP", {
        "python_version": sys.version.split()[0],
        "working_directory": str(Path.cwd()),
        "project_root": str(project_root)
    })
    
    parser = argparse.ArgumentParser(description="Start SynergyX services")
    parser.add_argument("--service", choices=["a2a", "mcp", "all"], default="all",
                       help="Service to start (default: all)")
    parser.add_argument("--config", default="a2a_servers/app/agents_config/agents.yaml",
                       help="Configuration file path")
    
    args = parser.parse_args()
    
    try:
        if args.service in ["mcp", "all"]:
            logger.info("Starting MCP Server...")
            start_mcp_server(logger)
        
        if args.service in ["a2a", "all"]:
            logger.info("Starting A2A Server...")
            start_a2a_server(logger, args.config)
            
    except KeyboardInterrupt:
        logger.info("Shutdown requested by user")
        log_critical_operation(logger, "SYSTEM_SHUTDOWN", {"reason": "user_interrupt"})
    except Exception as e:
        logger.error(f"System startup failed: {e}")
        log_critical_operation(logger, "SYSTEM_STARTUP_FAILED", {"error": str(e)})
        sys.exit(1)

def start_mcp_server(logger):
    """Start MCP server with logging"""
    mcp_path = project_root / "mcp_servers" / "mcp"
    
    if not mcp_path.exists():
        logger.error(f"MCP server path not found: {mcp_path}")
        return
    
    logger.info(f"Starting MCP server from: {mcp_path}")
    log_critical_operation(logger, "MCP_SERVER_START", {"path": str(mcp_path)})
    
    # Change to MCP directory and start server
    os.chdir(mcp_path)
    subprocess.run([sys.executable, "mcp_server.py"], check=True)

def start_a2a_server(logger, config_path):
    """Start A2A server with logging"""
    a2a_path = project_root / "a2a_servers" / "app"
    
    if not a2a_path.exists():
        logger.error(f"A2A server path not found: {a2a_path}")
        return
    
    config_full_path = project_root / config_path
    if not config_full_path.exists():
        logger.error(f"Configuration file not found: {config_full_path}")
        return
    
    logger.info(f"Starting A2A server from: {a2a_path}")
    logger.info(f"Using configuration: {config_full_path}")
    
    log_critical_operation(logger, "A2A_SERVER_START", {
        "path": str(a2a_path),
        "config": str(config_full_path)
    })
    
    # Change to A2A directory and start server
    os.chdir(a2a_path)
    subprocess.run([sys.executable, "src/a2a_service.py", "--config", str(config_full_path)], check=True)

if __name__ == "__main__":
    main()